package lia.admin;

import java.io.IOException;
import java.util.HashMap;

import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.store.Directory;

/** Utility class to get/refresh searchers when you are
 *  using multiple threads. */

public class SearcherManager {
  private HashMap searcherRefCount = new HashMap();
  private IndexSearcher searcher;                                //A
  private Directory dir;

  public SearcherManager(Directory dir) throws IOException {
    this.dir = dir;
    searcher = new IndexSearcher(IndexReader.open(dir));
    initRefCount(searcher);                                      //B
  }

  public void warm(IndexSearcher searcher) {}                    //C

  public void maybeReOpen() throws IOException {                 //D
    long currentVersion = searcher.getIndexReader().getVersion();
    if (IndexReader.getCurrentVersion(dir) != currentVersion) {
      IndexReader newReader = searcher.getIndexReader().reopen();
      assert newReader != searcher.getIndexReader();
      IndexSearcher newSearcher = new IndexSearcher(newReader);
      warm(newSearcher);
      swapSearcher(newSearcher);
    }
  }

  public synchronized IndexSearcher get() {                      //E
    int refCount = getRefCount(searcher);
    searcherRefCount.put(searcher, new Integer(1+refCount));
    return searcher;
  }    

  public synchronized void release(IndexSearcher searcher)       //F
    throws IOException {
    int refCount = getRefCount(searcher);
    if (refCount == 1) {
      searcher.close();
      searcherRefCount.remove(searcher);
    } else
      searcherRefCount.put(searcher, new Integer(refCount-1));
  }

  private synchronized int getRefCount(IndexSearcher searcher) {
    Integer refCount = (Integer) searcherRefCount.get(searcher);
    return refCount.intValue();
  }

  private synchronized void initRefCount(IndexSearcher searcher) {
    searcherRefCount.put(searcher, new Integer(1));
  }

  private synchronized void swapSearcher(IndexSearcher newSearcher) throws IOException {
    release(searcher);
    searcher = newSearcher;
    initRefCount(searcher);
  }
}

/*
#A Current IndexSearcher
#B Set refCount to 1 for initial searcher
#C Implement in subclass to warm new searcher
#D Call this to reopen searcher if index changed
#E Returns current searcher
#F Release searcher
*/
