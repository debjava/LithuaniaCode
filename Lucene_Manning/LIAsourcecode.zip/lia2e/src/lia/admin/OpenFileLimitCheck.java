package lia.admin;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.File;
import java.util.List;
import java.util.ArrayList;

/** Run this to see what your JRE's open file limit is. */

public class OpenFileLimitCheck {
  public static void main() throws IOException {
    int count = 0;
    List<RandomAccessFile> files = new ArrayList<RandomAccessFile>();
    try {
      while(true) {
        files.add(new RandomAccessFile("tmp" + count, "rw"));
        count++;
      }
    } catch (IOException ioe) {
      System.out.println("IOException after  " + count + " open files:");
      ioe.printStackTrace(System.out);
      for(int i=0;i<count;i++)
        new File("tmp" + i).delete();
    }
  }
}
