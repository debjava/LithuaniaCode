package lia.meetlucene;

import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;

import java.io.File;
import java.io.IOException;
import java.io.FileReader;
import java.util.Date;

/**
 * This code was originally written for
 * Erik's Lucene intro java.net article
 */
public class Indexer {

  public static void main(String[] args) throws Exception {
    if (args.length != 2) {
      throw new Exception("Usage: java " + Indexer.class.getName()
        + " <index dir> <data dir>");
    }
    File indexDir = new File(args[0]);         //1
    File dataDir = new File(args[1]);          //2

    long start = new Date().getTime();
    Indexer indexer = new Indexer(indexDir, dataDir);
    int numIndexed = indexer.index();
    long end = new Date().getTime();

    System.out.println("Indexing " + numIndexed + " files took "
      + (end - start) + " milliseconds");
  }

  private File indexDir, dataDir;
  private IndexWriter writer;

  public Indexer(File indexDir, File dataDir) throws IOException {
    this.indexDir = indexDir;
    this.dataDir = dataDir;
    writer = new IndexWriter(indexDir,          //3
                             new StandardAnalyzer(), true,
                             IndexWriter.MaxFieldLength.UNLIMITED);
  }

  public void close() throws IOException {
    writer.close();
  }

  // open an index and start file directory traversal
  public int index() throws Exception {

    if (!dataDir.exists() || !dataDir.isDirectory()) {
      throw new IOException(dataDir
        + " does not exist or is not a directory");
    }

    indexDirectory(dataDir);

    return writer.numDocs();
  }

  // recursive method that calls itself when it finds a directory
  private void indexDirectory(File dir) throws Exception {

    File[] files = dir.listFiles();

    for (int i = 0; i < files.length; i++) {
      File f = files[i];
      if (f.isDirectory()) {
        indexDirectory(f);                          //5
      } else if (acceptFile(f)) {                           
        indexFile(f);
      }
    }
  }

  protected boolean acceptFile(File f) {                    //6
    return f.getName().endsWith(".txt");
  }

  // method to actually index a file using Lucene
  private void indexFile(File f) throws Exception {

    if (f.isHidden() || !f.exists() || !f.canRead()) {
      return;
    }

    System.out.println("Indexing " + f.getCanonicalPath());

    Document doc = getDocument(f);
    if (doc != null) {
      writer.addDocument(doc);
    }
  }

  protected Document getDocument(File f) throws Exception {
    Document doc = new Document();
    doc.add(new Field("contents", new FileReader(f)));      //7
    doc.add(new Field("filename", f.getCanonicalPath(),     //8
             Field.Store.YES, Field.Index.NOT_ANALYZED));   //9
    return doc;
  }
}

/*
#1 Create Lucene index in this directory
#2 Index files in this directory
#3 Create Lucene index
#4 Close index
#5 Recurse
#6 Index .txt files only
#7 Index file content
#8 Index filename
#9 Add document to Lucene index
*/
