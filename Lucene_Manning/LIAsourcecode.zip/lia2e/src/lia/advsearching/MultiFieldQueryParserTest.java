package lia.advsearching;

import lia.common.LiaTestCase;
import org.apache.lucene.analysis.SimpleAnalyzer;
import org.apache.lucene.queryParser.MultiFieldQueryParser;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.BooleanClause;

public class MultiFieldQueryParserTest extends LiaTestCase {
  public void testDefaultOperator() throws Exception {
    Query query = new MultiFieldQueryParser(new String[]{"title", "subject"},
        new SimpleAnalyzer()).parse("development");

    IndexSearcher searcher = new IndexSearcher(bookDirectory);
    TopDocs hits = searcher.search(query, 10);

    assertHitsIncludeTitle(searcher.getIndexReader(), hits, "Java Development with Ant");

    // has "development" in the subject field
    assertHitsIncludeTitle(searcher.getIndexReader(), hits, "Extreme Programming Explained");
  }

  public void testSpecifiedOperator() throws Exception {
    Query query = MultiFieldQueryParser.parse("development",
        new String[]{"title", "subject"},
        new BooleanClause.Occur[]{BooleanClause.Occur.MUST,
                  BooleanClause.Occur.MUST},
        new SimpleAnalyzer());

    IndexSearcher searcher = new IndexSearcher(bookDirectory);
    TopDocs hits = searcher.search(query, 10);

    assertHitsIncludeTitle(searcher.getIndexReader(), hits, "Java Development with Ant");
    assertEquals("one and only one", 1, hits.scoreDocs.length);
  }

}
