package lia.advsearching;

import java.util.Date;

import lia.common.LiaTestCase;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.store.Directory;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.DateTools;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.function.FieldScoreQuery;
import org.apache.lucene.search.function.CustomScoreQuery;

public class FunctionQueryTest extends LiaTestCase {

  IndexSearcher s;
  IndexWriter w;

  private void addDoc(int score, String content) throws Exception {
    Document doc = new Document();
    doc.add(new Field("score", Integer.toString(score), Field.Store.NO, Field.Index.NOT_ANALYZED_NO_NORMS));
    doc.add(new Field("content", content, Field.Store.NO, Field.Index.ANALYZED));
    w.addDocument(doc);
  }

  public void setUp() throws Exception {
    super.setUp();

    Directory dir = new RAMDirectory();
    w = new IndexWriter(dir, new StandardAnalyzer(),
                        IndexWriter.MaxFieldLength.LIMITED);
    addDoc(7, "this hat is green");
    addDoc(42, "this hat is blue");
    w.close();

    s = new IndexSearcher(dir);
  }

  public void tearDown() throws Exception {
    super.tearDown();
    s.close();
  }

  public void testFieldScoreQuery() throws Throwable {
    Query q = new FieldScoreQuery("score", FieldScoreQuery.Type.BYTE);
    TopDocs hits = s.search(q, 10);
    assertEquals(2, hits.scoreDocs.length);       // #1
    assertEquals(1, hits.scoreDocs[0].doc);       // #2
    assertEquals(42, (int) hits.scoreDocs[0].score);
    assertEquals(0, hits.scoreDocs[1].doc);
    assertEquals(7, (int) hits.scoreDocs[1].score);
  }

  /*
    #1 All documents match
    #2 Doc 1 is first because its static score (42) is
       higher than doc 0's (7)
  */

  public void testCustomScoreQuery() throws Throwable {
    Query q = new QueryParser("content", new StandardAnalyzer()).parse("the green hat");
    FieldScoreQuery qf = new FieldScoreQuery("score", FieldScoreQuery.Type.BYTE);
    CustomScoreQuery customQ = new CustomScoreQuery(q, qf) {
        public float customScore(int doc, float subQueryScore, float valSrcScore) {
          return (float) (Math.sqrt(subQueryScore) * valSrcScore);
        }
        public String name() {
          return "shortVal*sqrt(score)";
        }
      };

    TopDocs hits = s.search(customQ, 10);
    assertEquals(2, hits.scoreDocs.length);
    
    assertEquals(1, hits.scoreDocs[0].doc);           // #1
    assertEquals(0, hits.scoreDocs[1].doc);
  }

  /*
    #1 Even though document 0 is a better match to the
       original query, document 1 gets a better score after
       multiplying in its score field
   */

  static class RecencyBoostingQuery extends CustomScoreQuery {

    int[] daysAgo;
    double multiplier;
    int maxDaysAgo;

    public RecencyBoostingQuery(Query q, int[] daysAgo, double multiplier,
                                int maxDaysAgo) {
      super(q);
      this.daysAgo = daysAgo;
      this.multiplier = multiplier;
      this.maxDaysAgo = maxDaysAgo;
    }

    public float customScore(int doc, float subQueryScore,
                             float valSrcScore) {
      if (daysAgo[doc] < maxDaysAgo) {                                   // #1
        float boost = (float) (multiplier * (maxDaysAgo-daysAgo[doc])    // #2
                               / maxDaysAgo);                            // #2
        return (float) (subQueryScore * (1.0+boost));
      } else
        return subQueryScore;                                            // #3
    }
  };

  /*
    #1 Check if book is new enough to get a boost
    #2 Do a simple linear boost; other functions are possible
    #3 Book is too old
  */

  final private static int MSEC_PER_DAY = 24*3600*1000;

  public void testRecency() throws Throwable {
    IndexReader r = IndexReader.open(bookDirectory);
    IndexSearcher s = new IndexSearcher(r);
    int maxDoc = s.maxDoc();
    int[] daysAgo = new int[maxDoc];
    //long now = new Date().getTime();
    long now = DateTools.stringToTime("200410");
    for(int i=0;i<maxDoc;i++) {                     // #1
      if (!r.isDeleted(i)) {
        long then = DateTools.stringToTime(r.document(i).get("pubmonth"));
        daysAgo[i] = (int) ((now - then)/MSEC_PER_DAY);
      }
    }

    QueryParser parser = new QueryParser("contents", new StandardAnalyzer());
    Query q = parser.parse("technology in action");  // #2
    Query q2 = new RecencyBoostingQuery(q, daysAgo,  // #3
                                        2.0, 2*365);
    TopDocs hits = s.search(q2, 5);
    //TopDocs hits = s.search(q, 5);
    for(int i=0;i<hits.scoreDocs.length;i++) {
      Document doc = r.document(hits.scoreDocs[i].doc);
      System.out.println((1+i) + ": " + doc.get("title") + ": score=" + hits.scoreDocs[i].score);
    }
    s.close();
  }

  /*
    #1 Build up daysAgo array, containing how many days ago
       each book was published
    #2 Normal query
    #3 Query that boosts by recency 
  */
}
