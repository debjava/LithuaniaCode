package lia.advsearching;

import lia.common.LiaTestCase;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.CachingWrapperFilter;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.QueryWrapperFilter;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.RangeFilter;
import org.apache.lucene.search.RangeQuery;
import org.apache.lucene.search.PrefixFilter;

public class FilterTest extends LiaTestCase {
  private RangeQuery allBooks;
  private IndexSearcher searcher;
  private int numAllBooks;

  protected void setUp() throws Exception {    // #1
    super.setUp();

    allBooks = new RangeQuery(
                      "pubmonth",
                      "190001",
                      "200512",
                      true, true);
    allBooks.setConstantScoreRewrite(true);
    searcher = new IndexSearcher(bookDirectory);
    TopDocs hits = searcher.search(allBooks, 20);
    numAllBooks = hits.totalHits;
  }

  public void testDateFilter() throws Exception {
    String jan1 = parseDate("2004-01-01");
    String jan31 = parseDate("2004-01-31");
    String dec31 = parseDate("2004-12-31");

    RangeFilter filter = new RangeFilter("modified", jan1, dec31, true, true);

    TopDocs hits = searcher.search(allBooks, filter, 20);
    assertEquals("all modified in 2004",
        numAllBooks, hits.scoreDocs.length);

    filter = new RangeFilter("modified", jan1, jan31, true, true);
    hits = searcher.search(allBooks, filter, 20);
     assertEquals("none modified in January",
        0, hits.scoreDocs.length);
  }

  /*
    #1 setUp() establishes baseline book count
  */

  public void testQueryWrapperFilter() throws Exception {
    TermQuery categoryQuery =
       new TermQuery(new Term("category", "/philosophy/eastern"));

    Filter categoryFilter = new QueryWrapperFilter(categoryQuery);

    TopDocs hits = searcher.search(allBooks, categoryFilter, 20);
    assertEquals("only tao te ching", 1, hits.scoreDocs.length);
  }

  public void testFilterAlternative() throws Exception {
    TermQuery categoryQuery =
       new TermQuery(new Term("category", "/philosophy/eastern"));

    BooleanQuery constrainedQuery = new BooleanQuery();
    constrainedQuery.add(allBooks, BooleanClause.Occur.MUST);
    constrainedQuery.add(categoryQuery, BooleanClause.Occur.MUST);

    TopDocs hits = searcher.search(constrainedQuery, 20);
    assertEquals("only tao te ching", 1, hits.scoreDocs.length);
  }


  public void testQueryWrapperFilterWithRangeQuery() throws Exception {
    String jan1 = parseDate("2004-01-01");
    String dec31 = parseDate("2004-12-31");

    RangeQuery rangeQuery = new RangeQuery("modified", jan1, dec31,
                                           true, true);
    Filter filter = new QueryWrapperFilter(rangeQuery);
    TopDocs hits = searcher.search(allBooks, filter, 20);
    assertEquals("all of 'em", numAllBooks, hits.scoreDocs.length);
  }

  public void testPrefixFilter() throws Exception {
    Filter prefixFilter = new PrefixFilter(new Term("pubmonth", "19"));

    TopDocs hits = searcher.search(allBooks, prefixFilter, 20);
    assertEquals("only 19XX books", 7, hits.totalHits);
  }

  public void testCachingWrapper() throws Exception {
    String jan1 = parseDate("2004-01-01");
    String dec31 = parseDate("2004-12-31");

    RangeFilter dateFilter =
        new RangeFilter("modified", jan1, dec31, true, true);

    CachingWrapperFilter cachingFilter = new CachingWrapperFilter(dateFilter);
    TopDocs hits = searcher.search(allBooks, cachingFilter, 20);
    assertEquals("all of 'em", numAllBooks, hits.totalHits);
  }
}
