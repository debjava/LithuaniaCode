package lia.advsearching;

import org.apache.commons.lang.StringUtils;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.RangeQuery;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.SortField;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import java.io.IOException;
import java.io.File;
import java.text.DecimalFormat;

public class SortingExample {
  private Directory directory;

  public SortingExample(Directory directory) {
    this.directory = directory;
  }

  public void displayResults(Query query, Sort sort)            // #1
      throws IOException {
    IndexSearcher searcher = new IndexSearcher(directory);

    TopDocs results = searcher.search(query, null, 20, sort);   // #2

    System.out.println("\nResults for: " +                      // #3
        query.toString() + " sorted by " + sort);

    System.out.println(StringUtils.rightPad("Title", 30) +
        StringUtils.rightPad("pubmonth", 10) +
        StringUtils.center("id", 4) +
        StringUtils.center("score", 15));

    DecimalFormat scoreFormatter = new DecimalFormat("0.######");
    for (int i = 0; i < results.scoreDocs.length; i++) {
      int docID = results.scoreDocs[i].doc;
      float score = results.scoreDocs[i].score;
      Document doc = searcher.doc(docID);
      System.out.println(
          StringUtils.rightPad(                                                    // #4
              StringUtils.abbreviate(doc.get("title"), 29), 30) +                  // #4
          StringUtils.rightPad(doc.get("pubmonth"), 10) +                          // #4
          StringUtils.center("" + docID, 4) +                                      // #4
          StringUtils.leftPad(                                                     // #4
              scoreFormatter.format(score), 12));                                  // #4
      System.out.println("   " + doc.get("category"));
      //System.out.println(searcher.explain(query, results.scoreDocs[i].doc));     // #5
    }

    searcher.close();
  }

  public static void main(String[] args) throws Exception {
    String earliest = "190001";
    String latest = "201012";
    Query allBooks = new RangeQuery("pubmonth", earliest, latest, true, true);
    //allBooks.setConstantScoreRewrite(true);                                       //#6
    String indexDir = System.getProperty("index.dir");

    FSDirectory directory = new FSDirectory(new File(indexDir), null);
    SortingExample example = new SortingExample(directory);

    example.displayResults(allBooks, Sort.RELEVANCE);

    example.displayResults(allBooks, Sort.INDEXORDER);

    example.displayResults(allBooks, new Sort("category"));

    example.displayResults(allBooks, new Sort("pubmonth", true));

    example.displayResults(allBooks,
        new Sort(new SortField[]{
          new SortField("category"),
          SortField.FIELD_SCORE,
          new SortField("pubmonth", SortField.INT, true)
        }));


    example.displayResults(allBooks, new Sort(new SortField[] {SortField.FIELD_SCORE, new SortField("category")}));
  }
}

/*
#1 Sort object encapsulates sorting info
#2 Sarch method that accepts Sort
#3 toString output
#4 StringUtils provides columnar output
#5 Explanation commented out for now
#6 Use constant-scoring rewrite method
*/
