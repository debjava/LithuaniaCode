
package lia.tools;
import java.io.IOException;
import java.io.File;
import org.apache.lucene.search.spell.SpellChecker;
import org.apache.lucene.search.spell.LuceneDictionary;
import org.apache.lucene.search.spell.JaroWinklerDistance;
import org.apache.lucene.search.spell.LevensteinDistance;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.Directory;

public class CreateSpellCheckerIndex {

  public static void main(String[] args) throws IOException {

    if (args.length != 3) {
      System.out.println("Usage: java lia.tools.SpellCheckerTest SpellCheckerIndexDir IndexDir IndexField");
      System.exit(1);
    }

    String spellCheckDir = args[0];
    String indexDir = args[1];
    String indexField = args[2];

    System.out.println("Now build SpellChecker index...");
    Directory dir = new FSDirectory(new File(spellCheckDir), null);
    SpellChecker spell = new SpellChecker(dir);     //#1
    long startTime = System.currentTimeMillis();
    IndexReader r = IndexReader.open(indexDir);     //#2
    try {
      spell.indexDictionary(new LuceneDictionary(r, indexField));  //#3
    } finally {
      r.close();
    }
    dir.close();
    long endTime = System.currentTimeMillis();
    System.out.println("  took " + (endTime-startTime) + " milliseconds");
  }

  /*
    #1 Create SpellChecker on its directory
    #2 Open IndexReader containing words to add to spell dictionary
    #3 Add all words from the specified fields into the spell checker index
   */
}
