package lia.tools;

import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.highlight.Fragmenter;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.SimpleFragmenter;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;

import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;

public class HighlightIt {
  private static final String text =
    "Giving end users some context around hits from their searches is friendly and, more important, useful. A prime example is Google search results. Each hit, as shown in Figure 1.1, includes up to three lines of the matching document highlighting the terms of the query. Often a brief glimpse of the surrounding context of the search terms is enough to know if that result is worth investigating further.  Like spell correction, covered in Section 8.11, the Web search engines have established this feature as a requirement that all other search engines are expected to have: users now expect it. " + 
    "What's commonly referred to as highlighting in fact consists of two different functionalities.  First is dynamic fragmenting, which means picking a few sentences out of a large text that best match the search query.  Some search applications skip this step, and instead fallback on a static abstract or summary for each document, but generally that gives a worse user experience because it's static." + 
    "The second function is highlighting, whereby specific words in context of their surrounding text are called out, often with bolding and a colored background, so the user’s eyes can quickly jump to specific words that matched.  These two functions are somewhat independent.  For example, you may apply highlighting to a title field without excerpting it, because you always want to present the full title.  Or, for a field that has a large amount of text, you would first excerpt it and then apply the highlighting.";

  public static void main(String[] args) throws IOException {
    String filename = args[0];

    if (filename == null) {
      System.err.println("Usage: HighlightIt <filename>");
      System.exit(-1);
    }

    TermQuery query = new TermQuery(new Term("f", "highlighting"));
    QueryScorer scorer = new QueryScorer(query);
    SimpleHTMLFormatter formatter =                                   // #1
      new SimpleHTMLFormatter("<span class=\"highlight\">",           // #1
                              "</span>");                             // #1
    Highlighter highlighter = new Highlighter(formatter, scorer);
    Fragmenter fragmenter = new SimpleFragmenter(70);                 // #2
    highlighter.setTextFragmenter(fragmenter);

    TokenStream tokenStream = new StandardAnalyzer()                  // #3
        .tokenStream("f", new StringReader(text));                    // #3

    String result =                                                   // #4
        highlighter.getBestFragments(tokenStream, text, 5, "...");    // #4

    FileWriter writer = new FileWriter(filename);
    writer.write("<html>");
    writer.write("<style>\n" +                                        // #5
        ".highlight {\n" +                                            // #5
        " background: yellow;\n" +                                    // #5
        "}\n" +                                                       // #5
        "</style>");                                                  // #5
    writer.write("<body>");
    writer.write(result);
    writer.write("</body></html>");
    writer.close();
  }
}

/*
#1 Customize surrounding tags
#2 Reduce default fragment size
#3 Tokenize text
#4 Highlight best 5 fragments
#5 Write highlighted HTML
*/