package lia.tools;

import junit.framework.TestCase;
import org.apache.lucene.analysis.snowball.SnowballAnalyzer;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import lia.analysis.AnalyzerUtils;

import java.io.StringReader;

public class SnowballTest extends TestCase {
  public void testEnglish() throws Exception {
    Analyzer analyzer = new SnowballAnalyzer("English");
    TokenStream.setUseNewAPIDefault(false);
    AnalyzerUtils.assertAnalyzesTo(analyzer,
                                   "stemming algorithms", new String[] {"stem", "algorithm"});
  }

  public void testSpanish() throws Exception {
    Analyzer analyzer = new SnowballAnalyzer("Spanish");
    TokenStream.setUseNewAPIDefault(false);
    AnalyzerUtils.assertAnalyzesTo(analyzer,
                                   "algoritmos", new String[] {"algoritm"});
  }
}
