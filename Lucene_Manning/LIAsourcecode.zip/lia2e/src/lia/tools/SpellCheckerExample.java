
package lia.tools;
import java.io.IOException;
import java.io.File;
import org.apache.lucene.search.spell.SpellChecker;
import org.apache.lucene.search.spell.LuceneDictionary;
import org.apache.lucene.search.spell.JaroWinklerDistance;
import org.apache.lucene.search.spell.LevensteinDistance;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.Directory;

public class SpellCheckerExample {

  public static void main(String[] args) throws IOException {

    if (args.length != 2) {
      System.out.println("Usage: java lia.tools.SpellCheckerTest SpellCheckerIndexDir wordToRespell");
      System.exit(1);
    }

    String spellCheckDir = args[0];
    String wordToRespell = args[1];

    Directory dir = new FSDirectory(new File(spellCheckDir), null);
    SpellChecker spell = new SpellChecker(dir);  //#1

    spell.setStringDistance(new LevensteinDistance());  //#2
    //spell.setStringDistance(new JaroWinklerDistance());

    String[] suggestions = spell.suggestSimilar(wordToRespell, 5); //#3
    System.out.println(suggestions.length + " suggestions for '" + wordToRespell + "':");
    for(int i=0;i<suggestions.length;i++)
      System.out.println("  " + suggestions[i]);
  }

  /*
    #1 Create SpellCheck from existing spell check index
    #2 Sets the string distance metric used to rank the suggestions
    #3 Generate respelled candidates
   */
}
