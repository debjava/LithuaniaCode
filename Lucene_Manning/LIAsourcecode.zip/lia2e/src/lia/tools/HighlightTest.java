package lia.tools;

import lia.common.LiaTestCase;
import org.apache.lucene.analysis.SimpleAnalyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.index.Term;
import org.apache.lucene.document.Document;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.TokenSources;

import java.io.StringReader;

public class HighlightTest extends LiaTestCase {
  public void testHighlighting() throws Exception {
    String text = "The quick brown fox jumps over the lazy dog";

    TermQuery query = new TermQuery(new Term("field", "fox"));
    QueryScorer scorer = new QueryScorer(query);
    Highlighter highlighter = new Highlighter(scorer);

    TokenStream tokenStream =
        new SimpleAnalyzer().tokenStream("field",
            new StringReader(text));

    assertEquals("The quick brown <B>fox</B> jumps over the lazy dog",
        highlighter.getBestFragment(tokenStream, text));
  }

  public void testHits() throws Exception {
    IndexSearcher searcher = new IndexSearcher(bookDirectory);
    TermQuery query = new TermQuery(new Term("title", "action"));
    TopDocs hits = searcher.search(query, 10);

    QueryScorer scorer = new QueryScorer(query);
    Highlighter highlighter = new Highlighter(scorer);
    Analyzer analyzer = new SimpleAnalyzer();
    
    for (int i = 0; i < hits.scoreDocs.length; i++) {
      Document doc = searcher.doc(hits.scoreDocs[i].doc);
      String title = doc.get("title");

      TokenStream stream = TokenSources.getAnyTokenStream(searcher.getIndexReader(),
                                                          hits.scoreDocs[i].doc,
                                                          "title",
                                                          doc,
                                                          analyzer);
      String fragment =
          highlighter.getBestFragment(stream, title);

      System.out.println(fragment);
    }
  }

}
