package lia.searching;

import lia.common.LiaTestCase;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.RangeQuery;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.BooleanClause;

public class BooleanQueryTest extends LiaTestCase {
  public void testAnd() throws Exception {
    TermQuery searchingBooks =
      new TermQuery(new Term("subject","search"));  //#1

    RangeQuery books2004 =                       //#2
      new RangeQuery("pubmonth", "200401",       //#2
                     "200412",                   //#2
                     true, true);                //#2

    BooleanQuery searchingBooks2004 = new BooleanQuery();              //#3
    searchingBooks2004.add(searchingBooks, BooleanClause.Occur.MUST);  //#3
    searchingBooks2004.add(books2004, BooleanClause.Occur.MUST);       //#3

    IndexSearcher searcher = new IndexSearcher(bookDirectory);
    TopDocs matches = searcher.search(searchingBooks2004, 10);

    assertHitsIncludeTitle(searcher.getIndexReader(), matches, "Lucene in Action");
  }

  public void testOr() throws Exception {
    TermQuery methodologyBooks = new TermQuery(
        new Term("category",
            "/technology/computers/programming/methodology"));

    TermQuery easternPhilosophyBooks = new TermQuery(
        new Term("category",
            "/philosophy/eastern"));

    BooleanQuery enlightenmentBooks = new BooleanQuery();
    enlightenmentBooks.add(methodologyBooks, BooleanClause.Occur.SHOULD);
    enlightenmentBooks.add(easternPhilosophyBooks, BooleanClause.Occur.SHOULD);

    IndexSearcher searcher = new IndexSearcher(bookDirectory);
    TopDocs matches = searcher.search(enlightenmentBooks, 10);
    System.out.println("or = " + enlightenmentBooks);

    assertHitsIncludeTitle(searcher.getIndexReader(), matches, "Extreme Programming Explained");
    assertHitsIncludeTitle(searcher.getIndexReader(), matches,
                               "Tao Te Ching \u9053\u5FB7\u7D93");
  }
}

/*
#1 All books with subject “search”
#2 All books in 2004
#3 Combines two queries
*/
