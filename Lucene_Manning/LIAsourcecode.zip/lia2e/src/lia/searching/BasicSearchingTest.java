package lia.searching;

import lia.common.LiaTestCase;
import org.apache.lucene.analysis.SimpleAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;

public class BasicSearchingTest extends LiaTestCase {

  public void testTerm() throws Exception {
    IndexSearcher searcher = new IndexSearcher(bookDirectory);
    Term t = new Term("subject", "ant");
    Query query = new TermQuery(t);
    TopDocs docs = searcher.search(query, 10);
    assertEquals("JDwA", 1, docs.totalHits);

    t = new Term("subject", "junit");
    docs = searcher.search(new TermQuery(t), 10);
    assertEquals(2, docs.totalHits);

    searcher.close();
  }

  public void testKeyword() throws Exception {
    IndexSearcher searcher = new IndexSearcher(bookDirectory);
    Term t = new Term("isbn", "1930110995");
    Query query = new TermQuery(t);
    TopDocs docs = searcher.search(query, 10);
    assertEquals("JUnit in Action", 1, docs.totalHits);
  }

  public void testQueryParser() throws Exception {
    IndexSearcher searcher = new IndexSearcher(bookDirectory);
    QueryParser parser = new QueryParser("contents",
                                         new SimpleAnalyzer());

    Query query = parser.parse("+JUNIT +ANT -MOCK");
    TopDocs docs = searcher.search(query, 10);
    assertEquals(1, docs.totalHits);
    Document d = searcher.doc(docs.scoreDocs[0].doc);
    assertEquals("Java Development with Ant", d.get("title"));

    query = new QueryParser("contents",
                              new SimpleAnalyzer()).parse("mock OR junit");
    docs = searcher.search(query, 10);
    assertEquals("JDwA and JIA", 2, docs.totalHits);
  }
}
