package lia.searching;

import lia.common.LiaTestCase;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.RangeQuery;

public class RangeQueryTest extends LiaTestCase {
  private String begin, end;

  protected void setUp() throws Exception {
    begin = "198805";

    // pub date of TTC was October 1988
    end = "198810";

    super.setUp();
  }

  public void testInclusive() throws Exception {
    RangeQuery query = new RangeQuery("pubmonth", begin, end,
                                      true, true);
    IndexSearcher searcher = new IndexSearcher(bookDirectory);

    TopDocs matches = searcher.search(query, 10);
    assertEquals("tao", 1, matches.totalHits);
  }

  public void testExclusive() throws Exception {
    RangeQuery query = new RangeQuery("pubmonth", begin, end,
                                      false, false);
    IndexSearcher searcher = new IndexSearcher(bookDirectory);

    TopDocs matches = searcher.search(query, 10);
    assertEquals("there is no tao", 0, matches.totalHits);
  }

}
