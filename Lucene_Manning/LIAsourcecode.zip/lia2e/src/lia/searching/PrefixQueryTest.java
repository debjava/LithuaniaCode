package lia.searching;

import lia.common.LiaTestCase;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.PrefixQuery;
import org.apache.lucene.search.TermQuery;

public class PrefixQueryTest extends LiaTestCase {
  public void testPrefix() throws Exception {
    IndexSearcher searcher = new IndexSearcher(bookDirectory);

    // search for programming books, including subcategories
    Term term = new Term("category",                              //#1
                         "/technology/computers/programming");    //#1
    PrefixQuery query = new PrefixQuery(term);                    //#1

    TopDocs matches = searcher.search(query, 10);                 //#1
    int programmingAndBelow = matches.totalHits;

    // only programming books, not subcategories
    matches = searcher.search(new TermQuery(term), 10);           //#2
    int justProgramming = matches.totalHits;

    assertTrue(programmingAndBelow > justProgramming);
  }
}

/*
  #1 Search for programming books, including subcategories
  #2 Search only for programming books, not subcategories
*/

