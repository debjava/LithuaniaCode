package lia.searching;

import lia.common.LiaTestCase;
import lia.analysis.synonym.SynonymAnalyzer;
import lia.analysis.synonym.SynonymEngine;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.StopAnalyzer;
import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.FuzzyQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.RangeQuery;
import org.apache.lucene.search.MultiPhraseQuery;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.document.DateTools;

import java.util.Locale;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;

public class QueryParserTest extends LiaTestCase {
  private Analyzer analyzer;
  private IndexSearcher searcher;

  protected void setUp() throws Exception {
    super.setUp();
    analyzer = new WhitespaceAnalyzer();
    searcher = new IndexSearcher(bookDirectory);
  }

  public void testToString() throws Exception {
    BooleanQuery query = new BooleanQuery();
    query.add(new FuzzyQuery(new Term("field", "kountry")),
              BooleanClause.Occur.MUST);
    query.add(new TermQuery(new Term("title", "western")),
              BooleanClause.Occur.SHOULD);
    assertEquals("both kinds", "+kountry~0.5 title:western",
                 query.toString("field"));
  }

  public void testPrefixQuery() throws Exception {
    QueryParser parser = new QueryParser("category", new StandardAnalyzer());
    parser.setLowercaseExpandedTerms(false);
    System.out.println(parser.parse("/Computers/technology*").toString("category"));
  }

  public void testGrouping() throws Exception {
    Query query = new QueryParser(
        "subject",
        analyzer).parse("(agile OR extreme) AND methodology");
    TopDocs matches = searcher.search(query, 10);

    assertHitsIncludeTitle(searcher.getIndexReader(),
                           matches,
                           "Extreme Programming Explained");
    assertHitsIncludeTitle(searcher.getIndexReader(),
                           matches,
                           "The Pragmatic Programmer");
  }

  public void testRangeQuery() throws Exception {
    Query query = new QueryParser("subject", analyzer).parse("pubmonth:[200401 TO 200412]");

    assertTrue(query instanceof RangeQuery);
    assertTrue(((RangeQuery) query).getConstantScoreRewrite());

    TopDocs matches = searcher.search(query, 10);
    assertHitsIncludeTitle(searcher.getIndexReader(), matches, "Lucene in Action");

    query = new QueryParser("pubmonth", analyzer).parse("{200201 TO 200208}");
    matches = searcher.search(query, 10);
    assertEquals("JDwA in 200208", 0, matches.totalHits);
  }

  public void testDateRangeQuery() throws Exception {
    String expression = "modified:[1/1/04 TO 12/31/04]";

    QueryParser parser = new QueryParser("subject", analyzer);

    // Tell QueryParser we indexed field "modified" with resolution DAY:
    parser.setDateResolution("modified", DateTools.Resolution.DAY);
    parser.setLocale(Locale.US);

    Query query = parser.parse(expression);
    TopDocs matches = searcher.search(query, 10);
    assertTrue(matches.totalHits > 0);
    System.out.println(expression + " parsed to " + query);
  }

  public void testSlop() throws Exception {
    Query q = new QueryParser("field", analyzer).parse("\"exact phrase\"");
    assertEquals("zero slop",
        "\"exact phrase\"", q.toString("field"));

    QueryParser qp = new QueryParser("field", analyzer);
    qp.setPhraseSlop(5);
    q = qp.parse("\"sloppy phrase\"");
    assertEquals("sloppy, implicitly",
        "\"sloppy phrase\"~5", q.toString("field"));
  }

  public void testPhraseQuery() throws Exception {
    Query q = new QueryParser("field", new StandardAnalyzer()).parse("\"This is Some Phrase*\"");
    assertEquals("analyzed",
        "\"some phrase\"", q.toString("field"));

    q = new QueryParser("field", analyzer).parse("\"term\"");
    assertTrue("reduced to TermQuery", q instanceof TermQuery);
  }

  public void testMultiPhraseQuery() throws Exception {
    SynonymEngine engine = new SynonymEngine() {
        public String[] getSynonyms(String s) {
          if (s.equals("quick"))
            return new String[] {"fast"};
          else
            return null;
        }
      };

    Query q = new QueryParser("field", new SynonymAnalyzer(engine)).parse("\"quick fox\"");
    assertEquals("analyzed",
        "field:\"(quick fast) fox\"", q.toString());
    assertTrue("parsed as MultiPhraseQuery", q instanceof MultiPhraseQuery);
  }

  public void testLowercasing() throws Exception {
    Query q = new QueryParser("field", analyzer).parse("PrefixQuery*");
    assertEquals("lowercased",
        "prefixquery*", q.toString("field"));

    QueryParser qp = new QueryParser("field", analyzer);
    qp.setLowercaseExpandedTerms(false);
    q = qp.parse("PrefixQuery*");
    assertEquals("not lowercased",
        "PrefixQuery*", q.toString("field"));
  }

  public void testWildcard() {
    try {
      new QueryParser("field", analyzer).parse("*xyz");
      fail("Leading wildcard character should not be allowed");
    } catch (ParseException expected) {
      assertTrue(true);
    }
  }

  public void testBoost() throws Exception {
    Query q = new QueryParser("field", analyzer).parse("term^2");
    assertEquals("term^2.0", q.toString("field"));
  }

  public void testParseException() {
    try {
      new QueryParser("contents", analyzer).parse("^&#");
    } catch (ParseException expected) {
      // expression is invalid, as expected
      assertTrue(true);
      return;
    }

    fail("ParseException expected, but not thrown");
  }
}
