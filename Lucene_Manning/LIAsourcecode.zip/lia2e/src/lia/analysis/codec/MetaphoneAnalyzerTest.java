package lia.analysis.codec;

import lia.analysis.AnalyzerUtils;
import lia.common.LiaTestCase;

import org.apache.lucene.util.AttributeSource;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TopDocCollector;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.analysis.TokenStream;
import java.io.IOException;

public class MetaphoneAnalyzerTest extends LiaTestCase {
  public void testFilter() throws Exception {
    AttributeSource[] tokens =
      AnalyzerUtils.tokensFromAnalysis(
                          new MetaphoneInjectionAnalyzer(), "cool cat");

    AnalyzerUtils.assertTokensEqual(tokens,
                      new String[]{ "cool", "KL", "cat", "KT" });

    assertEquals(1, AnalyzerUtils.getPositionIncrement(tokens[0]));
    assertEquals(0, AnalyzerUtils.getPositionIncrement(tokens[1]));
  }

  public void testKoolKat() throws Exception {
    RAMDirectory directory = new RAMDirectory();
    Analyzer analyzer = new MetaphoneReplacementAnalyzer();

    TokenStream.setUseNewAPIDefault(true);

    IndexWriter writer = new IndexWriter(directory, analyzer, true,
                                         IndexWriter.MaxFieldLength.LIMITED);

    Document doc = new Document();
    doc.add(new Field("contents", //#1
                      "cool cat",
                      Field.Store.YES,
                      Field.Index.ANALYZED));
    writer.addDocument(doc);
    writer.close();

    IndexSearcher searcher = new IndexSearcher(directory);
    Query query = new QueryParser("contents", analyzer).parse(//#2  
                                        "kool kat");

    TopDocCollector collector = new TopDocCollector(1);
    searcher.search(query, collector);
    assertEquals(1, collector.getTotalHits());   //#3   
    int docID = collector.topDocs().scoreDocs[0].doc;
    doc = searcher.getIndexReader().document(docID);
    assertEquals("cool cat", doc.get("contents"));   //#4 

    searcher.close();
  }

  /*
    #1 Original document
    #2 User typed in hip query
    #3 Hip query matches!
    #4 Original value still available
  */

  public static void main(String[] args) throws IOException {
    MetaphoneReplacementAnalyzer analyzer =
                                 new MetaphoneReplacementAnalyzer();
    AnalyzerUtils.displayTokens(analyzer,
                   "The quick brown fox jumped over the lazy dogs");

    System.out.println("");
    AnalyzerUtils.displayTokens(analyzer,
                   "Tha quik brown phox jumpd ovvar tha lazi dogz");
  }
}
