package lia.analysis.codec;

import org.apache.lucene.util.AttributeSource;
import org.apache.lucene.analysis.TokenFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.TermAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.apache.commons.codec.language.Metaphone;

import java.io.IOException;

public class MetaphoneReplacementFilter extends TokenFilter {
  public static final String METAPHONE = "METAPHONE";

  private Metaphone metaphoner = new Metaphone();    //#1  
  private TermAttribute termAttr;
  private TypeAttribute typeAttr;

  public MetaphoneReplacementFilter(TokenStream input) {
    super(input);
    termAttr = (TermAttribute) addAttribute(TermAttribute.class);
    typeAttr = (TypeAttribute) addAttribute(TypeAttribute.class);
  }

  public boolean incrementToken() throws IOException {
    if (!input.incrementToken())                    //#2   
      return false;                                 //#3  

    String encoded;
    encoded = metaphoner.encode(termAttr.term());   //#4  
    termAttr.setTermBuffer(encoded);                //#5
    typeAttr.setType(METAPHONE);                    //#6 
    return true;
  }
}

/*
#1 org.apache.commons.codec.language.Metaphone
#2 Advance to next token
#3 When false, end has been reached
#4 Convert term text to Metaphone encoding
#5 Overwrite term text with encoded text
#6 Set token type
*/
