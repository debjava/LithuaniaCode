package lia.analysis.codec;

import org.apache.lucene.util.AttributeSource;
import org.apache.lucene.analysis.TokenFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.TermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.TypeAttribute;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
import org.apache.commons.codec.language.Metaphone;
import java.io.IOException;

/**
 * Remove??  We don't show this anymore since SynonymAnalyzer
 * demonstrates placing more than one token in a position
 */
public class MetaphoneInjectionFilter extends TokenFilter {
  public static String METAPHONE = "METAPHONE";

  private Metaphone metaphoner = new Metaphone();
  private AttributeSource save = new AttributeSource();
  private boolean saved;
  private TermAttribute termAttr;
  private OffsetAttribute offsetAttr;
  private TermAttribute saveTermAttr;
  private TypeAttribute saveTypeAttr;
  private OffsetAttribute saveOffsetAttr;
  private PositionIncrementAttribute savePosIncrAttr;

  public MetaphoneInjectionFilter(TokenStream input) {
    super(input);
    termAttr = (TermAttribute) addAttribute(TermAttribute.class);
    offsetAttr = (OffsetAttribute) addAttribute(OffsetAttribute.class);
    saveTermAttr = (TermAttribute) save.addAttribute(TermAttribute.class);
    saveTypeAttr = (TypeAttribute) save.addAttribute(TypeAttribute.class);
    savePosIncrAttr = (PositionIncrementAttribute) save.addAttribute(PositionIncrementAttribute.class);
    saveOffsetAttr = (OffsetAttribute) save.addAttribute(OffsetAttribute.class);

    addAttribute(TypeAttribute.class);
    addAttribute(TermAttribute.class);
    addAttribute(PositionIncrementAttribute.class);
    addAttribute(OffsetAttribute.class);
  }

  public boolean incrementToken() throws IOException {

    // emit saved token, if available
    if (saved) {
      save.restoreState(this);
      saved = false;
      return true;
    }

    // pull next token from stream
    if (!input.incrementToken())
      return false;   // all done

    // create metaphone, save until next request
    String value = metaphoner.encode(termAttr.term());
    saveOffsetAttr.setStartOffset(offsetAttr.startOffset());
    saveOffsetAttr.setEndOffset(offsetAttr.endOffset());
    saveTermAttr.setTermBuffer(value);
    saveTypeAttr.setType(METAPHONE);
    savePosIncrAttr.setPositionIncrement(0);
    saved = true;

    return true;
  }
}
