package lia.analysis.i18n;

import lia.common.LiaTestCase;

import org.apache.lucene.index.Term;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.TermQuery;

public class ChineseTest extends LiaTestCase {
  public void testChinese() throws Exception {
    IndexSearcher searcher = new IndexSearcher(bookDirectory);
    assertEquals("tao", 1, getHitCount(searcher, new TermQuery(new Term("contents", "道"))));
  }
}
