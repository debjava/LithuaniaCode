package lia.analysis.i18n;

import lia.analysis.AnalyzerUtils;
import org.apache.lucene.util.AttributeSource;
import org.apache.lucene.analysis.tokenattributes.TermAttribute;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.SimpleAnalyzer;
import org.apache.lucene.analysis.cjk.CJKAnalyzer;
import org.apache.lucene.analysis.cn.ChineseAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;

import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Label;
import java.io.IOException;

public class ChineseDemo {
  private static String[] strings = {"道德經"};  //1 

  private static Analyzer[] analyzers = {
    new SimpleAnalyzer(),
    new StandardAnalyzer(),
    new ChineseAnalyzer (),    //2   
    new CJKAnalyzer ()   
  };

  public static void main(String args[]) throws Exception {

    for (int i = 0; i < strings.length; i++) {
      String string = strings[i];
      for (int j = 0; j < analyzers.length; j++) {
        Analyzer analyzer = analyzers[j];
        analyze(string, analyzer);
      }
    }

  }

  private static void analyze(String string, Analyzer analyzer)
         throws IOException {
    StringBuffer buffer = new StringBuffer();
    AttributeSource[] tokens =
      AnalyzerUtils.tokensFromAnalysis(analyzer, string);   //3
    for (int i = 0; i < tokens.length; i++) {
      TermAttribute term = (TermAttribute) tokens[i].getAttribute(TermAttribute.class);
      buffer.append("[");
      buffer.append(term.term());
      buffer.append("] ");
    }

    String output = buffer.toString();

    Frame f = new Frame();
    String name = analyzer.getClass().getName();
    f.setTitle(name.substring(name.lastIndexOf('.') + 1)
                  + " : " + string);
    f.setResizable(false);

    Font font = new Font(null, Font.PLAIN, 36);
    int width = getWidth(f.getFontMetrics(font), output);

    f.setSize((width < 250) ? 250 : width + 50, 75);
    Label label = new Label(buffer.toString());   //4 
    label.setSize(width, 75);
    label.setAlignment(Label.CENTER);
    label.setFont(font);
    f.add(label);

    f.setVisible(true);
  }

  private static int getWidth(FontMetrics metrics, String s) {
    int size = 0;
    for (int i = 0; i < s.length(); i++) {
      size += metrics.charWidth(s.charAt(i));
    }

    return size;
  }
}

/* 	
#1 Chinese text to be analyzed
#2 Analyzers from Sandbox
#3 Retrieve tokens from analysis using AnalyzerUtils
#4 AWT Label displays analysis
*/
