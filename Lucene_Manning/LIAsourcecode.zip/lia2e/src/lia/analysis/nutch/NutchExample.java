package lia.analysis.nutch;

import lia.analysis.AnalyzerUtils;

import org.apache.nutch.analysis.NutchDocumentAnalyzer;

import java.io.IOException;

public class NutchExample {
                              
  public static void main(String[] args) throws IOException {
    NutchDocumentAnalyzer analyzer = new NutchDocumentAnalyzer(null);   //1
    AnalyzerUtils.displayTokensWithFullDetails(analyzer, "The quick brown fox...");   //2
                                                            


    /*
    net.nutch.searcher.Query nutchQuery = net.nutch.searcher.Query.parse("\"the quick brown\"");      //3
    Query query = QueryTranslator.translate(nutchQuery);            //4
    System.out.println("query = " + query);
    */
  }
}

/*
#1 Custom analyzer
#2 displayTokensWithDetail method
#3 Use fully qualified class names
#4 Translate Nutch Query
*/
