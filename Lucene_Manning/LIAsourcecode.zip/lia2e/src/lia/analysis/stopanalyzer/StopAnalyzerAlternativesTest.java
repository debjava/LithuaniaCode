package lia.analysis.stopanalyzer;

import junit.framework.TestCase;
import org.apache.lucene.util.AttributeSource;
import lia.analysis.AnalyzerUtils;
import org.apache.lucene.analysis.tokenattributes.TermAttribute;

public class StopAnalyzerAlternativesTest extends TestCase {
  public void testStopAnalyzer2() throws Exception {
    AttributeSource[] tokens =
      AnalyzerUtils.tokensFromAnalysis(
        new StopAnalyzer2(), "The quick brown...");

      AnalyzerUtils.assertTokensEqual(tokens,
                                new String[] {"quick", "brown"});
  }

  public void testStopAnalyzerFlawed() throws Exception {
    AttributeSource[] tokens =
      AnalyzerUtils.tokensFromAnalysis(
        new StopAnalyzerFlawed(), "The quick brown...");

    TermAttribute termAttr = (TermAttribute) tokens[0].addAttribute(TermAttribute.class);
    assertEquals("the", termAttr.term());
  }

  /**
   * Illustrates that "the" is not removed, although it is lowercased
   */
  public static void main(String[] args) throws Exception {
    AnalyzerUtils.displayTokens(
      new StopAnalyzerFlawed(), "The quick brown...");
  }
}
