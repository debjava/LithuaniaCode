package lia.analysis.keyword;

import java.io.IOException;

import lia.common.LiaTestCase;

import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.analysis.SimpleAnalyzer;
import org.apache.lucene.analysis.PerFieldAnalyzerWrapper;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.queryParser.QueryParser;

public class KeywordAnalyzerTest extends LiaTestCase {

  private IndexSearcher searcher;

  public void setUp() throws Exception {

    super.setUp();

    IndexWriter writer = new IndexWriter(directory,
                                         new SimpleAnalyzer(), 
                                         true,
                                         IndexWriter.MaxFieldLength.LIMITED);

    Document doc = new Document();
    doc.add(new Field("partnum",
                      "Q36",
                      Field.Store.NO,
                      Field.Index.NOT_ANALYZED));   //1  
    doc.add(new Field("description",
                      "Illidium Space Modulator",
                      Field.Store.YES,
                      Field.Index.ANALYZED));
    writer.addDocument(doc);

    writer.close();

    searcher = new IndexSearcher(directory);
  }

  public void testTermQuery() throws Exception {
    Query query = new TermQuery(new Term("partnum", "Q36"));  //2
    assertEquals(1, getHitCount(searcher, query)); //3
  }

  public void testBasicQueryParser() throws Exception {
    Query query = new QueryParser("description",                //4 
                                  new SimpleAnalyzer()).parse("partnum:Q36 AND SPACE");
    assertEquals("note Q36 -> q",
                 "+partnum:q +space", query.toString("description"));    //5
    assertEquals("doc not found :(", 0, getHitCount(searcher, query));
  }

/*
#1 Field not analyzed
#2 No analysis here
#3 Document found as expected
#4 QueryParser analyzes each term and phrase
#5 toString() method
*/

  public void testPerFieldAnalyzer() throws Exception {
    PerFieldAnalyzerWrapper analyzer = new PerFieldAnalyzerWrapper(
                                              new SimpleAnalyzer());
    analyzer.addAnalyzer("partnum", new KeywordAnalyzer());  //1  

    Query query = new QueryParser("description", analyzer).parse(
                "partnum:Q36 AND SPACE");

    assertEquals("Q36 kept as-is",
              "+partnum:Q36 +space", query.toString("description"));  
    assertEquals("doc found!", 1, getHitCount(searcher, query));       //2
  }

/*
#1 Apply KeywordAnalyzer only to partnum
#2 Document is found
*/
}
