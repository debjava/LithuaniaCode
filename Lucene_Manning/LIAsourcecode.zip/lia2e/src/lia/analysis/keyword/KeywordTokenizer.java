package lia.analysis.keyword;

import org.apache.lucene.util.AttributeSource;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.tokenattributes.TermAttribute;
import java.io.IOException;
import java.io.Reader;

/**
 * "Tokenizes" the entire stream as a single token.
 */
public class KeywordTokenizer extends Tokenizer {
  
  private static final int DEFAULT_BUFFER_SIZE = 256;

  private boolean done;
  private TermAttribute termAttr;

  public KeywordTokenizer(Reader input) {
    this(input, DEFAULT_BUFFER_SIZE);
    termAttr = (TermAttribute) addAttribute(TermAttribute.class);
  }

  public KeywordTokenizer(Reader input, int bufferSize) {
    super(input);
    this.done = false;
  }

  public boolean incrementToken() throws IOException {
    if (!done) {
      done = true;
      int upto = 0;
      clearAttributes();
      char[] buffer = new char[10];
      while (true) {
        final int length = input.read(buffer, upto, buffer.length-upto);
        if (length == -1) break;
        upto += length;
        char[] newBuffer = new char[2*buffer.length];
        System.arraycopy(buffer, 0, newBuffer, 0, buffer.length);
        buffer = newBuffer;
      }
      termAttr.setTermBuffer(buffer, 0, upto);
      return true;
    }
    return false;
  }

  public void reset(Reader input) throws IOException {
    super.reset(input);
    this.done = false;
  }
}
