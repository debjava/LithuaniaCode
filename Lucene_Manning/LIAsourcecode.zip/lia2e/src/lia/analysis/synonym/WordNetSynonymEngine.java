package lia.analysis.synonym;

import org.apache.lucene.document.Document;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.RAMDirectory;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

import lia.common.AllDocCollector;

public class WordNetSynonymEngine implements SynonymEngine {
  RAMDirectory directory;
  IndexSearcher searcher;

  public WordNetSynonymEngine(File index) throws IOException {
    FSDirectory fsDir = new FSDirectory(index, null);
    directory = new RAMDirectory(fsDir);  // #1
    fsDir.close();
    searcher = new IndexSearcher(directory);
  }

  public String[] getSynonyms(String word) throws IOException {

    ArrayList synList = new ArrayList();

    AllDocCollector collector = new AllDocCollector();

    searcher.search(new TermQuery(new Term("word", word)), collector);

    List<ScoreDoc> hits = collector.getHits();
    Iterator<ScoreDoc> it = hits.iterator();
    while(it.hasNext()) {
      ScoreDoc hit = it.next();
      Document doc = searcher.getIndexReader().document(hit.doc);

      String[] values = doc.getValues("syn");

      for (int j = 0; j < values.length; j++) {
        synList.add(values[j]);
      }
    }

    return (String[]) synList.toArray(new String[0]);
  }
}

/*
#1 Load synonym index into RAM for rapid access
*/