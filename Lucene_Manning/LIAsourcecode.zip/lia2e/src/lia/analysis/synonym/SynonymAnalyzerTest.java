package lia.analysis.synonym;

import java.io.IOException;

import lia.analysis.AnalyzerUtils;
import lia.common.LiaTestCase;

import org.apache.lucene.util.AttributeSource;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.PhraseQuery;
import org.apache.lucene.queryParser.QueryParser;

public class SynonymAnalyzerTest extends LiaTestCase {
  private RAMDirectory directory;
  private IndexSearcher searcher;
  private static SynonymAnalyzer synonymAnalyzer =
                      new SynonymAnalyzer(new MockSynonymEngine());

  public void setUp() throws Exception {
    super.setUp();
    directory = new RAMDirectory();

    IndexWriter writer = new IndexWriter(directory,
                                         synonymAnalyzer,  //#1  
                                         true,
                                         IndexWriter.MaxFieldLength.LIMITED);
    Document doc = new Document();
    doc.add(new Field("content",
                      "The quick brown fox jumps over the lazy dogs",
                      Field.Store.YES,
                      Field.Index.ANALYZED));  //#2
    writer.addDocument(doc);
                                  
    writer.close();

    searcher = new IndexSearcher(directory);
  }

  public void tearDown() throws Exception {
    super.tearDown();
    searcher.close();
  }

  public void testJumps() throws Exception {
    AttributeSource[] tokens =
      AnalyzerUtils.tokensFromAnalysis(synonymAnalyzer , "jumps");     //|#1
                                                      
    AnalyzerUtils.assertTokensEqual(tokens,
                                    new String[] {"jumps", "hops", "leaps"});   //|#2

    // ensure synonyms are in the same position as the original
    assertEquals("jumps", 1, AnalyzerUtils.getPositionIncrement(tokens[0]));
    assertEquals("hops", 0, AnalyzerUtils.getPositionIncrement(tokens[1]));
    assertEquals("leaps", 0, AnalyzerUtils.getPositionIncrement(tokens[2]));
  }

 	
  public void testSearchByAPI() throws Exception {

    TermQuery tq = new TermQuery(new Term("content", "hops"));  //#3 
    assertEquals(1, getHitCount(searcher, tq));

    PhraseQuery pq = new PhraseQuery();    //#4
    pq.add(new Term("content", "fox"));    //#4
    pq.add(new Term("content", "hops"));   //#4  
    assertEquals(1, getHitCount(searcher, pq));
  }

  /*
#1 Analyze with SynonymAnalyzer
#2 Index single document
#3 Search for "hops"
#4 Search for "fox hops"
  */

  public void testWithQueryParser() throws Exception {
    Query query = new QueryParser("content",
                                  synonymAnalyzer).parse("\"fox jumps\"");
    // The issue demonstrated in LIA1 has been resolved in Lucene 1.9+
    assertEquals("Fixed in 1.9+", 1, getHitCount(searcher, query));

    query = new QueryParser("content",
                            new StandardAnalyzer()).parse("\"fox jumps\"");
    assertEquals("*whew*", 1, getHitCount(searcher, query));
  }

  public static void main(String[] args) throws Exception {
    Query query = new QueryParser("content",
                     synonymAnalyzer).parse("\"fox jumps\"");

    System.out.println("\"fox jumps\" parses to " +
                                         query.toString("content"));

    System.out.println("From AnalyzerUtils.tokensFromAnalysis: ");
    AnalyzerUtils.displayTokens(synonymAnalyzer,
                                     "\"fox jumps\"");
  }

  public void testWithQueryParser1() throws Exception {
    Query query = new QueryParser("content",
                                  synonymAnalyzer).parse(
                                                         "\"fox jumps\"");
                                    
    //assertEquals("!!!! what?!", 0, getHitCount(searcher, query));  //#1 
    assertEquals("!!!! what?!", 1, getHitCount(searcher, query));  //#1 
  }

  public void testWithQueryParser2() throws Exception {
    Query query = new QueryParser("content",
                                  new StandardAnalyzer()).parse(
                                                                "\"fox jumps\"");
    assertEquals("*whew*", 1, getHitCount(searcher, query));   //#2  
  }

  /*
#1 Analyzer can’t find document using phrase from original document
#2 StandardAnalyzer still finds document
  */
}
