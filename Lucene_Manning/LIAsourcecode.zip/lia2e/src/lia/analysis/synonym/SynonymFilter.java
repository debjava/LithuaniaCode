package lia.analysis.synonym;

import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.TokenFilter;
import org.apache.lucene.analysis.tokenattributes.TermAttribute;
import org.apache.lucene.util.AttributeSource;
import java.io.IOException;
import java.util.Stack;
import lia.analysis.AnalyzerUtils;

public class SynonymFilter extends TokenFilter {
  public static final String TOKEN_TYPE_SYNONYM = "SYNONYM";

  private Stack synonymStack;
  private SynonymEngine engine;
  private TermAttribute termAttr;

  public SynonymFilter(TokenStream in, SynonymEngine engine) {
    super(in);
    synonymStack = new Stack();  //|#1 
    termAttr = (TermAttribute) addAttribute(TermAttribute.class);
    this.engine = engine;
  }

  public boolean incrementToken() throws IOException {
    if (synonymStack.size() > 0) {       //#2
      AttributeSource syn = (AttributeSource) synonymStack.pop(); //#2
      syn.restoreState(this);             //#2
      return true;
    }

    if (!input.incrementToken())   //#3  
      return false;

    addAliasesToStack();  //#4 

    return true;       //#5 
  }

  private void addAliasesToStack() throws IOException {
    String[] synonyms = engine.getSynonyms(termAttr.term());   //#6
    if (synonyms == null) return;

    for (int i = 0; i < synonyms.length; i++) {            //#7
      AttributeSource synToken = captureState();
      AnalyzerUtils.setTerm(synToken, synonyms[i]);        //#7
      AnalyzerUtils.setType(synToken, TOKEN_TYPE_SYNONYM); //#7
      AnalyzerUtils.setPositionIncrement(synToken, 0);     //#8
      synonymStack.push(synToken);                         //#7
    }
  }
}

/*
#1 Synonym buffer
#2 Pop buffered synonyms
#3 Read next token
#4 Push synonyms of current token onto stack
#5 Return current token
#6 Retrieve synonyms
#7 Push synonyms onto stack
#8 Set position increment to zero
*/
