package lia.extsearch.sorting;

import org.apache.lucene.search.SortComparatorSource;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.SortField;
import org.apache.lucene.search.ScoreDocComparator;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.TermEnum;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.TermDocs;

import java.io.IOException;

public class DistanceComparatorSource
  implements SortComparatorSource {                   // #1
  private int x;
  private int y;

  public DistanceComparatorSource(int x, int y) {     // #2
    this.x = x;
    this.y = y;
  }

  public ScoreDocComparator newComparator(            // #3
      IndexReader reader, String fieldname) throws IOException {
    return new DistanceScoreDocLookupComparator(
        reader, fieldname, x, y);
  }

  private static class DistanceScoreDocLookupComparator  // #4
      implements ScoreDocComparator {
    private float[] distances;                        // #5

    public DistanceScoreDocLookupComparator(IndexReader reader,
               String fieldname, int x, int y) throws IOException {

      final TermEnum enumerator =
          reader.terms(new Term(fieldname, ""));
      distances = new float[reader.maxDoc()];
      if (distances.length > 0) {
        TermDocs termDocs = reader.termDocs();
        try {
          if (enumerator.term() == null) {
            throw new RuntimeException(
                "no terms in field " + fieldname);
          }
          do {                                        // #6
            Term term = enumerator.term();            // #6
            if (term.field() != fieldname) break;     // #6
            termDocs.seek(enumerator);                // #6
            while (termDocs.next()) {                 // #7
              String[] xy = term.text().split(",");   // #7
              int deltax = Integer.parseInt(xy[0]) - x;  // #7
              int deltay = Integer.parseInt(xy[1]) - y;  // #7

              distances[termDocs.doc()] = (float) Math.sqrt( // #7 #8
                  deltax * deltax + deltay * deltay); // #7 #8
            }                                         // #7
          } while (enumerator.next());                // #7
        } finally {
          termDocs.close();
        }
      }
    }

    public int compare(ScoreDoc i, ScoreDoc j) {          // #9
      if (distances[i.doc] < distances[j.doc]) return -1; // #9
      if (distances[i.doc] > distances[j.doc]) return 1;  // #9
      return 0;                                           // #9
    }

    public Comparable sortValue(ScoreDoc i) {             // #10
      return new Float(distances[i.doc]);                 // #10
    }                                                     // #10

    public int sortType() {
      return SortField.FLOAT;
    }
  }

  public String toString() {
    return "Distance from ("+x+","+y+")";
  }
}

/*
#1 Implement SortComparatorSource
#2 Give constructor base location
#3 newComparator
#4 ScoreDocComparator
#5 Array of distances
#6 Iterate over terms
#7 Iterate over documents containing current term
#8 Compute and store distance
#9 compare
#10 sortValue
*/

