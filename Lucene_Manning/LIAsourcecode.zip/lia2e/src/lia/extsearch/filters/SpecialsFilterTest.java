package lia.extsearch.filters;

import lia.common.LiaTestCase;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.WildcardQuery;
import org.apache.lucene.search.FilteredQuery;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.RangeQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.index.Term;

public class SpecialsFilterTest extends LiaTestCase {
  private Query allBooks;
  private IndexSearcher searcher;

  protected void setUp() throws Exception {
    super.setUp();

    allBooks = new RangeQuery("pubmonth",
                              "190001",
                              "200512",
                              true, true);
    searcher = new IndexSearcher(bookDirectory);
  }

  public void testCustomFilter() throws Exception {
    String[] isbns = new String[] {"0060812451", "0465026567"};

    SpecialsAccessor accessor = new MockSpecialsAccessor(isbns);
    Filter filter = new SpecialsFilter(accessor);
    TopDocs hits = searcher.search(allBooks, filter, 10);
    assertEquals("the specials", isbns.length, hits.totalHits);
  }

  public void testFilteredQuery() throws Exception {
    String[] isbns = new String[] {"0854402624"};  // Steiner     // #1

    SpecialsAccessor accessor = new MockSpecialsAccessor(isbns);
    Filter filter = new SpecialsFilter(accessor);

    WildcardQuery educationBooks =                                // #2
      new WildcardQuery(new Term("category", "*education*"));     // #2
    FilteredQuery edBooksOnSpecial =                              // #2
        new FilteredQuery(educationBooks, filter);                // #2

    TermQuery logoBooks =                                         // #3
        new TermQuery(new Term("subject", "logo"));               // #3

    BooleanQuery logoOrEdBooks = new BooleanQuery();                  // #4
    logoOrEdBooks.add(logoBooks, BooleanClause.Occur.SHOULD);         // #4
    logoOrEdBooks.add(edBooksOnSpecial, BooleanClause.Occur.SHOULD);  // #4

    TopDocs hits = searcher.search(logoOrEdBooks, 10);
    System.out.println(logoOrEdBooks.toString());
    assertEquals("Papert and Steiner", 2, hits.totalHits);
  }
  /*
#1 Rudolf Steiner's book
#2 All education books on special
#3 All books with "logo" in subject
#4 Combine queries
  */
}
