package lia.extsearch.perf;

import com.clarkware.profiler.Profiler;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.RangeQuery;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.document.DateTools;

import java.io.IOException;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * @author <b>Mike Clark</b>
 * @author Clarkware Consulting, Inc.
 */
public class Search {

  private IndexBuilder index;

  public Search() throws Exception {
    index = new IndexBuilder();
  }

  public TopDocs searchByTimestamp(Date begin, Date end)
      throws Exception {
    String beginTerm = 
        DateTools.dateToString(begin, DateTools.Resolution.MILLISECOND);
    String endTerm = 
        DateTools.dateToString(end, DateTools.Resolution.MILLISECOND);

    Query query = new RangeQuery("last-modified",
                                 beginTerm, endTerm,
                                 true, true);

    return newSearcher(
             index.byTimestampIndexDirName()).search(query, 10);
  }

  public TopDocs searchByDay(String begin, String end)
      throws Exception {

    Query query = new RangeQuery("last-modified", begin, end,
                                 true, true);

    return newSearcher(index.byDayIndexDirName()).search(query, 10);
  }

  public static Date janOneTimestamp() {
    Calendar firstDay = GregorianCalendar.getInstance();
    firstDay.set(2004, 0, 1); // Jan = 0
    return firstDay.getTime();
  }

  public static Date todayTimestamp() {
    return GregorianCalendar.getInstance().getTime();
  }

  public static String today() {
    SimpleDateFormat dateFormat =
        (SimpleDateFormat) SimpleDateFormat.getDateInstance();
    dateFormat.applyPattern("yyyyMMdd");
    return dateFormat.format(todayTimestamp());
  }

  private IndexSearcher newSearcher(String indexDirName)
      throws IOException {
    Directory indexDirectory = new FSDirectory(new File(indexDirName), null);
    return new IndexSearcher(indexDirectory);
  }

  public static void main(String args[]) throws Exception {

    Search s = new Search();

    //
    // Cache because it makes Lucene feel good
    //
    Profiler.begin("searchByTimestamp: 1");
    s.searchByTimestamp(Search.janOneTimestamp(),
        Search.todayTimestamp());
    Profiler.end("searchByTimestamp: 1");
    Profiler.begin("searchByDay: 1");
    s.searchByDay("20040101", Search.today());
    Profiler.end("searchByDay: 1");

    //
    // Search by timestamp
    //
    Profiler.begin("searchByTimestamp: 2");
    TopDocs hits = s.searchByTimestamp(Search.janOneTimestamp(),
                                       Search.todayTimestamp());
    System.out.println(hits.totalHits + " hits by timestamp");
    Profiler.end("searchByTimestamp: 2");

    //
    // Searby by day
    //
    Profiler.begin("searchByDay: 2");
    hits = s.searchByDay("20040101", Search.today());
    System.out.println(hits.totalHits + " hits by day");
    Profiler.end("searchByDay: 2");

    System.out.println("");
    Profiler.print();
  }
}
