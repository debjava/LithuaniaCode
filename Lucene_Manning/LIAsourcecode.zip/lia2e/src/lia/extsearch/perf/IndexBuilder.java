package lia.extsearch.perf;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.DateTools;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * @author <b>Mike Clark</b>
 * @author Clarkware Consulting, Inc.
 */
public class IndexBuilder {

  private String byTimestampIndexDirName;
  private String byDayIndexDirName;

  public IndexBuilder() throws Exception {

    String indexDirName = System.getProperty("perf.temp.dir");
    if (indexDirName == null) {
      throw new RuntimeException("Property 'perf.temp.dir' not defined!");
    }

    byTimestampIndexDirName = indexDirName + File.separator + "timestamp";
    byDayIndexDirName = indexDirName + File.separator + "day";
  }

  public String byTimestampIndexDirName() {
    return byTimestampIndexDirName;
  }

  public String byDayIndexDirName() {
    return byDayIndexDirName;
  }

  public void buildIndex(int size) throws Exception {
    buildIndexByTimestamp(byTimestampIndexDirName(), size);
    buildIndexByDay(byDayIndexDirName(), size);
  }

  public void buildIndexByTimestamp(String dirName, int size)
      throws Exception {

    IndexWriter writer = newIndexWriter(dirName);

    Calendar timestamp = GregorianCalendar.getInstance();
    timestamp.set(Calendar.DATE,                           // #1
                  timestamp.get(Calendar.DATE) - 1);       // #1
    for (int i = 0; i < size; i++) {
      timestamp.set(Calendar.SECOND,                       // #2
                    timestamp.get(Calendar.SECOND) + 1);   // #2
      String now = DateTools.dateToString(timestamp.getTime(),
                                          DateTools.Resolution.MILLISECOND);
      Document document = new Document();
      document.add(new Field("last-modified", now,
                             Field.Store.YES, Field.Index.NOT_ANALYZED));
      writer.addDocument(document);
    }

    writer.close();
  }
  /*
#1 Yesterday
#2 Increase 1 second
   */

  public void buildIndexByDay(String dirName, int size)
      throws Exception {

    IndexWriter writer = newIndexWriter(dirName);

    String today = Search.today();

    for (int i = 0; i < size; i++) {
      Document document = new Document();
      document.add(new Field("last-modified",
                             today, Field.Store.YES,
                             Field.Index.NOT_ANALYZED));
      writer.addDocument(document);
    }

    writer.close();
  }

  private IndexWriter newIndexWriter(String dirName)
      throws IOException {
    Directory indexDirectory = new FSDirectory(new File(dirName), null);
    IndexWriter writer =
        new IndexWriter(indexDirectory,
                        new StandardAnalyzer(),
                        IndexWriter.MaxFieldLength.LIMITED);
    return writer;
  }

  public static void main(String args[]) throws Exception {

    if (args.length != 1) {
      System.out.println("Usage: IndexBuilder <size>");
      System.exit(0);
    }

    IndexBuilder builder = new IndexBuilder();
    builder.buildIndex(Integer.parseInt(args[0]));
  }
}
