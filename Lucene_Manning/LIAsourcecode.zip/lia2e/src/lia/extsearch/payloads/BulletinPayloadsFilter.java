package lia.extsearch.payloads;

import java.io.IOException;

import org.apache.lucene.index.Payload;
import org.apache.lucene.analysis.TokenFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.PayloadAttribute;
import org.apache.lucene.analysis.tokenattributes.TermAttribute;
import org.apache.lucene.analysis.payloads.PayloadHelper;

public class BulletinPayloadsFilter extends TokenFilter {

  private TermAttribute termAtt;
  private PayloadAttribute payloadAttr;
  private boolean isBulletin;
  private Payload boostPayload;

  BulletinPayloadsFilter(TokenStream in, float warningBoost) {
    super(in);
    payloadAttr = (PayloadAttribute) addAttribute(PayloadAttribute.class);
    termAtt = (TermAttribute) addAttribute(TermAttribute.class);
    boostPayload = new Payload(PayloadHelper.encodeFloat(warningBoost));
  }

  void setIsBulletin(boolean v) {
    isBulletin = v;
  }

  public final boolean incrementToken() throws IOException {
    if (input.incrementToken()) {
      if (isBulletin && termAtt.term().equals("warning"))            // #1
        payloadAttr.setPayload(boostPayload);                        // #1
      else
        payloadAttr.clear();                                         // #2
      return true;
    } else
      return false;
  }
}

/*
  #1 If document is a bulletin, and term is warning,
  record payload boost
  #2 Clear payload to get no boost
*/
