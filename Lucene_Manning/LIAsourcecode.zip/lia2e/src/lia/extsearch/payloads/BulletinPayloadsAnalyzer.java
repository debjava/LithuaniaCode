package lia.extsearch.payloads;

import java.io.Reader;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.standard.StandardAnalyzer;

public class BulletinPayloadsAnalyzer extends Analyzer {
  private boolean isBulletin;
  private float boost;

  BulletinPayloadsAnalyzer(float boost) {
    this.boost = boost;
  }

  void setIsBulletin(boolean v) {
    isBulletin = v;
  }

  public TokenStream tokenStream(String fieldName, Reader reader) {
    BulletinPayloadsFilter stream = new BulletinPayloadsFilter(new StandardAnalyzer().tokenStream(fieldName, reader), boost);
    stream.setIsBulletin(isBulletin);
    return stream;
  }
}
