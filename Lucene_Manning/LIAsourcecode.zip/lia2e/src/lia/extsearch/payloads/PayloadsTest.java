package lia.extsearch.payloads;

import java.io.IOException;

import lia.common.LiaTestCase;

import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.payloads.BoostingTermQuery;

public class PayloadsTest extends LiaTestCase {

  Directory dir;
  IndexWriter writer;
  BulletinPayloadsAnalyzer analyzer;

  protected void setUp() throws Exception {
    super.setUp();
    TokenStream.setUseNewAPIDefault(true);
    dir = new RAMDirectory();
    analyzer = new BulletinPayloadsAnalyzer(5.0F);
    writer = new IndexWriter(dir, analyzer, IndexWriter.MaxFieldLength.LIMITED);
  }

  protected void tearDown() throws Exception {
    super.tearDown();
    writer.close();
  }

  void addDoc(String title, String contents) throws IOException {
    Document doc = new Document();
    doc.add(new Field("title",
                      title,
                      Field.Store.YES,
                      Field.Index.NO));
    doc.add(new Field("contents",
                      contents,
                      Field.Store.NO,
                      Field.Index.ANALYZED));
    analyzer.setIsBulletin(contents.startsWith("Bulletin:"));
    writer.addDocument(doc);
  }

  public void testBoostingTermQuery() throws Throwable {
    addDoc("Hurricane warning", "Bulletin: A hurricane warning was issued at 6 AM for the outer great banks");
    addDoc("Warning label maker", "The warning label maker is a delightful toy for your precocious six year old's warning needs");
    addDoc("Tornado warning", "Bulletin: There is a tornado warning for Worcester county until 6 PM today");

    writer.commit();

    IndexSearcher searcher = new IndexSearcher(dir);
    searcher.setSimilarity(new BoostingSimilarity());

    Term warning = new Term("contents", "warning");
    
    Query query1 = new TermQuery(warning);
    System.out.println("\nTermQuery results:");
    dumpHits(searcher.getIndexReader(),
             searcher.search(query1, 10));

    Query query2 = new BoostingTermQuery(warning);
    System.out.println("\nBoostingTermQuery results:");
    dumpHits(searcher.getIndexReader(),
             searcher.search(query2, 10));
  }
}
