package lia.common;

import junit.framework.TestCase;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.store.Directory;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.DateTools;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.TopDocCollector;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Filter;

import java.io.IOException;
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * LIA base class for test cases.
 */
public abstract class LiaTestCase extends TestCase {
  private String bookIndexDir = System.getProperty("index.dir");
  protected Directory bookDirectory;
  protected Directory directory;

  protected void setUp() throws Exception {
    bookDirectory = new FSDirectory(new File(bookIndexDir), null);
    directory = new RAMDirectory();
    TokenStream.setUseNewAPIDefault(true);
  }

  protected void tearDown() throws Exception {
    bookDirectory.close();
    directory.close();
  }

  /**
   * For troubleshooting
   */
  protected final void dumpHits(IndexReader reader, TopDocs hits) throws IOException {
    if (hits.totalHits == 0) {
      System.out.println("No hits");
    }

    for (int i=0; i < hits.totalHits; i++) {
      Document doc = reader.document(hits.scoreDocs[i].doc);
      System.out.println(hits.scoreDocs[i].score + ":" + doc.get("title"));
    }
  }

  public int getHitCount(IndexSearcher searcher, Query query) throws IOException {
    return searcher.search(query, 10).totalHits;
  }

  public int getHitCount(IndexSearcher searcher, Query query, Filter filter) throws IOException {
    return searcher.search(query, filter, 10).totalHits;
  }

  protected final void assertHitsIncludeTitle(IndexReader reader, TopDocs hits, String title)
    throws IOException {
    for (int i=0; i < hits.totalHits; i++) {
      Document doc = reader.document(hits.scoreDocs[i].doc);
      if (title.equals(doc.get("title"))) {
        assertTrue(true);
        return;
      }
    }

    fail("title '" + title + "' not found");
  }

  protected final String parseDate(String s) throws ParseException {
      return DateTools.dateToString(new SimpleDateFormat("yyyy-MM-dd").parse(s),DateTools.Resolution.MILLISECOND);
  }
}
