package lia.common;

import org.apache.lucene.ant.DocumentHandlerException;
import org.apache.lucene.ant.ConfigurableDocumentHandler;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class TestDataDocumentHandler implements ConfigurableDocumentHandler {
  private String basedir;

  public Document getDocument(File file) throws DocumentHandlerException {
    Properties props = new Properties();
    try {
      props.load(new FileInputStream(file));
    } catch (IOException e) {
      throw new DocumentHandlerException(e);
    }

    Document doc = new Document();

    // category comes from relative path below the base directory
    String category = file.getParent().substring(basedir.length());
    category = category.replace(File.separatorChar, '/');

    String isbn = props.getProperty("isbn");
    String title = props.getProperty("title");
    String author = props.getProperty("author");
    String url = props.getProperty("url");
    String subject = props.getProperty("subject");
    String pubmonth = props.getProperty("pubmonth");

    System.out.println(title + "\n" + author + "\n" + subject + "\n" + category + "\n---------");

    doc.add(new Field("isbn", isbn, Field.Store.YES, Field.Index.NOT_ANALYZED));
    doc.add(new Field("category", category, Field.Store.YES, Field.Index.NOT_ANALYZED));
    doc.add(new Field("title", title, Field.Store.YES, Field.Index.ANALYZED, Field.TermVector.WITH_POSITIONS_OFFSETS));

    // split multiple authors into unique field instances
    String[] authors = author.split(",");
    for (int i = 0; i < authors.length; i++) {
      doc.add(new Field("author", authors[i], Field.Store.YES, Field.Index.NOT_ANALYZED, Field.TermVector.WITH_POSITIONS_OFFSETS));
    }

    doc.add(new Field("url", url, Field.Store.YES, Field.Index.NO));
    doc.add(new Field("subject", subject, Field.Store.NO, Field.Index.ANALYZED, Field.TermVector.WITH_POSITIONS_OFFSETS));

    doc.add(new Field("pubmonth", pubmonth, Field.Store.YES, Field.Index.NOT_ANALYZED));

    doc.add(new Field("contents",
                      aggregate(new String[] {title, subject, author, category}), Field.Store.NO, Field.Index.ANALYZED, Field.TermVector.WITH_POSITIONS_OFFSETS));

    return doc;
  }

  private String aggregate(String[] strings) {
    StringBuffer buffer = new StringBuffer();

    for (int i = 0; i < strings.length; i++) {
      buffer.append(strings[i]);
      buffer.append(" ");
    }

    return buffer.toString();
  }

  public void configure(Properties props) {
    this.basedir = props.getProperty("basedir");
  }
}
