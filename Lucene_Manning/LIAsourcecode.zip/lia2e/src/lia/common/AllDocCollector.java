package lia.common;
import java.util.List;
import java.util.ArrayList;

import org.apache.lucene.search.HitCollector;
import org.apache.lucene.search.ScoreDoc;

/**
 * Gathers all documents from a search.
 */

public class AllDocCollector extends HitCollector {
  List<ScoreDoc> docs = new ArrayList<ScoreDoc>();
  public void collect(int doc, float score) {
    if (score > 0.0f) {
      docs.add(new ScoreDoc(doc, score));
    }
  }

  public void reset() {
    docs.clear();
  }

  public List<ScoreDoc> getHits() {
    return docs;
  }
}