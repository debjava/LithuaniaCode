package lia.indexing;

import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;

import java.io.IOException;

public class DocumentDeleteTest extends BaseIndexingTestCase {

  public void testDeleteBeforeIndexMerge() throws IOException {
    IndexWriter writer = new IndexWriter(directory, getAnalyzer(), IndexWriter.MaxFieldLength.LIMITED);
    assertEquals(2, writer.numDocs()); //1   
    writer.deleteDocuments(new Term("id", "1"));  //2
    writer.commit();
    assertTrue(writer.hasDeletions());    //3
    assertEquals(2, writer.maxDoc());    //4
    assertEquals(1, writer.numDocs());   //4   
    writer.close();
  }

  public void testDeleteAfterIndexMerge() throws IOException {
    IndexWriter writer = new IndexWriter(directory, getAnalyzer(), IndexWriter.MaxFieldLength.LIMITED);
    assertEquals(2, writer.numDocs());
    writer.deleteDocuments(new Term("id", "1"));
    writer.optimize();                //5
    writer.commit();
    assertFalse(writer.hasDeletions());
    assertEquals(1, writer.maxDoc());  //6
    assertEquals(1, writer.numDocs()); //6    
    writer.close();
  }
}

/*
#1 2 docs in the index
#2 Delete first document
#3 Index contains deletions
#4 1 indexed document, 1 deleted document
#5 Optimize compacts deletes
#6 1 indexed document, 0 deleted documents
*/