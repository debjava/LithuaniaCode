package lia.indexing;

import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.analysis.SimpleAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.store.Directory;

import java.io.IOException;

public class FieldLengthTest extends BaseIndexingTestCase {

  private String[] keywords = {"1", "2"};
  private String[] unindexed = {"Netherlands", "Italy"};
  private String[] unstored = {"Amsterdam has lots of bridges",
                               "Venice has lots of canals"};
  private String[] text = {"Amsterdam", "Venice"};

  public void testFieldSize() throws IOException {
    addDocuments(directory, 10);    //1   
    assertEquals(1, getHitCount("contents", "bridges"));  //2   

    addDocuments(directory, 1);    //3  
    assertEquals(0, getHitCount("contents", "bridges"));   //4  
  }

  private void addDocuments(Directory dir, int maxFieldLength)
    throws IOException {
    IndexWriter writer = new IndexWriter(dir,
                                         new SimpleAnalyzer(),
                                         true,
                                         IndexWriter.MaxFieldLength.LIMITED);
    writer.setMaxFieldLength(maxFieldLength);    //5  
    for (int i = 0; i < keywords.length; i++) {
      Document doc = new Document();
      doc.add(new Field("id", keywords[i], Field.Store.YES, Field.Index.NOT_ANALYZED));
      doc.add(new Field("country", unindexed[i], Field.Store.YES, Field.Index.NO));
      doc.add(new Field("contents", unstored[i], Field.Store.NO, Field.Index.ANALYZED));
      doc.add(new Field("city", text[i], Field.Store.YES, Field.Index.ANALYZED));
      writer.addDocument(doc);
    }
    writer.optimize();
    writer.close();
  }
}

/*
#1 Index first 10 terms of each Field
#2 Term bridges was indexed
#3 Index first term of each Field
#4 Term bridges wasn't indexed
#5 Set number of terms to index
*/