package lia.indexing;

import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.Term;

import java.io.IOException;

public class DocumentUpdateTest extends BaseIndexingTestCase {

  public void testUpdate() throws IOException {

    assertEquals(1, getHitCount("city", "Amsterdam"));

    IndexWriter writer = new IndexWriter(directory, getAnalyzer(), IndexWriter.MaxFieldLength.LIMITED);

    Document doc = new Document();                   //1            
    doc.add(new Field("id", "1",
                      Field.Store.YES,
                      Field.Index.NOT_ANALYZED));    //1
    doc.add(new Field("country", "Netherlands",
                      Field.Store.YES,
                      Field.Index.NO));              //1  
    doc.add(new Field("contents",                    
                      "Amsterdam has lots of bridges",
                      Field.Store.NO,
                      Field.Index.ANALYZED));       //1
    doc.add(new Field("city", "Haag",
                      Field.Store.YES,
                      Field.Index.ANALYZED));       //1

    writer.updateDocument(new Term("id", "1"),
                          doc);                      //2    
    writer.expungeDeletes();                         //3
    writer.close();

    assertEquals(0, getHitCount("city", "Amsterdam"));//4   
    assertEquals(1, getHitCount("city", "Haag"));     //5  
  }

  protected Analyzer getAnalyzer() {
    return new WhitespaceAnalyzer();
  }
}

/*
#1 Create new document with "Haag" in city field
#2 Replace original document with new version
#3 Remove bytes consumed by deleted document
#4 Verify old document is gone
#5 Verify new document is indexed
*/
