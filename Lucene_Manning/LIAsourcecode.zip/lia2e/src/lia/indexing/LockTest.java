package lia.indexing;

import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.analysis.SimpleAnalyzer;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.LockObtainFailedException;

import junit.framework.TestCase;
import java.io.IOException;
import java.io.File;

public class LockTest extends TestCase {

  private Directory dir;

  protected void setUp() throws IOException {
    String indexDir =
      System.getProperty("java.io.tmpdir", "tmp") +
      System.getProperty("file.separator") + "index";
    dir = new FSDirectory(new File(indexDir), null);
  }
  public void testWriteLock() throws IOException {
    IndexWriter writer1 = null;
    IndexWriter writer2 = null;

    try {
      writer1 = new IndexWriter(dir, new SimpleAnalyzer(),
                                IndexWriter.MaxFieldLength.LIMITED);
      writer2 = new IndexWriter(dir, new SimpleAnalyzer(),
                                IndexWriter.MaxFieldLength.LIMITED);
      fail("We should never reach this point");
    }
    catch (LockObtainFailedException e) {
      e.printStackTrace();   //#1   
    }
    finally {
      IndexWriter.unlock(dir);
      writer1.close();
      assertNull(writer2);
    }
  }
}

/*
#1 Expected exception: only one IndexWriter allowed on single index
*/
