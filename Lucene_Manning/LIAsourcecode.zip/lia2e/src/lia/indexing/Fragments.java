package lia.indexing;

import java.util.Date;
import java.io.IOException;

import org.apache.lucene.document.DateTools;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Document;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.index.IndexWriter;

/** Just to test the code compiles. */
class Fragments {

  public static void indexNumbersMethod() {
    // START
    new Field("size", "4096", Field.Store.YES, Field.Index.NOT_ANALYZED);
    new Field("price", "10.99", Field.Store.YES, Field.Index.NOT_ANALYZED);
    new Field("author", "Arthur C. Clark", Field.Store.YES, Field.Index.NOT_ANALYZED);
    // END
  }

  public static final String COMPANY_DOMAIN = "example.com";
  public static final String BAD_DOMAIN = "yucky-domain.com";

  private String getSenderEmail() {
    return "bob@smith.com";
  }

  private String getSenderName() {
    return "Bob Smith";
  }

  private String getSenderDomain() {
    return COMPANY_DOMAIN;
  }

  private String getSubject() {
    return "Hi there Lisa";
  }

  private String getBody() {
    return "I don't have much to say";
  }

  private boolean isImportant(String lowerDomain) {
    return lowerDomain.endsWith(COMPANY_DOMAIN);
  }

  private boolean isUnimportant(String lowerDomain) {
    return lowerDomain.endsWith(BAD_DOMAIN);
  }

  public void docBoostMethod() throws IOException {

    Directory dir = new RAMDirectory();
    IndexWriter writer = new IndexWriter(dir, new StandardAnalyzer(), IndexWriter.MaxFieldLength.LIMITED);

    // START
    Document doc = new Document();
    String senderEmail = getSenderEmail();
    String senderName = getSenderName();
    String subject = getSubject();
    String body = getBody();
    doc.add(new Field("senderEmail", senderEmail,
                      Field.Store.YES,
                      Field.Index.NOT_ANALYZED));
    doc.add(new Field("senderName", senderName,
                      Field.Store.YES,
                      Field.Index.ANALYZED));
    doc.add(new Field("subject", subject,
                      Field.Store.YES,
                      Field.Index.ANALYZED));
    doc.add(new Field("body", body,
                      Field.Store.NO,
                      Field.Index.ANALYZED));
    String lowerDomain = getSenderDomain().toLowerCase();
    if (isImportant(lowerDomain)) {
      doc.setBoost(1.5F);     //1  
    }
    else if (isUnimportant(lowerDomain)) {
      doc.setBoost(0.1F);    //2  
    }
    writer.addDocument(doc);
    // END
    writer.close();

    /*
      #1 Good domain boost factor: 1.5
      #2 Bad domain boost factor: 0.1
    */
  }

  public void fieldBoostMethod() throws IOException {

    String senderName = getSenderName();
    String subject = getSubject();

    // START
    Field senderNameField = new Field("senderName", senderName,
                                      Field.Store.YES,
                                      Field.Index.ANALYZED);
    Field subjectField = new Field("subject", subject,
                                   Field.Store.YES,
                                   Field.Index.ANALYZED);
    subjectField.setBoost(1.2F);
    // END
  }

  public void dateMethod() {
    Document doc = new Document();
    doc.add(new Field("indexDate",
                      DateTools.dateToString(new Date(), DateTools.Resolution.DAY),
                      Field.Store.YES,
                      Field.Index.NOT_ANALYZED));
  }
}

