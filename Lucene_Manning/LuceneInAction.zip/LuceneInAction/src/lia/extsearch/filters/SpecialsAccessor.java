package lia.extsearch.filters;

public interface SpecialsAccessor {
  String[] isbns();
}
