// JNDI imports
import javax.naming.InitialContext;
import javax.naming.NamingException;

// JMS imports
import javax.jms.Message;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueConnection;
import javax.jms.QueueSession;
import javax.jms.QueueSender;
import javax.jms.QueueReceiver;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.JMSException;

public class PointToPoint
{
	public PointToPoint()
	{
		try
		{
			final InitialContext context = new InitialContext();
			
			// Lookup the queue connection factory from the
			// initial context.
			// final QueueConnectionFactory qcf = 
			
			// Create a new queue connection from the queue
			// connection factory.
			// final QueueConnection conn = 
			
			// Start the connection
			
			// Create a new queue session from the queue
			// connection. The session should not be transacted
			// and should use automatic message acknowledgement.
			// final QueueSession session = 
			
			// Lookup the queue to be used to send and receive
			// messages from the initial context.
			// final Queue q = 
			
			// Create a new queue sender using the queue session.
			// The sender should be created to send messages to
			// the queue q.
			// final QueueSender sender = 
			
			// Create a text message using the queue session.
			// Initialize the message's data to a String of your
			// choice.
			// final TextMessage sentMessage = 
			
			// Send the sentMessage object using the queue sender.
			
			// Create a new queue receiver using the queue session.
			// The queue receiver should be created to receive
			// messages from the queue q.
			// final QueueReceiver receiver = 
			
			// Use the queue receiver to receive the message that
			// was sent previously.
			// final Message receivedMessage = 
			
			// Output the received message to System.out
		}
		catch (NamingException ne)
		{
			ne.printStackTrace();	
		}
		catch (JMSException jmse)
		{
			Exception linkedException = jmse.getLinkedException();
			
			if (linkedException != null)
			{
				linkedException.printStackTrace();
			}
			
			jmse.printStackTrace();	
		}
	}
	
	public static void main(String[] args)
	{
		new PointToPoint();
	}
}
