package com.ibm.toolbelt;

/***************************************************************************/
/*                                                                         */
/* (c) Copyright IBM Corp. 1999  All rights reserved.                      */
/*                                                                         */
/* This sample program is owned by International Business Machines         */
/* Corporation or one of its subsidiaries ("IBM") and is copyrighted       */
/* and licensed, not sold.                                                 */
/*                                                                         */
/* You may copy, modify, and distribute this sample program in any         */
/* form without payment to IBM, for any purpose including developing,      */
/* using, marketing or distributing programs that include or are           */
/* derivative works of the sample program.                                 */
/*                                                                         */
/* The sample program is provided to you on an "AS IS" basis, without      */
/* warranty of any kind.  IBM HEREBY  EXPRESSLY DISCLAIMS ALL WARRANTIES,  */
/* EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED   */
/* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.     */
/* Some jurisdictions do not allow for the exclusion or limitation of      */
/* implied warranties, so the above limitations or exclusions may not      */
/* apply to you.  IBM shall not be liable for any damages you suffer as    */
/* a result of using, modifying or distributing the sample program or      */
/* its derivatives.                                                        */
/*                                                                         */
/* Each copy of any portion of this sample program or any derivative       */
/* work,  must include the above copyright notice and disclaimer of        */
/* warranty.                                                               */
/*                                                                         */
/***************************************************************************/

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.ibm.mqbind.*;			//include the MQ bindings package


/**
 * This type was created in VisualAge.
 */
public class BillingAddressServlet extends javax.servlet.http.HttpServlet {
	
	private String qManager = "NC.QManager";	//name of queue manager to connect to

	private MQQueueManager qMgr;				//define a queue manager object
/**
 * BillingAddressServlet constructor comment.
 */
public BillingAddressServlet() {
	super();
}
/**
 * This method was created in VisualAge.
 */
public void destroy() {
	System.out.println("In destroy()");
	try
	{
		//Disconnect from the queue manager
		qMgr.disconnect();
	}
	catch (MQException ex)
	{
		System.out.println("An MQ error occourred: Completion code " + ex.completionCode +
													  " Reason code" + ex.reasonCode);
	}
	
	System.out.println("Out of destroy()");				
}
/**
 * This method was created in VisualAge.
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @exception javax.servlet.ServletException The exception description.
 * @exception java.io.IOException The exception description.
 */
public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

	String tempAddress = "Input information is";
	res.setContentType("text/plain");
	PrintWriter out = res.getWriter();

	if ("application/x-www-form-urlencoded".equals(req.getContentType())) {
		System.out.println("In doPost()");
		Enumeration enum = req.getParameterNames();
		while (enum.hasMoreElements()) {
			String name = (String) enum.nextElement();
			String values = req.getParameter(name);
			if(values != null) {
				tempAddress = tempAddress + "; " + name + ": " + values;
			}
			
		}
		System.out.println(tempAddress);
				
		try {
				//calling to put the order
				System.out.println("Calling putOrder()");
		      	putOrder(tempAddress);

		      	//calling orderUpdateStatus to get the conformation back
				System.out.println("Calling orderUpdateStatus()");
				String msgText = orderUpdateStatus();
				
				//Instantiate the bean and calling the JSP
				System.out.println("Instantiate the bean and calling the JSP");
				performTask(req, res, msgText);
				
				
						
			}
			catch (Exception ex)
			{
				System.out.println("Exception caught in doPost()");
				ex.printStackTrace();
			}	
		
	}
		
	System.out.println("Out of doPost()");				
	
}
/**
 * This method was created in VisualAge.
 * @param config javax.servlet.ServletConfig
 * @exception javax.servlet.ServletException The exception description.
 */
public void init(ServletConfig config) throws ServletException {
		super.init(config);
		try {
				//Create a connection to the queue manager
				System.out.println("Create a connection to the queue manager");
				qMgr = new MQQueueManager("NC.QManager");
				System.out.println("Connection created in init()");
				
			}
			catch (MQException ex)
			{
				System.out.println("An MQ error occourred in init(): Completion code " + ex.completionCode +
															  " Reason code" + ex.reasonCode);
				try {
					if (qMgr != null)
					//Disconnect from the queue manager
					qMgr.disconnect();
				}
				catch (MQException e)
				{
					System.out.println("An MQ error occourred in init() while disconnecting: Completion code " + e.completionCode +
															  " Reason code" + e.reasonCode);
				}
			}
			
}
/**
 * This method was created in VisualAge.
 */
public String orderUpdateStatus() {
	String msgText = null;
	try {
		System.out.println("In orderUpdateStatus()");
		
		int openOptions = MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_OUTPUT;
	
		//Specify the queue that we wish to open, and the open options.
		System.out.println("Specifying the queue that we wish to open, and the open options.");
			
				
		MQQueue ncOrderUpdateQ = qMgr.accessQueue("NC.OrderCreateQ",
		                   						openOptions,
		                   						qManager,      
		                   						null,             // no dynamic q name
		                   						null);            // no alternate user id

		//create a new get the message
		MQMessage retrievedMessage = new MQMessage();
		
		retrievedMessage.messageId = MQC.MQMI_NONE;
				
		//set the get message options
		MQGetMessageOptions gmo = new MQGetMessageOptions();
		
		//get the message off the queue
		ncOrderUpdateQ.get(retrievedMessage, gmo);
						
		//Display the message
		//msgText = retrievedMessage.readString(retrievedMessage.getMessageLength());  //for NC.UpdateQ
		msgText = retrievedMessage.readUTF();		// for NC.OrderCreateQ
		System.out.println("The address is: " + msgText);

		//Close the queue
		ncOrderUpdateQ.close();

		
						
	}
	catch (MQException ex)
	{
		System.out.println("An MQ error occourred: Completion code " + ex.completionCode +
													  " Reason code" + ex.reasonCode);
		System.out.println("disconnecting in orderUpdateStatus()");
		try {
			if (qMgr != null)
			//Disconnect from the queue manager
			qMgr.disconnect();
		}
		catch (MQException e)
		{
			System.out.println("An MQ error occourred while disconnecting in orderUpdateStatus(): Completion code " + e.completionCode +
														  " Reason code" + e.reasonCode);
		}
				
				
	}
	catch (java.io.IOException ex)
	{
		System.out.println("An error occourred while writing to the message buffer: " + ex);
		System.out.println("disconnecting in orderUpdateStatus()");
		try {
			if (qMgr != null)
			//Disconnect from the queue manager
			qMgr.disconnect();
		}
		catch (MQException ep)
		{
			System.out.println("An MQ error occourred while disconnecting in orderUpdateStatus(): Completion code " + ep.completionCode +
															  " Reason code" + ep.reasonCode);
		}
	}
	return(msgText);
}
/**
 * This method was created in VisualAge.
 * @param request javax.servlet.http.HttpServletRequest
 * @param response javax.servlet.http.HttpServletResponse
 */
public void performTask(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response, java.lang.String returnMessage) {
	System.out.println("in performTask()");	
	try 
		{
			// instantiate the bean
			BillingAddressBean myBillingAddressBean = new BillingAddressBean();
			// set the return message in the bean
			myBillingAddressBean.setMQReturnMessage(returnMessage);
			// store the bean in the request so it can be accessed by pages which are accessed with callPage()
			((com.sun.server.http.HttpServiceRequest)request).setAttribute("BillingAddressBean", myBillingAddressBean);
			// Call the output page.
			((com.sun.server.http.HttpServiceResponse)response).callPage("/AddressOutputPage.jsp", request);
			
		}
		catch (Exception ex)
		{
			System.out.println("Exception caught in performTask()");
			ex.printStackTrace();
		}
}
/**
 * This method was created in VisualAge.
 */
public void putOrder(String tempAddress) {
	try {
		System.out.println("In putOrder()");
		int openOptions = MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_OUTPUT;
	
		//Specify the queue that we wish to open, and the open options.
		System.out.println("Specifying the queue that we wish to open, and the open options.");
			
		MQQueue ncOrderDataQ = qMgr.accessQueue("NC.OrderCreateQ",
		                   						openOptions,
		                   						qManager,      
		                   						null,             // no dynamic q name
		                   						null);            // no alternate user id

					
		//Define a MQ message
		System.out.println("Define a MQ message");
		MQMessage customerAddress = new MQMessage();
												
		System.out.println("tempAddress =" + tempAddress);
					
		customerAddress.writeUTF(tempAddress);
		
		//specify the message options
		MQPutMessageOptions pmo = new MQPutMessageOptions();

		//put the message on the queue
		ncOrderDataQ.put(customerAddress, pmo);

		System.out.println("Put message done");
				
		//Close the queue
		ncOrderDataQ.close();							
				
		}
		catch (MQException ex)
		{
				System.out.println("An MQ error occourred: Completion code " + ex.completionCode +
															  " Reason code" + ex.reasonCode);
				System.out.println("disconnecting in doPost()");
				try {
					if (qMgr != null)
					//Disconnect from the queue manager
					qMgr.disconnect();
				}
				catch (MQException e)
				{
					System.out.println("An MQ error occourred while disconnecting in doPost(): Completion code " + e.completionCode +
															  " Reason code" + e.reasonCode);
				}
				
				
		}
		catch (java.io.IOException ex)
		{
				System.out.println("An error occourred while writing to the message buffer: " + ex);
				System.out.println("disconnecting in doPost()");
				try {
					if (qMgr != null)
					//Disconnect from the queue manager
					qMgr.disconnect();
				}
				catch (MQException ep)
				{
					System.out.println("An MQ error occourred while disconnecting in doPost(): Completion code " + ep.completionCode +
															  " Reason code" + ep.reasonCode);
				}
		}
					
		
		System.out.println("Out of putOrder()");
				
}
}