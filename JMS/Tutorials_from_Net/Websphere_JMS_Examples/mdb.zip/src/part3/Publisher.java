// JNDI imports
import javax.naming.InitialContext;
import javax.naming.NamingException;

// JMS imports
import javax.jms.TextMessage;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicConnection;
import javax.jms.TopicSession;
import javax.jms.TopicPublisher;
import javax.jms.Topic;
import javax.jms.Session;
import javax.jms.JMSException;

public class Publisher
{
    public Publisher()
    {
        try
        {
            final InitialContext context = new InitialContext();

            // Lookup the topic connection factory
            // from the initial context.
            final TopicConnectionFactory tcf = (TopicConnectionFactory) context.lookup("TCF");

            // Create a new topic connection from the topic
            // connection factory.
            final TopicConnection conn = tcf.createTopicConnection();

            // Start the connection	
            conn.start();       

            // Create a new topic session from the topic
            // connection. The session should not be transacted
            // and should use automatic message acknowledgement.
            final TopicSession session = conn.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);

            // Lookup the topic that we are to subscribe to
            // from the initial context.
            final Topic topic = (Topic) context.lookup("Topic");

            // Create a new topic publisher using
            // the topic session. The publisher should
            // be created to publish to Topic topic.
            final TopicPublisher publisher = session.createPublisher(topic);

            // Using the topic session create a new
            // text message to publish
            final TextMessage message = session.createTextMessage("My first published message");

            // Using the publisher publish the text
            // message that's just been created
            publisher.publish(message);

            // Output to System.out to indicate that the
            // message has been published successfully
            System.out.println("Message published");
        }
        catch (NamingException ne)
        {
            ne.printStackTrace();   
        }
        catch (JMSException jmse)
        {
            Exception linkedException = jmse.getLinkedException();

            if (linkedException != null)
            {
                linkedException.printStackTrace();
            }

            jmse.printStackTrace(); 
        }
    }

    public static void main(String[] args)
    {
        new Publisher();
    }
}
