// JNDI imports
import javax.naming.InitialContext;
import javax.naming.NamingException;

// JMS imports
import javax.jms.TextMessage;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicConnection;
import javax.jms.TopicSession;
import javax.jms.TopicPublisher;
import javax.jms.Topic;
import javax.jms.Session;
import javax.jms.JMSException;

public class Publisher
{
    public Publisher()
    {
        try
        {
            final InitialContext context = new InitialContext();

            // Lookup the topic connection factory
            // from the initial context.
            // final TopicConnectionFactory tcf = 

            // Create a new topic connection from the topic
            // connection factory.
            // final TopicConnection conn = 

            // Start the connection			

            // Create a new topic session from the topic
            // connection. The session should not be transacted
            // and should use automatic message acknowledgement.
            // final TopicSession session = 

            // Lookup the topic that we are to publish to
            // from the initial context.
            // final Topic topic = 

            // Create a new topic publisher using
            // the topic session. The publisher should
            // be created to publish to Topic topic.
            // final TopicPublisher publisher =

            // Using the topic session create a new
            // text message to publish
            // final TextMessage message = 

            // Using the publisher publish the text
            // message that's just been created

            // Output to System.out to indicate that the
            // message has been published successfully

        }
        catch (NamingException ne)
        {
            ne.printStackTrace();   
        }
        catch (JMSException jmse)
        {
            Exception linkedException = jmse.getLinkedException();

            if (linkedException != null)
            {
                linkedException.printStackTrace();
            }

            jmse.printStackTrace(); 
        }
    }

    public static void main(String[] args)
    {
        new Publisher();
    }
}
