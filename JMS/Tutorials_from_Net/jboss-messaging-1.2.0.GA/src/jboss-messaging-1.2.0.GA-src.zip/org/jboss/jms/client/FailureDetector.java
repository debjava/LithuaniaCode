/**
 * JBoss, Home of Professional Open Source
 *
 * Distributable under LGPL license.
 * See terms of license at gnu.org.
 */
package org.jboss.jms.client;

/**
 * @author <a href="mailto:ovidiu@jboss.org">Ovidiu Feodorov</a>
 * @version <tt>$Revision: 1943 $</tt>
 * 
 * $Id: FailureDetector.java 1943 2007-01-10 12:56:46Z ovidiu.feodorov@jboss.com $
 */
public interface FailureDetector
{
}
