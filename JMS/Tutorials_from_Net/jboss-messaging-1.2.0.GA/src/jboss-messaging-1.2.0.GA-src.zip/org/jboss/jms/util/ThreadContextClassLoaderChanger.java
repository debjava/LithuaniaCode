/*
  * JBoss, Home of Professional Open Source
  * Copyright 2005, JBoss Inc., and individual contributors as indicated
  * by the @authors tag. See the copyright.txt in the distribution for a
  * full listing of individual contributors.
  *
  * This is free software; you can redistribute it and/or modify it
  * under the terms of the GNU Lesser General Public License as
  * published by the Free Software Foundation; either version 2.1 of
  * the License, or (at your option) any later version.
  *
  * This software is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  * Lesser General Public License for more details.
  *
  * You should have received a copy of the GNU Lesser General Public
  * License along with this software; if not, write to the Free
  * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
  * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
  */
package org.jboss.jms.util;

/**
 * A thread context classloader changer. This class is an abomination. It is here for experimental
 * purposes only. The way it changes the class loader (and more important, the way it stores the
 * saved thread context class loader) is inneficient and dangerous.
 *
 * TODO: Do not use it in the production version.
 *       See http://www.jboss.org/index.html?module=bb&op=viewtopic&t=74434 for an alternative solution.
 *
 * @author <a href="mailto:ovidiu@jboss.org">Ovidiu Feodorov</a>
 * @version <tt>$Revision: 537 $</tt>
 *
 * $Id: ThreadContextClassLoaderChanger.java 537 2005-12-22 16:34:17Z ovidiu $
 */
public class ThreadContextClassLoaderChanger
{
   // Constants -----------------------------------------------------

   // Static --------------------------------------------------------

   private ClassLoader savedThreadContextClassLoader;

   public void set(ClassLoader cl)
   {
      Thread currentThread = Thread.currentThread();
      savedThreadContextClassLoader = currentThread.getContextClassLoader();
      currentThread.setContextClassLoader(cl);
   }

   /**
    * Use it from a finally block.
    */
   public void restore()
   {
      if (savedThreadContextClassLoader == null)
      {
         return;
      }

      Thread.currentThread().setContextClassLoader(savedThreadContextClassLoader);
      savedThreadContextClassLoader = null;
   }
   // Attributes ----------------------------------------------------
   
   // Constructors --------------------------------------------------
   
   // Public --------------------------------------------------------

   // Package protected ---------------------------------------------
   
   // Protected -----------------------------------------------------
   
   // Private -------------------------------------------------------
   
   // Inner classes -------------------------------------------------   
}
