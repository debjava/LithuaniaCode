/**
 * JBoss, Home of Professional Open Source
 *
 * Distributable under LGPL license.
 * See terms of license at gnu.org.
 */
package org.jboss.messaging.core.plugin.contract;


/**
 * @author <a href="mailto:ovidiu@jboss.org">Ovidiu Feodorov</a>
 * @author <a href="mailto:tim.fox@jboss.com">Tim Fox</a>
 * @version <tt>$Revision: 1270 $</tt>
 *
 * $Id: ServerPlugin.java 1270 2006-09-09 11:48:48Z timfox $
 */
public interface ServerPlugin
{
   /**
    * A server plugin will be always accessed via a hard reference, so it is essential that each
    * implementation exposes this method.
    */
   MessagingComponent getInstance();
}
