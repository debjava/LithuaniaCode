/**
 * JBoss, Home of Professional Open Source
 *
 * Distributable under LGPL license.
 * See terms of license at gnu.org.
 */
package org.jboss.test.messaging.tools.jmx.rmi;

import javax.management.NotificationListener;
import javax.management.Notification;
import java.io.Serializable;

/**
 * @author <a href="mailto:ovidiu@jboss.org">Ovidiu Feodorov</a>
 * @version <tt>$Revision: 1917 $</tt>
 * $Id: NotificationListenerID.java 1917 2007-01-08 20:26:12Z clebert.suconic@jboss.com $
 */
public class NotificationListenerID implements Serializable, NotificationListener
{
   // Constants -----------------------------------------------------

   private static final long serialVersionUID = -39839086486546L;

   // Static --------------------------------------------------------

   // Attributes ----------------------------------------------------

   private long id;

   // Constructors --------------------------------------------------

   public NotificationListenerID(long id)
   {
      this.id = id;
   }

   // NotificationListener implementation ---------------------------

   public void handleNotification(Notification notification, Object object)
   {
      throw new IllegalStateException("Do not use this method directly!");
   }

   // Public --------------------------------------------------------

   public long getID()
   {
      return id;
   }

   // Package protected ---------------------------------------------

   // Protected -----------------------------------------------------

   // Private -------------------------------------------------------

   // Inner classes -------------------------------------------------
}
