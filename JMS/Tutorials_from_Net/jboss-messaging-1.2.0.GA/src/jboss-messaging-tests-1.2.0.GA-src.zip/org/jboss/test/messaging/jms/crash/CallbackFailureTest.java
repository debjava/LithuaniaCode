/*
  * JBoss, Home of Professional Open Source
  * Copyright 2005, JBoss Inc., and individual contributors as indicated
  * by the @authors tag. See the copyright.txt in the distribution for a
  * full listing of individual contributors.
  *
  * This is free software; you can redistribute it and/or modify it
  * under the terms of the GNU Lesser General Public License as
  * published by the Free Software Foundation; either version 2.1 of
  * the License, or (at your option) any later version.
  *
  * This software is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  * Lesser General Public License for more details.
  *
  * You should have received a copy of the GNU Lesser General Public
  * License along with this software; if not, write to the Free
  * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
  * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
  */
package org.jboss.test.messaging.jms.crash;

import javax.jms.*;
import javax.management.ObjectName;
import javax.naming.InitialContext;
import org.jboss.jms.server.ConnectionManager;
import org.jboss.test.messaging.MessagingTestCase;
import org.jboss.test.messaging.tools.ServerManagement;
import org.jboss.test.messaging.tools.jmx.ServiceContainer;
import org.jboss.test.messaging.tools.jmx.rmi.LocalTestServer;
import org.jboss.test.messaging.tools.jmx.rmi.Server;
import org.jboss.test.messaging.tools.jndi.InVMInitialContextFactory;

/**
 * @author <a href="tim.fox@jboss.com">Tim Fox</a>
 * @version <tt>$Revision: 2046 $</tt>
 *
 * $Id: CallbackFailureTest.java 2046 2007-01-25 03:00:26Z ovidiu.feodorov@jboss.com $
 */
public class CallbackFailureTest extends MessagingTestCase
{
   // Constants ------------------------------------------------------------------------------------

   // Static ---------------------------------------------------------------------------------------
   
   // Attributes -----------------------------------------------------------------------------------
   
   protected Server localServer;
   protected Server remoteServer;

   // Constructors ---------------------------------------------------------------------------------

   public CallbackFailureTest(String name)
   {
      super(name);
   }

   // Public ---------------------------------------------------------------------------------------

   public void setUp() throws Exception
   {
      super.setUp();
      
      // Start the local server
      localServer = new LocalTestServer();
      
      // Start all the services locally
      localServer.start("all", true);
            
      localServer.deployQueue("Queue", null, false);
           
      // Connect to the remote server, but don't start a servicecontainer on it. We are only using
      // the remote server to open a client connection to the local server.
      ServerManagement.create();
          
      remoteServer = ServerManagement.getServer();
   }

   public void tearDown() throws Exception
   {       
      localServer.stop();
   }
        
   /*
    * Test that when a client callback fails, server side resources for connections are cleaned-up.
    */
   public void testCallbackFailure() throws Exception
   {
      if (!ServerManagement.isRemote())
      {
         fail("this test should be run in a remote configuration");
      }

      // we need to disable exception listener otherwise it will clear up the connection itself
      
      ObjectName remoteConnectorName = ServiceContainer.REMOTING_OBJECT_NAME;
      
      ConnectionManager cm = localServer.getServerPeer().getConnectionManager();
      
      localServer.getServerPeer().getServer().
         invoke(remoteConnectorName,
                "removeConnectionListener",
                new Object[] {cm},
                new String[] {"org.jboss.remoting.ConnectionListener"});
       
      InitialContext ic = new InitialContext(InVMInitialContextFactory.getJNDIEnvironment());
      
      ConnectionFactory cf = (ConnectionFactory)ic.lookup("/ConnectionFactory");
      
      Queue queue = (Queue)ic.lookup("/queue/Queue");
      
      CreateHangingConsumerCommand command = new CreateHangingConsumerCommand(cf, queue);
      
      String remotingSessionId = (String)remoteServer.executeCommand(command);
      
      remoteServer.kill();
        
      // we have removed the exception listener so the server side resouces shouldn't be cleared up

      log.info("sleeping for 1 min ...");
      Thread.sleep(60000);
                 
      assertTrue(cm.containsRemotingSession(remotingSessionId));
      
      // Now we send a message which should prompt delivery to the dead consumer causing
      // an exception which should cause connection cleanup
                  
      Connection conn = cf.createConnection();
      
      Session sess = conn.createSession(false, Session.AUTO_ACKNOWLEDGE);
        
      MessageProducer prod = sess.createProducer(queue);

      // sending just one message should be enough to trigger the failure and client smacking
      prod.send(sess.createMessage());

      log.info("sleeping for 45 secs ...");
      Thread.sleep(45000);
      
      assertFalse(cm.containsRemotingSession(remotingSessionId));

      // make sure the message is still in queue

      conn = cf.createConnection();
      conn.start();
      sess = conn.createSession(false, Session.AUTO_ACKNOWLEDGE);
      MessageConsumer cons = sess.createConsumer(queue);
      Message m = cons.receive(1000);
      assertNotNull(m);

      cons.close();
               
   }
   
   // Package protected ----------------------------------------------------------------------------
   
   // Protected ------------------------------------------------------------------------------------
   
   // Private --------------------------------------------------------------------------------------
   
   // Inner classes --------------------------------------------------------------------------------

}
