/**
 * JBoss, Home of Professional Open Source
 *
 * Distributable under LGPL license.
 * See terms of license at gnu.org.
 */
package org.jboss.test.messaging.util;

import javax.naming.InitialContext;
import java.util.Hashtable;

/**
 * @author <a href="mailto:ovidiu@jboss.org">Ovidiu Feodorov</a>
 * @version <tt>$Revision: 1972 $</tt>
 * $Id: JNDITesterService.java 1972 2007-01-17 14:29:46Z ovidiu.feodorov@jboss.com $
 */
public class JNDITesterService implements JNDITesterServiceMBean
{
   // Constants ------------------------------------------------------------------------------------

   // Static ---------------------------------------------------------------------------------------

   // Attributes -----------------------------------------------------------------------------------

   // Constructors ---------------------------------------------------------------------------------

   // JNDITesterServiceMBean implementation --------------------------------------------------------

   public Object installAndUseJNDIEnvironment(Hashtable environment, String thingToLookUp)
      throws Exception
   {

      InitialContext ic = new InitialContext(environment);

      return ic.lookup(thingToLookUp);
   }

   // Public ---------------------------------------------------------------------------------------

   // Package protected ----------------------------------------------------------------------------

   // Protected ------------------------------------------------------------------------------------

   // Private --------------------------------------------------------------------------------------

   // Inner classes --------------------------------------------------------------------------------

}
