import java.io.RandomAccessFile;
import com.objectspace.voyager.*;
import com.objectspace.voyager.corba.*;

/**
 * @(#)Server.java
 * @author Qusay H. Mahmoud
 */

public class Server {
   static IArith arith;
   public static void main(String argv[]) {
      try {
        Voyager.startup("6000");
        arith = new Arith();
        String ior = Corba.asIOR(arith);
        System.out.println("Arith IOR =: "+ior);
        RandomAccessFile file = new RandomAccessFile("Arith.IOR", "rw");
        file.writeUTF(ior);
        file.close();
        System.out.println("CORBA server is ready to serve clients");
      } catch (Exception e) {
         System.err.println(e);
      }
   }
}
