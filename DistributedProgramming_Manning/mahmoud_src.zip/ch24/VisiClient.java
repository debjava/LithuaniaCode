import org.omg.CORBA.*;
import java.io.*;

/**
 * @(#)VisiClient.java
 * @author Qusay H. Mahmoud
 */

public class VisiClient {
   public static void main(String argv[]) {
      int a[] = {4, 4, 4, 4, 4, 4, 4, 4, 4, 4};
      int b[] = {4, 4, 4, 4, 4, 4, 4, 4, 4, 4};
      int result[] = new int[10];
      try {
        ORB orb = ORB.init();
        BOA boa = orb.BOA_init();
        RandomAccessFile file = new RandomAccessFile("Arith.IOR", "r");
        String ior = file.readUTF();
        file.close();
        System.out.println("IOR = "+ior);
        IArith add = IArithHelper.narrow(orb.string_to_object(ior));
        System.out.println("Got Add reference");
        result = add.addArrays(a, b);
        System.out.println("Sum = ");
        for (int i=0; i<10; i++) {
          System.out.println(result[i]+"    ");
        }
        System.out.println();
      } catch (SystemException se) {
         se.printStackTrace();
      } catch (Exception e) {
         e.printStackTrace();
      }
   }
}
