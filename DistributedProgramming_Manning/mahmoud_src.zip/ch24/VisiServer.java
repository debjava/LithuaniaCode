import org.omg.CORBA.*;
import java.io.RandomAccessFile;

/**
 * @(#)VisiServer.java 
 * @author Qusay H. Mahmoud
 */

public class VisiServer {
   public static void main(String argv[]) {
      try {
        ORB orb = ORB.init();
        BOA boa = orb.BOA_init();
        AddImpl arr = new AddImpl("Arithmetic Server");
        boa.obj_is_ready(arr);
        String ior = orb.object_to_string(arr);
        System.out.println("Arith IOR = "+ior);
        RandomAccessFile file = new RandomAccessFile("arith.ior", "rw");
        file.writeUTF(ior);
        file.close();
        System.out.println(arr + " is ready");
        boa.impl_is_ready();
      } catch(SystemException se) {
         se.printStackTrace();
      } catch (Exception e) {
         e.printStackTrace();
      }
   }
}
