import java.io.RandomAccessFile;
import com.objectspace.voyager.*;
import com.objectspace.voyager.corba.*;

/**
 * @(#)VoyClient.java
 * @author Qusay H. Mahmoud
 */

public class VoyClient {
   public static void main(String argv[]) {
      int a[] = {4, 4, 4, 4, 4, 4, 4, 4, 4, 4};
      int b[] = {4, 4, 4, 4, 4, 4, 4, 4, 4, 4};
      Arith.AddPackage.Outarray result = new Arith.AddPackage.Outarray();
      try {
        Voyager.startup();
        RandomAccessFile file = new RandomAccessFile("arith.ior", "r");
        String ior = file.readUTF();
        file.close();
        System.out.println("Arith IOR = "+ior);
        Arith.Add arith = (Arith.Add) Namespace.lookup(ior);
        Arith.sum_arrays(a, b, result);
        System.out.print("Sum = ");
        for(int i=0; i<10; i++) {
          System.out.println(result.value[i]+"    ");
        }
        System.out.println();
      } catch(Exception e) {
         e.printStackTrace();
      }
      Voyager.shutdown();
   }
}
