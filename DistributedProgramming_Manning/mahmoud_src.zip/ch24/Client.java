import java.io.RandomAccessFile;
import com.objectspace.voyager.*;
import com.objectspace.voyager.corba.*;

/**
 * @(#)Client.java
 * @author Qusay H. Mahmoud
 */

public class Client {
   public static void main(String argv[]) {
      int a[] = {4, 4, 4, 4, 4, 4, 4, 4, 4, 4};
      int b[] = {4, 4, 4, 4, 4, 4, 4, 4, 4, 4};
      int result[] = new int[10];
      try {
        Voyager.startup();
        RandomAccessFile file = new RandomAccessFile("Arith.IOR", "r");
        String ior = file.readUTF();
        file.close();
        System.out.println("Arith IOR =: "+ior);
        IArith arith = (IArith) Namespace.lookup(ior);
        result = arith.addArrays(a, b);
        System.out.print("Sum = ");
        for(int i=0; i<result.length; i++) {
          System.out.print(result[i]+"      ");
        }
        System.out.println();
      } catch(Exception e) {
         System.err.println(e);
      }
      Voyager.shutdown();
   }
}
