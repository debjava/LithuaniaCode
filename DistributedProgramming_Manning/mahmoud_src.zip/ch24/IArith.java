/**
 * @(#)IArith.java
 * @author Qusay H. Mahmoud
 */

public interface IArith {
   int[] addArrays(int a[], int b[]);
}
