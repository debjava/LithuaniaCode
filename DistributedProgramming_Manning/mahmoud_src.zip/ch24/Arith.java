/**
 * @(#)Arith.java
 * @author Qusay H. Mahmoud
 */
public class Arith implements IArith {
   public int[] addArrays(int a[], int b[]) {
      int c[] = new int[10];
      for(int i=0; i<c.length; i++) {
        c[i] = a[i] + b[i];
      }
      return c;
   }
}
