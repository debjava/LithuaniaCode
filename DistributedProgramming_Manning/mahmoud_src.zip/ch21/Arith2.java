import java.io.*;
import com.objectspace.voyager.*;
/**
 * @(#)Arith2.java
 * @author Qusay H. Mahmoud
 */

public class Arith2 {
   public static void main(String argv[]) throws Exception {
      Voyager.startup();
      IArith m = (IArith) Proxy.export(new Arith(), "9000");
      Namespace.bind("9000/add", m);
   }
}
