import com.objectspace.voyager.*;

/**
 * @(#)ArithClient2.java
 * @author Qusay H. Mahmoud
 */

public class ArithClient2 {
   public static void main(String argv[]) throws Exception {
      int a[] = {4, 4, 4, 4, 4, 4, 4, 4, 4, 4};
      int b[] = {4, 4, 4, 4, 4, 4, 4, 4, 4, 4};
      int result[] = new int[10];
      Voyager.startup();
      IArith arithObj = (IArith) Namespace.lookup("//localhost:9000/add");
      result = arithObj.addArrays(a, b);
      for (int i=0; i<result.length; i++) {
        System.out.println(result[i]);
      }
      Voyager.shutdown();
   }
}
