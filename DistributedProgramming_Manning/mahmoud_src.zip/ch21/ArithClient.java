import com.objectspace.voyager.*;

/**
 * @(#)ArithClient.java
 * @author Qusay H. Mahmoud
 */

public class ArithClient {
   public static void main(String argv[]) {
      int a[] = {4, 4, 4, 4, 4, 4, 4, 4, 4, 4};
      int b[] = {4, 4, 4, 4, 4, 4, 4, 4, 4, 4};
      int result[] = new int[10];
      // start voyager as a client
      Voyager.startup(); 
      //create a remote arithmetic object
      IArith arithObj = (IArith) Factory.create("Arith", "//localhost:8000");
      // send message to the remote object
      result = arithObj.addArrays(a, b);
      for (int i=0; i<result.length; i++) {
        System.out.println(result[i]);
      }
      Voyager.shutdown();
   }
}
