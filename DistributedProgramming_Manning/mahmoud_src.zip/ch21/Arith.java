import java.io.*;

/**
 * @(#)Arith.java
 * @author Qusay H. Mahmoud
 */

public class Arith implements IArith, Serializable {
   public Arith() { // constructor
      System.out.println("construct arith object");
   }

   public int[] addArrays(int a[], int b[]) {
      int len = a.length;
      int c[] = new int[len];
      for(int i=0; i<len; i++) {
        c[i] = a[i] + b[i];
      }
      return c;
   }
}
