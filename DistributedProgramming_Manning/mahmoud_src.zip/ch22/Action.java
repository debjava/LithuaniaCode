import com.objectspace.voyager.*;
import com.objectspace.voyager.mobility.*;
/**
 * @(#)Action.java
 * @author Qusay H. Mahmoud
 */
public class Action {
   public static void main(String argv[]) {
   boolean onHost = false;
   try {
     Voyager.startup("9000");
     IHello hello = (IHello) Factory.create("Hello");
     IMobility mob = Mobility.of(hello);
     if(!onHost) {
       mob.moveTo("//ultra10/6000");
       hello.sayHi("hi from my creator on ultra9");
     } else {
       mob.moveTo("//localhost:9000");
       hello.sayHi("hi to myself");
     }
   } catch(Exception e) {
      System.err.println(e);
   }
   Voyager.shutdown();
   }
}
