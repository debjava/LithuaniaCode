import java.io.*;
import com.objectspace.voyager.mobility.*;
/**
 * @(#)Hello2.java
 * @author Qusay H. Mahmoud
 */
public class Hello2 implements IHello, IMobile, Serializable {
   public void sayHi(String msg) {
      System.out.println(msg);
   }

   public void preDeparture(String src, String dest) {
      System.out.println("preDeparture()");
   }
   
   public void preArrival() {
      System.out.println("preArrivale()");
   }

   public void postArrival() {
      System.out.println("postArrival");
   }

   public void postDeparture() {
      System.out.println("postDeparture");
   }
}
