import com.objectspace.voyager.*;
/**
 * @(#)MyAgent.java
 * @author Qusay H. Mahmoud
 */
public class MyAgent {
   public static void main(String argv[]) {
      try {
        Voyager.startup();
        IArith arith = (IArith)Factory.create("Arith", "//ultra10:7000");
        IAdder add = (IAdder)Factory.create("Adder");
        add.add(arith);
      } catch(Exception e) {
         System.err.println(e);
      }
      Voyager.shutdown();
   }
}
