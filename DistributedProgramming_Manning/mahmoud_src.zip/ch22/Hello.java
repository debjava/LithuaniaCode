import java.io.*;
/**
 * @(#)Hello.java
 * @author Qusay H. Mahmoud
 */
public class Hello implements IHello, Serializable {
   public void sayHi(String msg) {
      System.out.println(msg);
   }
}
