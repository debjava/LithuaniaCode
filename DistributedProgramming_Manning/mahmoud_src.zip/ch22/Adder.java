import java.io.*;
import com.objectspace.lib.timer.*;
import com.objectspace.voyager.*;
import com.objectspace.voyager.agent.*;

/**
 * @(#)Adder.java
 * @author Qusay H. Mahmoud
 */

public class Adder implements IAdder, Serializable {
   int a[] = {4, 4, 4, 4, 4, 4, 4, 4, 4, 4};
   int b[] = {4, 4, 4, 4, 4, 4, 4, 4, 4, 4};

   public Adder() {
      System.out.println("constuct an array adder");
   }
   
   public void finalize() {
      System.out.println("finalize array adder");
   }

   public void add(IArith arith) {
      System.out.println("remote adder");
      addAt(arith);
      System.out.println("local adder");
      try {
        Agent.of(this).moveTo(arith, "atMachine");
      } catch(Exception e) {
        System.err.println(e);
      }
   }
  
   public void atMachine(IArith arith) {
      System.out.println("at remote machine, home = "+Agent.of(this).getHome());
      addAt(arith);
      Agent.of(this).setAutonomous(false);
   }

   public void addAt(IArith arith) {
      int result[] = new int[10];
      System.out.println("start adding");
      result = arith.addArrays(a, b);
      System.out.println("stop adding");
      // print result
      for(int i=0; i<10; i++) {
        System.out.println(result[i]);
      }
   }
}
