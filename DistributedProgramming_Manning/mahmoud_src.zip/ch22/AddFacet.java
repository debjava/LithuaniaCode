import com.objectspace.lib.facets.*;
import com.objectspace.voyager.*;

/**
 * @(#)AddFacet.java
 * @author Qusay H. Mahmoud
 */

public class AddFacet {
   public static void main(String argv[]) {
      try {
        Voyager.startup("8000");
        ICustomer customer = new Customer("J. Giles", "Ottawa");
        //return the customer's facet
        IFacets facets = Facets.of(customer);
        //return a proxy to the facet that implements Ipayment interface
        IPayment payment = (IPayment) facets.of("IPayment");
        payment.payBill(2300);
        System.out.println("primary = "+facets.getPrimary());
        Object objs[] = facets.getFacets();
        for(int i=0; i<objs.length; i++) {
          System.out.println("facet["+i+"]="+objs[0]);
        }
        Namespace.bind("Giles", customer);
      } catch(Exception e) {
        System.err.println(e);
      }
   }
}
