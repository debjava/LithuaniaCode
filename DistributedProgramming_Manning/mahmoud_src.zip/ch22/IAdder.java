/**
 * @(#)Iadder.java
 * @author Qusay H. Mahmoud
 */
public interface IAdder {
   void add(IArith arith);
}
