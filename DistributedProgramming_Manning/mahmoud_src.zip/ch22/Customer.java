/**
 * @(#)Customer.java
 * @author Qusay H. Mahmoud
 */
public class Customer implements ICustomer {
   String name;
   String location;
   
   public Customer(String name, String location) {
      this.name = name;
      this.location = location;
   }

   public String toString() {
      return "Customer(" +name+","+location+")";
   }

   public String getName() {
      return name;
   }

   public String getLocation() {
      return location;
   }
}
