/**
 * @(#)Payment.java
 * @author Qusay H. Mahmoud
 */
public class Payment implements IPayment {
   int balance;

   public String toString() {
      return "Payment("+balance+")";
   }

  public void payBill(int amount) {
     balance += amount;
  }

  public int getBalance() {
     return balance;
  }
}
