import java.io.*;
/**
 * @(#)Arith.java
 * @author Qusay H. Mahmoud
 */
public class Arith implements IArith, Serializable {
   public Arith() {
      System.out.println("construct math object");
   }

   public int[] addArrays(int a[], int b[]) {
      int len = a.length;
      int c[] = new int[10];
      for(int i=0; i<len; i++) {
        c[i] = a[i] + b[i];
      }
      return c;
   }
}
