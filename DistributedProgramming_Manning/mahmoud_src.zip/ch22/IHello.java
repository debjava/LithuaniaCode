/**
 * @(#)IHello.java
 * @author Qusay H. Mahmoud
 */
public interface IHello {
   void sayHi(String msg);
}
