/**
 * @(#)IPayment.java
 * @author Qusay H. Mahmoud
 */
public interface IPayment {
   void payBill(int amount);
   int getBalance();
}
