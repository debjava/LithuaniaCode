import com.objectspace.lib.facets.*;
import com.objectspace.voyager.*;
/**
 * @(#)AccessFacet.java
 * @author Qusay H. Mahmoud
 */
public class AccessFacet {
   public static void main(String argv[]) {
      try {
        Voyager.startup();
        ICustomer customer = (ICustomer) Namespace.lookup("//localhost:8000/Giles");
        IPayment payment = (IPayment) Facets.of(customer).of("IPayment");
        System.out.println("Payment ="+payment);
      } catch(Exception ex) {
         System.err.println(ex);
      }
      Voyager.shutdown();
   }
}
