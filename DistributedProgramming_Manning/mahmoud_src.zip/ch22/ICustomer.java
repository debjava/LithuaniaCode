/**
 * @(#)ICustomer.java
 * @author Qusay H. Mahmoud
 */
public interface ICustomer {
   String getName();
   String getLocation();
}
