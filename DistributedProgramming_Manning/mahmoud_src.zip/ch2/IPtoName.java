import java.net.*;  

/**
 * @(#)IPtoName.java
 * @author Qusay H. Mahmoud
 * @version Nov 2, 1996 (doesn't work with JDK1.0.2)
 * @modified Dec 9, 1996 (works with JDK1.1beta)
 */

public class IPtoName {
  public static void main(String argv[]) {
    if (argv.length == 0) {
      System.out.println("Usage: java IPtoName <IP Address>");
      System.exit(0);
    }
    String host = argv[0]; 
    InetAddress address = null; 
    try {
      address = InetAddress.getByName(host); 
    } catch (UnknownHostException e) {
       System.out.println("invalid IP - malformed IP"); 
       System.exit(0); 
    }
    System.out.println(address.getHostName()); 
  } 
}

