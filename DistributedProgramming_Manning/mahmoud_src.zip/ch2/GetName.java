import java.net.*;

/**
 * @(#)GetName.java
 * @author Qusay H. Mahmoud
 */

public class GetName {
  public static void main(String argv[]) throws Exception {
    InetAddress host = null;
    host = InetAddress.getLocalHost();
    System.out.println(host.getHostName());
  }
}
