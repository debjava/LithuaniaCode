import java.net.*;  

/**
 * @(#)NsLookup.java
 * @author Qusay H. Mahmoud
 */

public class NsLookup {
  public static void main(String argv[]) {
    if (argv.length == 0) {
      System.out.println("Usage: java NsLookup <hostname>");
      System.exit(0);
    }
    String host = argv[0]; 
    InetAddress address = null; 
    try {
      address = InetAddress.getByName(host); 
    } catch(UnknownHostException e) {
       System.out.println("Unknown host"); 
       System.exit(0); 
    }
    byte[] ip = address.getAddress(); 
    for (int i=0; i<ip.length; i++) {
      if (i > 0) System.out.print("."); 
      System.out.print((ip[i]) & 0xff); 
    }
    System.out.println(); 
  } 
}

