import java.io.*;
/**
 * @(#)Employee.java
 * @author Qusay H. Mahmoud
 */
public class Employee {
   String name;
   int age;
   int salary;

   public Employee(String name, int age, int salary) {
      this.name = name;
      this.age = age;
      this.salary = salary;
   }

   public static void print(Employee emp) {
      System.out.println("------------------------------");
      System.out.println(emp.name+" Record:");
      System.out.println("Name: "+emp.name);
      System.out.println("Age: "+emp.age);
      System.out.println("Salary: "+emp.salary);
   }

   public static void main(String argv[]) {
      Employee emily = new Employee("E. Jordan", 27, 35000);
      Employee john = new Employee("J. McDonald", 30, 39000);
    
      // print Emily's information
      print(emily);
   }
}
