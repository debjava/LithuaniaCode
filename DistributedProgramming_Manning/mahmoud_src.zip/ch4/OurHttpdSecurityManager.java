/**
 * @(#)OurHttpdSecurityManager.java
 * @author Qusay H. Mahmoud
 */

import java.io.*;
import java.util.*;

/**
 * This class implements a very simple custom security manager for the 
 * Web Server.
 * just make sure noone can request our passwd file by saying:
 *     http://hostname/../../../etc/passwd  OR
 *     http://hostname//etc/passwd
 *
 */

class OurHttpdSecurityManager extends SecurityManager {

    // the following operations are allowed.
    // may be this is not what you exactly want...but..
    public void checkConnect(String host, int port) { };
    public void checkCreateClassLoader() { };
    public void checkAccess(Thread g) { };
    public void checkListen(int port) { };
    public void checkLink(String lib) { };
    public void checkPropertyAccess(String key) { }; 
    public void checkAccept(String host, int port) { };
    public void checkAccess(ThreadGroup g) { };
    public void checkRead(FileDescriptor fd) { };
    public void checkWrite(String f) { };
    public void checkWrite(FileDescriptor fd) { };

    // make sure noone can say http://hostname/../../../etc/passwd OR
    // http://hostname//etc/passwd    note the two slashes
    public void checkRead(String filename){
      if ((filename.indexOf("..") != -1) || (filename.startsWith("/"))) {
       throw new SecurityException("You do not have enough privileges to read:"+filename);
      }
    }
 }

