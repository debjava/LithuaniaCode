/**
 * @(#)UpdateEmp.java
 * @author Qusay H. Mahmoud
 */

import java.sql.*; 

class UpdateEmp {
  public static void main(String argv[]) {
    if( argv.length != 3 ) {
      System.err.println("Usage: java UpdateEmp [name] [age] [salary]"); 
      return; 
    }
    try {
      Class.forName("com.imaginary.sql.msql.MsqlDriver");
      // change the hostname and port# to your hostname and port# 
      String url = "jdbc:msql://rockwood.csd.unbsj.ca:1112/employees"; 
      Connection con = DriverManager.getConnection(url, "qusay", ""); 
      Statement stmt = con.createStatement(); 
      stmt.executeUpdate("INSERT INTO employee (name, age, salary) " +
        "VALUES(" + "'" + argv[0] + "'" + ", " + argv[1] + ", "+argv[2] +")"); 
      System.out.println("Insert Succeeded."); 
      stmt.close(); 
      con.close(); 
    }
    catch( Exception e ) {
      System.out.println(e.getMessage()); 
      e.printStackTrace(); 
    }
  }
}
