/**
 * @(#)Emp.java
 * @author Qusay H. Mahmoud
 */

import java.sql.*; 

class Emp {
  public static void main(String argv[]) {
    try {
      // The call to Class.forName explicitly loads the driver class
      Class.forName("com.imaginary.sql.msql.MsqlDriver"); 
      
      // the following url says that the protocol is jdbc, the
      // subprotocol is msql, and our database is installed on the machine
      // rockwood.csd.unbsj.ca, in which the mSQL server runs on port 1112
      // change these to your configurations!
      String url = "jdbc:msql://rockwood.csd.unbsj.ca:1112/employees"; 
      
      // the method DriverManager.getConnection is the only method that a
      // general programmer needs to use directly. This method establishes
      // a connection to a database specified by a URL, loginID and
      // password. 
      Connection con = DriverManager.getConnection(url, "qusay", ""); 

      // Once a connection has been established we can create an instance
      // of Statement, through which we will send queries to the database. 
      Statement stmt = con.createStatement(); 

      // The method executeQuery executes a query on the database. The
      // return result is of type ResultSet which is one or more rows in
      // this case. 
      ResultSet rs = stmt.executeQuery("SELECT * from employee"); 

      System.out.println("The Results we got are:"); 
      // the ResultSet.next() method returns the next field in the
      // current row. 
      // the returned results could be saved in the corresponding types
      // using ResultSet.getInt for an integer, ResultSet.getFloat for a
      // real number, ...etc
      while(rs.next()) {
        String str = rs.getString(1); 
        int f1 = rs.getInt(2); 
        float f2 = rs.getFloat(3); 
        System.out.println(" Name= " + str); 
        System.out.println(" Age= " + f1); 
        System.out.println(" Salary= " + f2); 
      }
        
      // Once we are done we can close the statement and connection to
      // the database. 
      stmt.close(); 
      con.close(); 
    }
    catch( Exception e ) {
      System.out.println(e.getMessage()); 
      e.printStackTrace(); 
    }
  }
}
