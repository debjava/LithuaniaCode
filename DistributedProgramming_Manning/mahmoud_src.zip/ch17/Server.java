/**
 * @(#)Server.java
 * @author Qusay H. Mahmoud
 */

public class Server {
   public static void main(String argv[]) {
     try {
       CORBA.ORB orb = CORBA.ORB.init();
       CORBA.BOA boa = orb.BOA_init();
       Manager manager = new Manager();
       Bank.Manager manager2 = new Bank._tie_Manager(manager, "Bank");
       // export the object reference
       boa.obj_is_ready(manager);
       System.out.println("The Acct Manager is ready.");
       // wait for requests
       boa.impl_is_ready();
     } catch (SystemException e) {
        e.printStackTrace();
     }
   }
}
