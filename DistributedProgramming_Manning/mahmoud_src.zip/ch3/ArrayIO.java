/**
 * @(#)ArrayIO.java
 * @author Qusay H. Mahmoud
 */

import java.io.*;

class ArrayIO {
    public ArrayIO() {
    }

    /**
     * write an array of integers to a socket
     */

     public void writeArray(DataOutputStream out, int arr[]) throws Exception {
        for (int i=0; i<arr.length; i++) {
           out.write(arr[i]);
        }
    }

    /**
     * read an array of integers from a socket
     */
    public int[] readArray(BufferedReader br) throws Exception {
        int c[] = new int[10];
    
        for (int h=0; h<10; h++) {
           try {  
             c[h] = (int) br.read();
           } catch(IOException il) {
             il.printStackTrace();
           }
 	}
        return c;
    }
}    
