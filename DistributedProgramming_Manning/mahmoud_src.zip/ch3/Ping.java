import java.io.*;
import java.net.*;
/**
 * @(#) Ping.java  
 * @author Qusay H. Mahmoud
 */
public class Ping {
   public final static int ECHO_PORT = 7;
   public static void main(String argv[]) {
      if (argv.length != 1) {
        System.out.println("Usage: java ping hostname");
        System.exit(0);
      }
      if (alive(argv[0])) {
        System.out.println(argv[0] + " is alive");
      } else {
      System.out.println("No response fr " +argv[0]+", down or doesn't exist");
      }
   }
   // check for aliveness through ECHO
	 public static boolean alive(String host) {
  	    Socket pingSocket = null;
       try {
         pingSocket = new Socket(host, ECHO_PORT);
       } catch (UnknownHostException e) {
          System.err.println("UnknownHostException: " +e);
       } catch (IOException io) {
          System.out.println("IOException: " + io);
       }
       if (pingSocket != null) {
         try {
           pingSocket.close();
         } catch (IOException e) {
            System.err.println("IOException: " + e);
         }
         return true;
       } else {
         return false;
       }
   }
}
