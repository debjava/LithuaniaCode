/**
 * @(#)Client.java
 * @author Qusay H. Mahmoud
 */

import java.io.*;
import java.net.*;

public class Client {    
    public final static int REMOTE_PORT = 3333;
    static int a[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    static int b[] = {11, 12, 13, 14, 15, 16, 17, 18, 19, 20};

    public static void main(String argv[]) throws Exception {
	Socket cl = null, cl2=null;
	BufferedReader is = null;
	DataOutputStream os = null;
        ArrayIO aio = new ArrayIO();

	try {
	   cl = new Socket("hostname",REMOTE_PORT);
	   is = new BufferedReader(new InputStreamReader(cl.getInputStream()));
	   os = new DataOutputStream(cl.getOutputStream());
	} catch(UnknownHostException e1) {
	   System.out.println("Unknown Host: "+e1);
	} catch (IOException e2) {
	   System.out.println("Erorr io: "+e2);
	}
	try {	    
	   aio.writeArray(os, a);
           aio.writeArray(os, b);
	} catch (IOException ex) {
	   System.out.println("error writing to server..."+ex);
	}	
	// receive results 
	int result[] = new int[10];
	try {
           result = aio.readArray(is);
	} catch(Exception e) {
	   e.printStackTrace();
	}
	System.out.println("The sum of the two arrays is: ");
	for (int j=0; j<result.length; j++) {
	   System.out.print(result[j]+" ");
	}
        System.out.println("");
	// close input stream, output stream and connection
	try {
           is.close();
           os.close();
	   cl.close();
	} catch (IOException x) {
	   System.out.println("Error writing...."+x);
	}
    }
}
