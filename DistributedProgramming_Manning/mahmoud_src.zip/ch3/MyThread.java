/**
 * @(#)MyThread.java
 * @author Qusay H. Mahmoud
 */

class MyThread extends Thread {
   public MyThread(String name) {
      super(name);
   }

   public void run() {
      for (int i=0; i<3; i++) {
         System.out.println(getName() + ":" + i);
         try {
            Thread.sleep(500);
         } catch(InterruptedException e) {
            e.printStackTrace();
         }
      }
   }

   public static void main(String argv[]) {
      MyThread t1 = new MyThread("ReadFromSocket");
      MyThread t2 = new MyThread("ReadFromKeyboard");
      t1.start();
      t2.start();
   }
}

