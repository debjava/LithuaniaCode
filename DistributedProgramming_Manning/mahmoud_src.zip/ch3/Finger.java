import java.io.*;
import java.net.*;
/** 
 * @(#)Finger.java
 * @author Qusay H. Mahmoud
 */
public class Finger {
   static String host = null;
   static String user = null;
   public static String localHost() throws Exception {
      InetAddress host = null;
      host = InetAddress.getLocalHost();
      return host.getHostName();
   }
   public static void parse(String str) throws Exception {
     int position = 0;
     while (position != -1) {
        position = str.indexOf('@', position);
     	if (position != -1) {
          host = str.substring(position+1);
          host.trim();
          user = str.substring(0,position);
          user.trim();
          position++;
        } else {
           user = str;
           host = localHost();
        }
     }
   }
   // just in case we forgot to catch all exceptions..thows Exception
   // it is easier just to handle exceptions once.in the future.
   public static void main(String argv[]) throws Exception{
      Socket fingerSocket = null;
      DataOutputStream os = null;
      BufferedReader is = null;
      if (argv.length == 1) {
        parse(argv[0]);
      } else {
        host = localHost();
        user ="@"+host;
      }
      try {
        fingerSocket = new Socket(host, 79);
        os=new DataOutputStream(fingerSocket.getOutputStream());
        is = new BufferedReader (new InputStreamReader(fingerSocket.getInputStream()));
      } catch (UnknownHostException e) {
         System.err.println("Couldn't get I/O for the connection to: "+host);
      }
      if (fingerSocket != null && os != null && is != null) {
        try {
          os.writeBytes(user);
          os.writeBytes("\n");
          String responseLine;
          while ((responseLine = is.readLine()) != null) {
             System.out.println(responseLine);
          }
          os.close();
          is.close();
          fingerSocket.close();
        } catch (UnknownHostException e) {
           System.err.println("Trying to connect to unknown host: " + e);
        } catch (IOException e) {
           System.err.println("IOException:  " + e);
        }  
      }
   }
}
