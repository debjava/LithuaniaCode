/**
 * @(#)MyThread2.java
 * @author Qusay H. Mahmoud
 */

class MyThread2 implements Runnable {

   public void run() {
      for (int i=0; i<3; i++) {
         System.out.println(Thread.currentThread().getName() + ":"+i);
         try {
            Thread.sleep(500);
         } catch(InterruptedException e) {
            e.printStackTrace();
         }
      }
   }

   public static void main(String argv[]) {
      MyThread2 s = new MyThread2();
      MyThread2 k = new MyThread2();
      Thread t1 = new Thread(s, "ReadFromSocket");
      Thread t2 = new Thread(k, "ReadFromKeyboard");
      t1.start();
      t2.start();
   }
}
