import org.omg.CORBA.*;

/**
 * @(#)Client.java
 * @author Qusay H. Mahmoud
 */

public class Client {
   public static void main(String argv[]) {
    String name = "Qusay H. Mahmoud";  
    float bal = (float) 0.0;
    try {
        ORB orb = ORB.init();
        Bank.Manager manager = Bank.ManagerHelper.bind(orb,"Bink");
	Bank.Account account = manager.createAccount(name);
        account.Deposit((float)128.4);
        bal = (float) account.balance();
        System.out.println("Balance = "+bal);
        account.Withdraw((float)100.0);
        bal = (float) account.balance();
        System.out.println("Balance = "+bal);
    } catch (SystemException e) {
        e.printStackTrace();
    }
  }
}
 
