import org.omg.CORBA.*;

/**
 * @(#)NovaServer.java
 * @author Qusay H. Mahmoud
 */
public class NovaServer {
   public static void main(String argv[]) {
      try {
        ORB orb = ORB.init();
        BOA boa = orb.BOA_init();
        Bank.Manager  manager = new ManagerImpl("NovaBank");
        boa.obj_is_ready(manager);
        System.out.println("Manager is ready");
        boa.impl_is_ready();
      } catch(SystemException e) {
        e.printStackTrace();
     }
   }
}
