import java.io.*;
/**
 * @(#)SaveEmp.java
 * @author Qusay H. Mahmoud
 * This class creates some instances of the Employee
 * class and serialize then by saving their state to
 * a file.
 */
public class SaveEmp {
   public static void main(String argv[]) throws Exception {
      // create some objects
      Employee emily = new Employee("E. Jordan", 27, 35000);
      Employee john = new Employee("J. McDonald",290, 39000);
      // serialize the objects emily and john
      FileOutputStream fos = new FileOutputStream("db");
      ObjectOutputStream oos = new ObjectOutputStream(fos);
      oos.writeObject(emily);
      oos.writeObject(john);
      oos.flush();
   }
}
