import java.io.*;
import java.net.*;
import java.security.*;

/**
 * @(#)Client.java
 * @author Qusay H. Mahmoud
 */

public class Client {
   public static void main(String argv[]) {
      Socket s = null;
      ObjectOutputStream os = null;

      try {
        s = new Socket("hamming", 4000);
        os = new ObjectOutputStream(s.getOutputStream());
        System.out.println("Generating public and private keys....");
        // generate public and private kjeys
        KeyPairGenerator kgen = KeyPairGenerator.getInstance("DSA");
        kgen.initialize(256);
        KeyPair kpair = kgen.generateKeyPair();
        
        // generate signature
        System.out.println("Generating Signature....");
        Signature sig = Signature.getInstance("SHA/DSA");
        PublicKey pub = kpair.getPublic();
        PrivateKey priv = kpair.getPrivate();
        sig.initSign(priv);

        // read a file and compute a signature
        FileInputStream fis = new FileInputStream(argv[0]);
        byte arr[] = new byte[fis.available()];
        fis.read(arr);
        sig.update(arr);

        // send the SignedObject on the wire
        SignedObject obj = new SignedObject(arr, sig.sign(), pub);
        os.writeObject(obj);
        
        fis.close();
        os.close();
        s.close();
      } catch (Exception e) {
        e.printStackTrace();
      }
   }
}
