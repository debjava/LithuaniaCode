import java.io.*;
/**
 * @(#)ReadEmp.java
 * @author Qusay H. Mahmoud
 * This class deserializes the objects emily and john by reconstructing
 * their state, which is saved in a file.
 */
public class ReadEmp {
   public static void main(String argv[]) throws Exception{
      //deserialize objects emily and john
      FileInputStream fis = new FileInputStream("db");
      ObjectInputStream ois = new ObjectInputStream(fis);
      Employee emily = (Employee) ois.readObject();
      Employee john = (Employee) ois.readObject();
      // print the records after reconstruction of state
      emily.print();
      john.print();
   }
}
