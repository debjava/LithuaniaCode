/** 
 * @(#)NetClassLoader.java    
 * @author Qusay H. Mahmoud
 */

import java.io.*;
import java.net.*;
import java.util.*;


/**
 * This class implements a custom network class loader. The class is 
 * capable of loading classes off the network.<p>
 * This class loader creates a cache of loaded classes so that classes 
 * that have been loaded before can just be fetched from the cache.
 *
 * @author	Qusay H. Mahmoud
 * @version	1.0
 */

public class NetClassLoader extends ClassLoader {
    private Hashtable classes = new Hashtable();

    // constructor
    public NetClassLoader() {
    }

    /**
     * Loads a class with the specified name and return it.
     * @return a class with the specified name.
     */
    public Class loadClass(String className) throws ClassNotFoundException {
        return (loadClass(className, true));
    }

    /**
     * This method is called by the loadClass above.
     * @return a class with the specified name.
     */
    public synchronized Class loadClass(String className, boolean resolveIt)
    	throws ClassNotFoundException {
        Class result;
        byte  classData[];

        result = (Class) classes.get(className);
	if (result==null) {
	  try {
	      result = findSystemClass(className);
	      if (result!=null) classes.put(className,result);
	  } catch(Exception e) {
	  }
	}
	if (result==null) {
	  classData = null;
	  if (0==className.indexOf("http://")) {
	    classData = loadnet(className);
	  }
          if (classData!=null) {
	    result = defineClass(classData, 0, classData.length);
	    if (resolveIt) resolveClass(result);
	    if (result!=null) {
	      classes.put(className, result);
	    }
	  }
	}
	return(result);
    }

    /**
     * Loads a class with the specified name off the network.
     * @returns an array of bytes representing the bytecode class.
     */
    private byte[] loadnet(String name) {
      URL url=null;
      DataInputStream dis=null;
      URLConnection urlc=null;
      byte data[]; 
      int filesize;

      System.out.println("Loading "+name+" from the network");
      try {
	 url = new URL(name);
      } catch(MalformedURLException e) {
	 System.out.println("NetClassLoader: "+e);
      }
      try {
	 urlc = url.openConnection();
	 dis = new DataInputStream(urlc.getInputStream());
      } catch(Exception e) {
	 System.out.println("NetClassLoader: can not open URL "+e);
      }
      filesize = urlc.getContentLength();
      data = new byte[filesize];
      try {
	 dis.readFully(data);
      } catch(IOException i) {
	 System.out.println("NetClassLoader: could not read: "+name);
      }
      if (data==null) System.out.println("DATA = NULL");
      return(data);
    }
}
