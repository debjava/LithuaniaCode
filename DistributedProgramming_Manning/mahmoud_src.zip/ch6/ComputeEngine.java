import java.io.*;
import java.net.*;
import java.util.*;

/* 
 * @(#)ComputeEngine.java
 * @version 1.0, Jan 6, 1997
 * @author Qusay H. Mahmoud
 */

public class ComputeEngine extends Thread {
    public static final int EXEC_PORT = 5000;
    protected ServerSocket listen;
    
    // constructor
    public ComputeEngine() {
        try {
           listen = new ServerSocket(EXEC_PORT);
       	} catch (IOException e) {
	   System.out.println("Error in creating server socket: "+e);
	}
	System.out.println("Exec server listening on port: "+EXEC_PORT);
	this.start();
    }
  
    /**
     * accepts a new connection in a seperate thread of execution.
     */
    public void run() {
	try {
 	   while(true) {
	      Socket cl = listen.accept();
	      Connect cc = new Connect(cl);
	   }
	} catch(IOException ex) {
	   System.out.println("Error listening for connections: "+ex);
	}
    }

    /**
     * This is main where execution starts. Set our custom security 
     * manager, and create an instance of the Compute Engine.
     */
    public static void main(String argv[]) {
        RunnerSecurityManager RSM;
       	try {
	   RSM = new RunnerSecurityManager();
	   System.setSecurityManager(RSM);
	} catch (SecurityException se) {
	   System.out.println("RunnerSecurityManager already running");
	}
	new ComputeEngine();
    }
}
