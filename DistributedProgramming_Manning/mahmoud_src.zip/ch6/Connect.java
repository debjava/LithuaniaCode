import java.io.*;
import java.net.*;

/* 
 * @(#)Connect.java
 * @author Qusay H. Mahmoud
 */

class Connect extends Thread {
    Socket client;
//  BufferedReader is;
    DataInputStream is;
    PrintStream os;

    /**
     * creates an input and output streams and make the inputstream ready to 
     * receive information from the client.
     */
    public Connect(Socket s) { // constructor
       	client = s;
	try {
	   is = new DataInputStream(client.getInputStream());
	   os = new PrintStream(client.getOutputStream());
	} catch (IOException e) {
	   System.out.println("Error...."+e);
	}
	this.start();
    }

    /**
     * reads information from the client and creates an instance of our 
     * custom network class loader.
     */
    public void run() {
	String url = null;
        try {
           url = is.readUTF();
	} catch (IOException es) {
	   System.out.println("Error writing..."+es);
	}
	String className = url;
        // redirect the output stream to the client socket.
	System.setOut(os);
        
	// use a class loader...
	NetClassLoader sc = new NetClassLoader(); 
        try {
          Object o; 
          o = (sc.loadClass(className, true)).newInstance();
          ((Compute) o).run();	    
	} catch (Exception cne) {
	  System.out.println("Error...."+cne);
 	} 

	// close the input and output streams and the connection to the client.
	try {
	  is.close();
	  os.close();
	  client.close();
	} catch (IOException xx) {
	  System.out.println("Error closing..."+xx);
	}
   }
}
