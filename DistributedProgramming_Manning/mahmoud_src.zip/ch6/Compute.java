/* 
 * @(#)Compute.java   
 * @author Qusay H. Mahmoud
 * Copyright (c) 1997 Qusay H. Mahmoud
 */


/**
 * This interface is designed to overcome one limitation found when working with
 * class loaders. The limitation is described below. This limitation can 
 * now be solved with the new Reflection API mechanism. However, I am 
 * using this interface as a novel solution.<p>
 * <b>The Problem</b>: One hidden issue when working with class loaders is 
 * the inability to cast an object that was created from a loaded class 
 * into its original class.<p> 
 * This problem can be resolved by either having an abstract class or an 
 * interface that each client should implement. So this is my interface. 
 * Each client of the system will have to implement this interface.<p>
 *
 */

public interface Compute { 
    /* Start the module */ 
    void run(); 
} 
