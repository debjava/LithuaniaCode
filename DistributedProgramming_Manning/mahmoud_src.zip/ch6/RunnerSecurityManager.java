import java.io.*;
import java.util.*;

/*
 * @(#)RunnerSecurityManager.java
 * @version 1.0, Jan 6, 1997
 * @author Qusay H. Mahmoud
 *
 * A Custom Security Manager. A very simple Custom Security Manager
 * that protects against some malicious code to be executed by a class 
 * loader. <p>
 */

class RunnerSecurityManager extends SecurityManager { 
   private boolean silent = true;
   private boolean checkRead = false;
   private boolean checkWrite = false;
   private boolean checkDelete = true;    
   private boolean checkExit = true;

   // constructor
   RunnerSecurityManager() {
      System.out.println("RunnerSecurityManager started");
   }


   /**
    * The following operations are alllowed. This is just hypotheitcal
    * though, more restricted access should be imposed when working with
    * class loaders
    */
   public void checkConnect(String host, int port) { };
   public void checkCreateClassLoader() { };
   public void checkAccess(Thread g) { };
   public void checkListen(int port) { };
   public void checkLink(String lib) { };
   public void checkPropertyAccess(String key) { };
   public void checkAccept(String host, int port) { };
   public void checkAccess(ThreadGroup g) { };
   public void checkExec(String cmd) { };
    
   /**
    * check to see if a file with the specified file descriptor can be read.
    */
   public void checkRead(FileDescriptor fd) {
      if(checkRead) {
	throw new SecurityException("Sorry, checkRead("+fd+") not allowed"); 
      }
      if(!silent) {
        System.out.println("RunnerSecurityMan FD="+fd+" : checkRead");	
      }
   }

   /**
    * check to see if a file with the specified file name can be read.
    */
   public void checkRead(String file) {
      if(checkRead) {
	 throw new SecurityException("Sorry, checkRead("+file+") not allowed."); 
      }
      if(!silent) {
        System.out.println("RunnerSecurityMan FILE="+file+" :checkRead");
      }
   }

   /**
    * check to see if a file with the specified file descriptor can be altered.
    */
   public void checkWrite(FileDescriptor fd) {
     if(checkWrite) {	
        throw new SecurityException("Sorry, not allowed to write "+fd); 
     }
     else if(!silent) {
       System.out.println("RunnerSecurityMan FD="+fd+" : checkWrite");
     }
   }

   /**
    * check to see if a file with the specified file name can be altered.
    */
   public void checkWrite(String file) {
      if(checkWrite) {
   	 throw new SecurityException("Sorry, not allowed to write "+file); 
      }
      else if(!silent) {
        System.out.println("RunnerSecurityManager FILE="+file+" : checkWrite");
      }
   }

   /**
    * check to see if a file with the specified file name can be deleted. 
    */
   public void checkDelete(String file) {
      if(checkDelete) {
   	 throw new SecurityException("Sorry, not allowed to delete "+file); 
      }
      else if(!silent) {
        System.out.println("RunnerSecurityManager FILE="+file+" : checkDelete");
      }
   }

   /**
    * check to see if the system has exited the Java Virtual Machine.
    */
   public void checkExit(int status) {
      if(checkExit) {	
   	 throw new SecurityException("Sorry, checkExit "+status); 
      }
      else if(!silent) {
        System.out.println("RunnerSecurityManager STATUS="+status+" : checkExit");
      }	
   }
}
