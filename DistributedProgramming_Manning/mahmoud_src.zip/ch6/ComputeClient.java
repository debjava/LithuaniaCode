import java.io.*;
import java.net.*;

/** 
 * @(#)ComputeClient.java
 * @author Qusay H. Mahmoud
 */

public class ComputeClient {    
   public final static int REMOTE_PORT = 5000;;
   /**
    * This is the main program of the client.
    * @param host The host on which the Compute Engine is running on
    * @param url The url of the class to be loaded.
    */
   public static void main(String argv[]) throws Exception {
      String host = argv[0];
      String url = argv[1];
      Socket cl = null, cl2=null;
      BufferedReader is = null;
      DataOutputStream os = null;
      // Open connection to the compute engine on port 5000	
      try {
	      cl = new Socket(host,REMOTE_PORT);
	      is = new BufferedReader(new InputStreamReader(cl.getInputStream()));
	      os = new DataOutputStream(cl.getOutputStream());
	      System.out.println("Connection is fine...");
      } catch(UnknownHostException e1) {
	      System.out.println("Unknown Host: "+e1);
      } catch (IOException e2) {
	      System.out.println("Erorr io: "+e2);
      }
      // write the url to the compute engine
      try {	    
	     os.writeUTF(url);
      } catch (IOException ex) {
	      System.out.println("error writing to server..."+ex);
      }	
      // receive results from the compute engine
      String outline;
      try {
	     while((outline = is.readLine()) != null) {
	       System.out.println("Remote: "+outline);
	     }
      } catch (IOException cx) {
	      System.out.println("Error: "+cx);
      }
      // close input stream, output stream and connection
      try {
        is.close();
        os.close();
        cl.close();
      } catch (IOException x) {
	       System.out.println("Error writing...."+x);
      }
   } 
}

