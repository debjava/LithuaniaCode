/**
 * @(#)ArithServer.java
 * @author Qusay H. Mahmoud
 */
public class ArithServer extends _MImplBase {
    Server(String name) {
      super(name);
    }

    public int[] add(int a[], int b[]) {
       int sum[] = new int[10];
       for(int i=0; i<a.length; i++) {
          sum[i] = a[i] = b[i];
       }
       return sum;
    }
     
    public static void main(String argv[]) {
      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(argv, null);
      org.omg.CORBA.BOA boa = orb.BOA_init();
      Arith math = new ArithServer("Math Server");
      boa.obj_is_ready(math);
      System.out.println(math +" is ready.");
      boa.impl_is_ready();
    }
}
