/**
 * @(#)Arith.java
 * @author Qusay H. Mahmoud
 */

public interface Arith extends org.omg.CORBA.Object {
   int[] add(int a[], int b[]);
}
