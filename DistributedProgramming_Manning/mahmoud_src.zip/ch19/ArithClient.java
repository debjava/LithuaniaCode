/**
 * @(#)ArithClient.java
 * @author Qusay H. Mahmoud
 */

public class ArithClient {
   public static void main(String argv[]) {
      org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(argv, null);
      Arith m = ArithHelper.bind(orb);
      int a[] = {2, 2, 2, 2, 2, 2, 2, 2, 2, 2};
      int b[] = {2, 2, 2, 2, 2, 2, 2, 2, 2, 2};
      int result[] = new int[10];

      result = m.add(a, b);
      for(int i=0; i<a.length; i++) {
        System.out.print(result[i] +"    ");
      }
      System.out.println("");
   }
}
