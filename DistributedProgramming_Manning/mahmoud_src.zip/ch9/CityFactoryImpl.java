import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

/**
 * @(#)CityFactoryImpl.java
 * @author Qusay H. Mahmoud
 */

public class CityFactoryImpl extends UnicastRemoteObject implements CityFactory {

   public CityFactoryImpl() throws RemoteException {
      super();
   }

   public City2Impl getCityServer(String cityName) throws RemoteException {
      City2Impl cityServer = new City2Impl(cityName);
      return cityServer;
   }

   public static void main(String argv[]) {
      System.setSecurityManager(new RMISecurityManager());
      try {
        CityFactoryImpl obj = new CityFactoryImpl();
        Naming.rebind("//localhost/CityFactory", obj);
        System.out.println("CityFactory bound in registry");
      } catch (Exception e) {
        e.printStackTrace();
      }
   }

}
