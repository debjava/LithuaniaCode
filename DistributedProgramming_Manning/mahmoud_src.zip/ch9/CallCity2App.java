import java.rmi.*;
import java.net.*;

/**
 * @(#)CallCity2App.java
 * @author Qusay H. Mahmoud
 */

public class CallCity2App implements Callback{

    public static void main(String argv[]) {
	int pop = 0;
        Callback c = (Callback) new CallCity2App();
        CallCity obj = null;

	try {
	   obj = (CallCity)Naming.lookup("//hamming/CityServer");
	   pop = obj.getPopulation("Toronto");
	} catch (Exception e) {
	   System.out.println("ArithApp exception:"+e.getMessage());
	   e.printStackTrace();
	}
        // register the callback
        try {
          obj.register(c);
        } catch(RemoteException e) {
          System.out.println("Error: ");
          e.printStackTrace();
        }
    }
    
    //implement Callback interface
    public void tempChanged(String cityName, int temp) {
       System.out.println("Dynamic Update: ");
       System.out.println("CityName: "+cityName);
       System.out.println("Temp: "+temp);
    }
}
