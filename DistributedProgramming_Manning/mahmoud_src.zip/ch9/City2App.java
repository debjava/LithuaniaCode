import java.rmi.*;

/**
 * @(#)City2App.java
 * @author Qusay H. Mahmoud
 */

public class City2App {
    public static void main(String argv[]) {
        Remote obj = null;
        CityFactoryImpl cityFactory;
        City2 ottawa = null;
        City2 toronto = null;
        int ottawaPopulation = 0;
        int torontoPopulation = 0;

        try {
           obj = Naming.lookup("//hostname/CityFactory");
        } catch (Exception e) {
           e.printStackTrace();
        }
        if (obj instanceof CityFactoryImpl) {
           cityFactory = (CityFactoryImpl) obj;
        }

        // create a server for each city
        try {
            ottawa = new CityFactoryImpl().getCityServer("Ottawa");
            toronto = new CityFactoryImpl().getCityServer("Toronto");
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        // invoke methods on those servers
        try {
             ottawaPopulation = ottawa.getPopulation();
             torontoPopulation = toronto.getPopulation();
        } catch (RemoteException e) {
             e.printStackTrace();
        }
        // print the results
        System.out.println("The population of Ottawa is: "+ottawaPopulation);
        System.out.println("The population of Toronto is: "+torontoPopulation);
   }
}
