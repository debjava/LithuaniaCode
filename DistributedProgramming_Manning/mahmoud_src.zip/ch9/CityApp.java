import java.rmi.*;
import java.net.*;

/**
 * @(#)CityApp.java
 * @author Qusay H. Mahmoud
 */

public class CityApp {

    public static void main(String argv[]) {
	int pop = 0;

	try {
	   City obj = (City)Naming.lookup("//hamming/CityServer");
	   pop = obj.getPopulation("Toronto");
	} catch (Exception e) {
	   System.out.println("ArithApp exception:"+e.getMessage());
	   e.printStackTrace();
	}
	System.out.println("The population of Toronto is: ");
	System.out.println(pop);
    }
}
