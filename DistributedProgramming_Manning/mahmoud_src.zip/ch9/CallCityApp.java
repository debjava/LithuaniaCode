import java.rmi.*;
import java.net.*;

/**
 * @(#)CallCityApp.java
 * @author Qusay H. Mahmoud
 */

public class CallCityApp implements Callback{

    public static void main(String argv[]) {
	int pop = 0;

	try {
	   CallCity obj = (CallCity)Naming.lookup("//hamming/CityServer");
	   pop = obj.getPopulation("Toronto");
	} catch (Exception e) {
	   System.out.println("ArithApp exception:"+e.getMessage());
	   e.printStackTrace();
	}
	System.out.println("The population of Toronto is: ");
	System.out.println(pop);
    }
    
    //implement Callback interface
    public void tempChanged(String cityName, int temp) {
       System.out.println("Dynamic Update: ");
       System.out.println("CityName: "+cityName);
       System.out.println("Temp: "+temp);
    }
}
