import java.io.*;
import java.security.*;
import java.rmi.*;
import java.rmi.server.*;

/**
 * @(#)Server.java
 * @author Qusay H. Mahmoud
 */

class Server extends UnicastRemoteObject implements SignedInterface {
    SignedObject s;
    String name;
    String str;
    public Server(String name) throws RemoteException {
      super();
      this.name = name;
    }
      
    public String put(String str) throws RemoteException {
      this.str = str; 
      return str;
    }

    public Server(SignedObject s) throws RemoteException {
      super();
      this.s = s;
    }

    public SignedObject getString() throws RemoteException {
       return s;
    }

    public static void main(String argv[]) throws Exception {
       System.out.println("Generating keys...");
       KeyPairGenerator kgen = KeyPairGenerator.getInstance("DSA");
       kgen.initialize(256);
       KeyPair kpair = kgen.generateKeyPair();

       Signature sig = Signature.getInstance("SHA/DSA");
       PublicKey pub = kpair.getPublic();
       PrivateKey priv = kpair.getPrivate();
       sig.initSign(priv);

       FileInputStream fis = new FileInputStream(argv[0]);
       byte arr[] = new byte[fis.available()];
       fis.read(arr);
       sig.update(arr);
       System.setSecurityManager(new RMISecurityManager());
       SignedObject ss = new SignedObject(arr, sig.sign(), pub);
       System.out.println(pub);
       System.out.println(ss.pub);
       Server sss = new Server(ss);
       Naming.rebind("//localhost/Server", sss);
       System.out.println("Server bound in registry");
    }
}
