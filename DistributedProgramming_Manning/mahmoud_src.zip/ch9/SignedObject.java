import java.io.*;
import java.security.*;
import java.rmi.*;
import java.rmi.server.*;

/**
 * @(#)SignedObject.java
 * @author Qusay H. Mahmoud
 */

public class SignedObject implements Serializable {
   byte b[];
   byte sig[];
   PublicKey pub;

   public SignedObject(byte b[], byte sig[], PublicKey pub) {
      this.b = b;
      this. sig = sig;
      this.pub = pub;
   }
}
