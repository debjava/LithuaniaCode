import java.io.*;
import java.security.*;
import java.rmi.*;
import java.rmi.server.*;

/**
 * @(#)Client.java
 * @author Qusay H. Mahmoud
 */ 

class Client {
   public static void main(String argv[]) throws Exception {
      SignedInterface rs = (SignedInterface)Naming.lookup("//hostname/Server");
      String out = rs.put("Hello there");
      System.out.println("I got: "+out);

      SignedObject so = rs.getString();
      System.out.println(so.toString());

      Signature sig = Signature.getInstance("SHA/DSA");
      sig.initVerify(so.pub);
      sig.update(so.b);
      System.out.println(so.pub);
      boolean valid = sig.verify(so.sig);
      if (valid) {
        System.out.println("valid signature");
      } else {
        System.out.println("invalid signature");
      }
  }
}
