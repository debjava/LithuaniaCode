
import java.rmi.*;

/**
 * @(#)City.java
 * @author Qusay H. Mahmoud
 */
public interface City extends Remote {
   int getPopulation(String cityName) throws RemoteException;
   int getTemperature(String cityName) throws RemoteException;
}
   
