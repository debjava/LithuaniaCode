import java.rmi.*;

/**
 * @(#)CityFactory.java
 * @author Qusay H. Mahmoud
 */

public interface CityFactory extends Remote {
   City2Impl getCityServer(String cityName) throws RemoteException;
}
