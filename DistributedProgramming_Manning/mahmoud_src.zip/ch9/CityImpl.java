import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

/**
 * @(#)CityImpl.java
 * @author Qusay H. Mahmoud
 */


public class CityImpl extends UnicastRemoteObject implements City {
   private String name; 

   public CityImpl(String str) throws RemoteException {
      super();
      name = str;
   }

   public int getPopulation(String cityName) throws RemoteException {
      if (cityName.equals("Toronto")) {
         return 10;
      } else if (cityName.equals("Ottawa")) { 
	 return 2;
      } else {
 	 return 100;
      }
   }
  
   public int getTemperature(String cityName) throws RemoteException {
      return 1;
   }

   public static void main(String argv[]) {
      System.setSecurityManager(new RMISecurityManager());
      try {
        CityImpl obj = new CityImpl("CityyServer");
        Naming.rebind("//hamming/CityServer", obj);
	System.out.println("CityServer bound in registry");
      } catch (Exception e) {
	e.printStackTrace();
      }
   }
}
