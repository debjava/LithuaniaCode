import java.io.*;
import java.security.*;
import java.rmi.*;
import java.rmi.server.*;

/**
 * @(#) SignedInterface.java
 * @author Qusay H. Mahmoud
 */

interface SignedInterface extends Remote {
   public String put(String str) throws RemoteException;
   public SignedObject getString() throws RemoteException;
}
