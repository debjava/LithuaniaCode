import java.rmi.*;

/**
 * @(#)City2.java
 * @author Qusay H. Mahmoud
 */

public interface City2 extends Remote {
   int getPopulation() throws RemoteException;
   int getTemperature() throws RemoteException;
}
   
