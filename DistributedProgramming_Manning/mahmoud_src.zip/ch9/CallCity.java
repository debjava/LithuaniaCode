import java.rmi.*;

/**
 * @(#)CallCity.java
 * @author Qusay H. Mahmoud
 */

public interface CallCity extends Remote {
   int getPopulation(String cityName) throws RemoteException;
   int getTemperature(String cityName) throws RemoteException;
   void register(Callback cb) throws RemoteException;
}
