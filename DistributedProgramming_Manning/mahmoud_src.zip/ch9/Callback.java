/**
 * @(#)Callback.java
 * @author Qusay H. Mahmoud
 */

public interface Callback {
   void tempChanged(String cityName, int temp);
}
