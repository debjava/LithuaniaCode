import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

/**
 * @(#)City2Impl.java
 * @author Qusay H. Mahmoud
 */

public class City2Impl extends UnicastRemoteObject implements City2 {
   private String cityName; 

   public City2Impl() throws RemoteException {
     super();
   }
   
   public City2Impl(String cityName) throws RemoteException {
      super();
      this.cityName = cityName;
   }

   public int getPopulation() throws RemoteException {
      if (cityName.equals("Toronto")) {
         return 10;
      } else if (cityName.equals("Ottawa")) { 
	 return 2;
      } else {
 	 return 0;
      }
   }
  
   public int getTemperature() throws RemoteException {
      return 1;
   }

}
