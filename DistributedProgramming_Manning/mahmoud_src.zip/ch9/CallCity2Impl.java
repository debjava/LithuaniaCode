import java.util.*;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

/**
 * @(#)CallCity2Impl.java
 * @author Qusay H. Mahmoud
 */


public class CallCity2Impl extends UnicastRemoteObject implements CallCity {
   private String name; 
   Vector list = new Vector();

   public CallCity2Impl() throws RemoteException {
     super();
   }

   public CallCity2Impl(String str) throws RemoteException {
      super();
      name = str;
   }

   public int getPopulation(String cityName) throws RemoteException {
      if (cityName.equals("Toronto")) {
         return 10;
      } else if (cityName.equals("Ottawa")) { 
	 return 2;
      } else {
 	 return 100;
      }
   }
  
   public int getTemperature(String cityName) throws RemoteException {
      return 1;
   }

   public void register(Callback cb) {
      list.addElement(cb);
   }

   public void setTemp(String cityName, int tmp) {
     for(int i=0; i<list.size(); i++) {
       Callback cb = (Callback) list.elementAt(i);
       cb.tempChanged(cityName, tmp);
     }
   }

   public static void main(String argv[]) {
      System.setSecurityManager(new RMISecurityManager());
      try {
        CallCity2Impl obj = new CallCity2Impl("CityyServer");
        Naming.rebind("//hamming/CityServer", obj);
	System.out.println("CityServer bound in registry");
      } catch (Exception e) {
	e.printStackTrace();
      }
   }
}
