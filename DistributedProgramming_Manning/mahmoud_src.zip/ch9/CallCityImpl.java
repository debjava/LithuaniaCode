import java.util.*;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

/**
 * @(#)CallCityImpl.java
 * @author Qusay H. Mahmoud
 */


public class CallCityImpl extends UnicastRemoteObject implements CallCity {
   private String name; 
   Vector list = new Vector();

   public CallCityImpl() throws RemoteException {
     super();
   }

   public CallCityImpl(String str) throws RemoteException {
      super();
      name = str;
   }

   public int getPopulation(String cityName) throws RemoteException {
      if (cityName.equals("Toronto")) {
         return 10;
      } else if (cityName.equals("Ottawa")) { 
	 return 2;
      } else {
 	 return 100;
      }
   }
  
   public int getTemperature(String cityName) throws RemoteException {
      return 1;
   }

   public void register(Callback cb) {
      list.addElement(cb);
   }

   public static void main(String argv[]) {
      System.setSecurityManager(new RMISecurityManager());
      try {
        CallCityImpl obj = new CallCityImpl("CityyServer");
        Naming.rebind("//hamming/CityServer", obj);
	System.out.println("CityServer bound in registry");
      } catch (Exception e) {
	e.printStackTrace();
      }
   }
}
