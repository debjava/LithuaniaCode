import org.omg.CORBA.*;
/**
 * @(#)Client.java
 * @author Qusay H. Mahmoud
 */
public class Client {
   public static void main(String argv[]) {
      int a[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
      int b[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
      Arith.AddPackage.arrayHolder result = new Arith.AddPackage.arrayHolder();
      try {
         ORB orb = ORB.init(); 
         Arith.Add add = Arith.AddHelper.bind(orb, "Arithmetic Server");
         add.sum_arrays(a, b, result);
         System.out.print("The sum is: ");
         for(int i=0; i<10; i++) {
            System.out.print(result.value[i]+"   ");
         }
         System.out.println();
      } catch(SystemException se) {
         se.printStackTrace();
      }
   }
}
