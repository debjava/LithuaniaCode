/**
 * @(#)AddImpl.java
 * @author Qusay H. Mahmoud
 */
public class AddImpl extends Arith._AddImplBase {
   public AddImpl(java.lang.String name) {
      super(name);
   }

   public AddImpl() {
      super();
   }

   public void sum_arrays( int[] a, int[] b, Arith.AddPackage.arrayHolder c) {
      c.value = new int[10];
      for (int i=0; i< 10; i++) {
         c.value[i] = a[i] + b[i];
      }
   }
}
