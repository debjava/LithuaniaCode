import org.omg.CORBA.*;
/**
 * @(#)Server.java
 * @author Qusay H. Mahmoud
 */
public class Server {
   public static void main(String argv[]) {
      try {
         ORB orb = ORB.init();
         BOA boa = orb.BOA_init();
         AddImpl arr = new AddImpl("Arithmetic Server");
         boa.obj_is_ready(arr);
         System.out.println(arr +" is ready");
         boa.impl_is_ready();
      } catch(SystemException se) {
         se.printStackTrace();
      }
   }
}

