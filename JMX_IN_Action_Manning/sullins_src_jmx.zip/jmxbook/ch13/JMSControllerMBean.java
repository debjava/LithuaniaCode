package jmxbook.ch13;

public interface JMSControllerMBean
{
  public void turnOnHomeTheater();
  public void turnOffHomeTheater();
}

