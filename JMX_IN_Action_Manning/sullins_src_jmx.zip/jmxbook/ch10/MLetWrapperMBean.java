package jmxbook. ch10;

import javax.management.loading.*;

public interface MLetWrapperMBean extends MLetMBean
{
}

