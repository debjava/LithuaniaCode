package jmxbook.ch11;

public interface PhoneCardMBean
{
  public void disable();
}

