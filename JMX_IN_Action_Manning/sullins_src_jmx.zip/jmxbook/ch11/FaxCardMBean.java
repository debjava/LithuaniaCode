package jmxbook.ch11;

public interface FaxCardMBean
{
  public void disable();
}

