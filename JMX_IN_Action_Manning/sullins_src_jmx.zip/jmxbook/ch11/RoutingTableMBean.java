package jmxbook.ch11;

public interface RoutingTableMBean
{
  public void removePhoneRoute(Integer cardNum);
  public void removeFaxRoute();
}

