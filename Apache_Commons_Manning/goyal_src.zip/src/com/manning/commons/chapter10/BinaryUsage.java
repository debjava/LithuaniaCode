package com.manning.commons.chapter10;

// import Java classes
import java.io.File;
import java.io.IOException;
import java.io.FileInputStream;

// import Codec classes
import org.apache.commons.codec.*;
import org.apache.commons.codec.binary.*;

public class BinaryUsage{

	public static void main(String args[]){
		BinaryUsage codec = new BinaryUsage();
		try{
		  codec.start();
		}catch(Exception e){
			System.err.println(e);
		}
	}

	public void start() throws IOException, EncoderException, DecoderException{

		// create an instance of the encoders/decoder
		Base64 b64Encoder = new Base64();
		Hex    hexEncoder = new Hex();

		// encode a simple string for Base64
		byte[] b64Result = b64Encoder.encode("Hello World!!".getBytes());
		System.err.println("Hello World!! got encoded as: " + new String(b64Result));

		// encode resultant byte array to hex
		byte[] hexResult = hexEncoder.encode(b64Result);
		System.err.println("Hex representation of Base64 result: " + new String(hexResult));

		// using this hex representation, decode it back
		hexResult = hexEncoder.decode(hexResult);
		System.err.println("Hex decoding on the encoded data: " + new String(hexResult));

		// The same result should get decoded back to the original string
		System.err.println("The same encoding should give the original string: " + new String(b64Encoder.decode(hexResult)));

		// now get the Bse64 representation of a truly binary object, like an image
		File imageFile = new File("hills.jpg");
		byte[] imageBytes = new byte[(int)imageFile.length()];
		FileInputStream fis = new FileInputStream(imageFile);

		fis.read(imageBytes);

		fis.close();

		System.err.println("Printing Base64 representation of: " + imageFile.getName());
		System.err.println(new String(b64Encoder.encodeBase64(imageBytes)));

		System.err.println("Printing Base64 CHUNKED representation of: " + imageFile.getName());
		System.err.println(new String(b64Encoder.encodeBase64Chunked(imageBytes)));


	}
}