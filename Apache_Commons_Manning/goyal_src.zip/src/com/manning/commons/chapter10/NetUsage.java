package com.manning.commons.chapter10;

// import Codec classes
import org.apache.commons.codec.*;
import org.apache.commons.codec.net.*;

public class NetUsage{

	public static void main(String args[]){
		NetUsage codec = new NetUsage();
		try{
		  codec.start();
		}catch(Exception e){
			System.err.println(e);
		}
	}

	public void start() throws EncoderException, DecoderException{

		String urlData1 = "This#is^a&String with reserved @/characters";

		URLCodec encoder = new URLCodec();

		String result = encoder.encode(urlData1);

		System.err.println("URL Encoding result: " + result);
		System.err.println("URL Decoding result: " + encoder.decode(result));
	}
}