package com.manning.commons.chapter10;

import java.io.File;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.net.URLCodec;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.language.Soundex;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.codec.StringEncoderComparator;
import org.apache.commons.codec.language.DoubleMetaphone;

public class CodecExample {

  private Base64 b64Encoder = new Base64();
  private Hex    hexEncoder = new Hex();
  private FileInputStream fis;
	private String result;

  public static void main(String[] args) {
	  CodecExample app = new CodecExample();
	  app.doMain(args);
  }

  private void doMain(String[] args) {
    test1();
    test2();
    test3();
    test4();
    test5();
    test6();
  }
}