package com.manning.commons.chapter10;

// import Codec classes
import org.apache.commons.codec.digest.*;

public class DigestUsage{

	public static void main(String args[]){
		DigestUsage codec = new DigestUsage();
		try{
		  codec.start();
		}catch(Exception e){
			System.err.println(e);
		}
	}

	public void start(){

		String hashData = "Hello World!!";

		System.err.println("Hello World!! as MD5 16 element hash: "
		  + new String(DigestUtils.md5(hashData)));

		System.err.println("Hello World!! as MD5 Hex hash: "
		  + DigestUtils.md5Hex(hashData));

		System.err.println("Hello World!! as SHA byte array hash: "
		  + new String(DigestUtils.sha(hashData)));

		System.err.println("Hello World!! as SHA Hex hash: "
		  + DigestUtils.shaHex(hashData));

	}
}