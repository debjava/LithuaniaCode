package com.manning.commons.chapter08;

import org.apache.commons.lang.ArrayUtils;

public class ArrayUtilsExampleV1 {

	public static void main(String args[]) {

		long[] longArray = new long[] {10000, 30, 99};
		String[] stringArray = new String[] {"abc", "def", "fgh"};

		long[] clonedArray = ArrayUtils.clone(longArray);
		System.err.println(
			ArrayUtils.toString((ArrayUtils.toObject(clonedArray))));

		System.err.println(ArrayUtils.indexOf(stringArray, "def"));

		ArrayUtils.reverse(stringArray);
		System.err.println(ArrayUtils.toString(stringArray));
	}
}