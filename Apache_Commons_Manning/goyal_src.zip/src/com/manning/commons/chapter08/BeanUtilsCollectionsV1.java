package com.manning.commons.chapter08;

import org.apache.commons.beanutils.BeanComparator;

import java.util.Arrays;

public class BeanUtilsCollectionsV1 {
  public static void main(String args[]) {
		BeanComparator comp = new BeanComparator("name");

		Actor actor1 = new Actor();
		actor1.setName("Michael Caine");

		Actor actor2 = new Actor();
		actor2.setName("Robert Redford");

		Actor actor3 = new Actor();
		actor3.setName("Harrison Ford");

		Actor[] actors = {actor1, actor2, actor3};

		Arrays.sort(actors, comp);

		for(int i=0; i<actors.length; i++) {
			System.err.println("[" + actors[i].getName() + "]");
		}
	}
}