package com.manning.commons.chapter08;

import org.apache.commons.lang.math.IntRange;

public class RangeCheckV1 {

	public static void main(String args[]) {
		IntRange range1 = new IntRange(35, 70);
		IntRange range2 = new IntRange(35);
		IntRange range3 = new IntRange(69, 75);

		System.err.println(range1.containsRange(range2));
		System.err.println(range1.overlapsRange(range3));
		System.err.println(range1.getMaximumInteger());
	}
}