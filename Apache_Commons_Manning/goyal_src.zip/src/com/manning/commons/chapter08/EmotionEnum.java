package com.manning.commons.chapter08;

import org.apache.commons.lang.enum.Enum;

import java.util.Map;
import java.util.List;
import java.util.Iterator;

public final class EmotionEnum extends Enum {
	public static final EmotionEnum JEALOUSY = new EmotionEnum("Jealousy");
	public static final EmotionEnum HAPPINESS = new EmotionEnum("Happiness");
	public static final EmotionEnum FEAR = new EmotionEnum("Fear");

	private EmotionEnum(String emotion) {
		super(emotion);
	}

	public static EmotionEnum getEnum(String emotion) {
		return (EmotionEnum) getEnum(EmotionEnum.class, emotion);
	}

	public static Map getEnumMap() {
		return getEnumMap(EmotionEnum.class);
	}

	public static List getEnumList() {
		return getEnumList(EmotionEnum.class);
	}

	public static Iterator iterator() {
		return iterator(EmotionEnum.class);
	}
}