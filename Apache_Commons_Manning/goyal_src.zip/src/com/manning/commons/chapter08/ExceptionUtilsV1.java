package com.manning.commons.chapter08;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang.exception.NestableException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ExceptionUtilsV1 {
  public static void main(String args[]) {
		try {
		  loadFile();
		} catch(Exception e) {
			e.printStackTrace();
		}
  }

  public static void loadFile() throws Exception {
		try {
		  FileInputStream fis =
		   new FileInputStream(new File("nosuchfile"));
		} catch (FileNotFoundException fe) {
			throw new NestableException(fe);
		}
	}
}
