package com.manning.commons.chapter08;

import org.apache.commons.lang.StringEscapeUtils;

public class StringUtilsEscapeExampleV1 {

	public static void main(String args[]) {
		String unescapedJava = "Are you	for real?";
		System.err.println(
			StringEscapeUtils.escapeJava(unescapedJava));

		String unescapedJavaScript = "What's in a name?";
		System.err.println(
			StringEscapeUtils.escapeJavaScript(unescapedJavaScript));

		String unescapedSql = "Mc'Williams";
		System.err.println(
			StringEscapeUtils.escapeSql(unescapedSql));

		String unescapedXML = "<data>";
		System.err.println(
			StringEscapeUtils.escapeXml(unescapedXML));
	}
}