package com.manning.commons.chapter08;

import org.apache.commons.beanutils.locale.LocaleBeanUtils;

import java.util.Date;
import java.util.GregorianCalendar;

public class BeanUtilsExampleV5 {
  public static void main(String args[]) throws Exception {
		BeanUtilsExampleV5 diff = new BeanUtilsExampleV5();
		Movie movie = diff.prepareData();

		System.err.println(
			LocaleBeanUtils.getProperty(movie, "dateOfRelease", "dd-MMM-yyyy"));

  }

  private Movie prepareData() {
		Movie movie = new Movie();
		movie.setTitle("The Italian Job");
		movie.setDateOfRelease(new GregorianCalendar(2000, 0, 1).getTime());
		return movie;
	}
}
