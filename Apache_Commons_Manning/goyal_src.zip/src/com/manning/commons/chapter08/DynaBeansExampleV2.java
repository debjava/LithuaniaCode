package com.manning.commons.chapter08;

import org.apache.commons.dbcp.BasicDataSource;

import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.beanutils.ResultSetDynaClass;

import java.util.Iterator;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class DynaBeansExampleV2 {
	public static void main(String args[]) throws Exception {

		Connection conn = getConnection();
		PreparedStatement ps =
		  conn.prepareStatement(
				"SELECT * from movie, person " +
				"WHERE movie.director = person.Id");
		ResultSet rs = ps.executeQuery();

		ResultSetDynaClass rsdc = new ResultSetDynaClass(rs);

		Iterator itr = rsdc.iterator();
		while(itr.hasNext()) {
			DynaBean bean = (DynaBean)itr.next();
			System.err.println(bean.get("title"));
		}

		conn.close();
	}

	private static Connection getConnection() throws Exception {
		BasicDataSource bds = new BasicDataSource();
		bds.setDriverClassName("com.mysql.jdbc.Driver");
		bds.setUrl("jdbc:mysql://localhost/commons");
		bds.setUsername("root");
		bds.setPassword("");

		bds.setInitialSize(5);

		return bds.getConnection();
	}
}