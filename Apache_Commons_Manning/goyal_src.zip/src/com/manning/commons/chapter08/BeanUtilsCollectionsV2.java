package com.manning.commons.chapter08;

import org.apache.commons.beanutils.BeanPredicate;
import org.apache.commons.collections.PredicateUtils;

public class BeanUtilsCollectionsV2 {
  public static void main(String args[]) {
		BeanPredicate predicate =
		  new BeanPredicate("title", PredicateUtils.uniquePredicate());

		Movie movie = new Movie();
		movie.setTitle("The Italian Job");

		Movie movie1 = new Movie();
		movie1.setTitle("The Italian Job");

		System.err.println(predicate.evaluate(movie)); // evaluates true
		System.err.println(predicate.evaluate(movie1)); // evaluates false

	}
}