package com.manning.commons.chapter08;

import org.apache.commons.lang.CharSet;
import org.apache.commons.lang.CharRange;
import org.apache.commons.lang.ArrayUtils;

public class CharSetExampleV1 {

	public static void main(String args[]) {
		CharSet set = CharSet.getInstance("the apprentice");
		System.err.println(set.contains('q'));
		CharRange[] range = set.getCharRanges();

		System.err.println(ArrayUtils.toString(range));
	}
}