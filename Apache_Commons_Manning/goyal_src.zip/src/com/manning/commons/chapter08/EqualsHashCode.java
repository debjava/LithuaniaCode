package com.manning.commons.chapter08;

import java.util.Map;
import java.util.HashMap;

public class EqualsHashCode {

	public static void main(String args[]) {
		Person p1 = new Person();
		p1.setName("Steven Spielberg");
		p1.setGender(1);

		Person p2 = new Person();
		p2.setName("Steven Spielberg");
		p2.setGender(1);

		System.err.println("Is P1 equal to P2? " + p1.equals(p2));

		Map personMap = new HashMap();
		personMap.put(p2, "available");

		System.err.println("Is P2 available? " + personMap.get(p1));

		Map contactMap = new HashMap();
		contactMap.put("Home", "444444444");
		contactMap.put("Mobile", "457993444");
		p2.setContactNumber(contactMap);
		System.err.println(p2);

	}
}