package com.manning.commons.chapter08;

import org.apache.commons.beanutils.Converter;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.beanutils.BeanUtilsBean;
import org.apache.commons.beanutils.ConvertUtilsBean;
import org.apache.commons.beanutils.PropertyUtilsBean;
import org.apache.commons.beanutils.ConversionException;

import java.util.Map;

public class BeanUtilsExampleV4 {
  public static void main(String args[]) throws Exception {
		BeanUtilsExampleV4 diff = new BeanUtilsExampleV4();
		Actor actor = diff.prepareData();

		ConvertUtilsBean convertUtilsBean = new ConvertUtilsBean();
		convertUtilsBean.deregister(String.class);
		convertUtilsBean.register(new MyStringConverter(), String.class);

		convertUtilsBean.deregister(Long.class);
		convertUtilsBean.register(new MyLongConverter(), Long.class);
		convertUtilsBean.register(new MyLongConverter(), Long.TYPE);

		BeanUtilsBean beanUtilsBean =
		  new BeanUtilsBean(convertUtilsBean, new PropertyUtilsBean());

		System.err.println("==== Values before calling describe ==== ");
		System.err.println("By PropertyUtils: " +
		  PropertyUtils.getProperty(actor, "name"));
		System.err.println("By BeanUtils: " +
		  beanUtilsBean.getProperty(actor, "name"));
		System.err.println(beanUtilsBean.getProperty(actor, "worth"));

		Map describedData = beanUtilsBean.describe(actor);

		// check the map
		System.err.println("==== Values in Map ==== ");
		System.err.println(describedData.get("name"));
		System.err.println(describedData.get("worth"));

		// create a new Actor Bean
		Actor newActor = new Actor();
		beanUtilsBean.populate(newActor, describedData);

		System.err.println("==== Values after calling populate ==== ");
		System.err.println(beanUtilsBean.getProperty(newActor, "name"));
		System.err.println(beanUtilsBean.getProperty(newActor, "worth"));

  }

  private Actor prepareData() {
		Actor actor = new Actor();
		actor.setName("Michael Caine");
		actor.setGender(1);
		actor.setWorth(10000000);
		return actor;
	}
}

class MyStringConverter implements Converter {
	public Object convert(Class type, Object value) {
		if(value == null) {
		  return (String)null;
		} else {
		  return (value.toString().replaceAll("\\s", ""));
		}
	}
}

class MyLongConverter implements Converter {

	private Object defaultValue;
	private boolean useDefault;

  public MyLongConverter() {
		this(true, new Long(0));
	}

	public MyLongConverter(boolean useDefault, Object defaultValue) {
		this.useDefault = useDefault;
		this.defaultValue = defaultValue;
	}

	public Object convert(Class type, Object value) {
		if(value == null) {
			if(useDefault) {
				return defaultValue;
			} else {
				throw new ConversionException("No default value specified");
			}
		}

		if(value instanceof Long) {
			return new Long(((Long)value).longValue() + 1000);
		} else {
			try {
				return new Long(new Long(value.toString()).longValue() + 1000);
			} catch (Exception e) {
				System.err.println(e);
				if(useDefault) {
					return defaultValue;
				} else {
					throw new ConversionException(e);
				}
			}
		}

	}
}