package com.manning.commons.chapter08;

import org.apache.commons.lang.math.Fraction;

public class FractionExampleV1 {
	public static void main(String args[]) {
		Fraction twoThirds = Fraction.TWO_THIRDS;
		Fraction fraction_whole  = Fraction.getFraction(2, 2, 3);
		Fraction fraction  = Fraction.getFraction(27, 98);
		Fraction fraction_double = Fraction.getFraction(4.56);
		Fraction fraction_string = Fraction.getFraction("2 1/3");

		System.err.println(twoThirds.doubleValue());
		System.err.println(fraction_string.getNumerator());
		System.err.println(fraction_whole.divideBy(fraction_double));
		System.err.println(fraction.divideBy(fraction));
	}
}