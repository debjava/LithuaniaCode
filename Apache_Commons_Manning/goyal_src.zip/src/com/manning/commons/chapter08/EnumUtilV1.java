package com.manning.commons.chapter08;

import org.apache.commons.lang.enum.EnumUtils;

import java.util.Iterator;

public class EnumUtilV1 {
  public static void main(String args[]) {

		System.err.println(EmotionEnum.getEnum("Fear"));

		System.err.println(EnumUtils.getEnum(EmotionEnum.class, "Fear"));

		Iterator itr = EnumUtils.iterator(EmotionEnum.class);
		while(itr.hasNext()) {
			System.err.println(itr.next());
		}
  }
}