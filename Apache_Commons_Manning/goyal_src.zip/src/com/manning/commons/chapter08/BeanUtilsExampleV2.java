package com.manning.commons.chapter08;

import org.apache.commons.beanutils.BeanUtils;

import java.util.Map;
import java.util.Date;
import java.util.List;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.GregorianCalendar;

public class BeanUtilsExampleV2 {
  public static void main(String args[]) throws Exception {
		BeanUtilsExampleV2 diff = new BeanUtilsExampleV2();
		Movie movieBean = diff.prepareData();

		// create a new Movie with the same properties
		Movie newMovieBean = new Movie();
		BeanUtils.copyProperties(newMovieBean, movieBean);
		// Movie newMovieBean = (Movie)BeanUtils.cloneBean(movieBean);

		// change its title
		BeanUtils.setProperty(newMovieBean, "title", "Quills");

		// and date
		BeanUtils.setProperty(
			newMovieBean,
			"dateOfRelease",
			new GregorianCalendar(2000, 0, 1).getTime());

		// and director name
		BeanUtils.setProperty(newMovieBean, "director.name", "Philip Kaufman");

		// and director's home number
		BeanUtils.setProperty(
			newMovieBean,
			"director.contactNumber(Home)",
			"3349084333");

		System.err.println(BeanUtils.getProperty(movieBean, "title"));
		System.err.println(BeanUtils.getProperty(movieBean, "director.name"));
		System.err.println(BeanUtils.getProperty(
			newMovieBean,
			"director.contactNumber(Home)"));
  }

  private Movie prepareData() {
		Movie movie = new Movie();
		movie.setTitle("The Italian Job");
		movie.setDateOfRelease(new GregorianCalendar(1969, 0, 1).getTime());

		// sets the genre
		Map genre_map = new HashMap();
		genre_map.put("THR", "Thriller");
		genre_map.put("ACT", "Action");

		movie.setGenre(genre_map);

		// creates the Director
		Person director = new Person();
		director.setName("Peter Collinson");
		director.setGender(1);
		Map director_contacts = new HashMap();
		director_contacts.put("Home", "99922233");
		director_contacts.put("Mobile", "0343343433");
		director.setContactNumber(director_contacts);

		movie.setDirector(director);

		// create the actors
		Actor actor1 = new Actor();
		actor1.setName("Michael Caine");
		actor1.setGender(1);
		actor1.setWorth(10000000);
		List actor1_movies = new ArrayList();

		Movie movie2 = new Movie();
		movie2.setTitle("The Fourth Protocol");

		Movie movie3 = new Movie();
		movie3.setTitle("Shiner");

		actor1_movies.add(movie2);
		actor1_movies.add(movie3);

		actor1.setMovieCredits(actor1_movies);

		Actor actor2 = new Actor();
		actor2.setName("Margaret Blye");
		actor2.setGender(2);
		actor2.setWorth(20000000);

		List actors = new ArrayList();
		actors.add(actor1);
		actors.add(actor2);

		movie.setActors(actors);

		return movie;
	}
}