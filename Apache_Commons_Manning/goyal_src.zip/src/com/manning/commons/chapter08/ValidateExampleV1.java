package com.manning.commons.chapter08;

import org.apache.commons.lang.Validate;

import java.util.List;
import java.util.ArrayList;

public class ValidateExampleV1 {

	public static void main(String args[]) {
		int i = 35;
		Validate.isTrue(i > 30); // Passes ok
		// Validate.isTrue(i > 40, "Invalid value: ", i); // throws custom Exception

		List data = new ArrayList();
		// Validate.notEmpty(data, "Collection cannot be empty"); // throws custom Exception

		data.add(null);
		Validate.noNullElements(data, "Collection contains null elements"); // throws custom Exception

	}
}