package com.manning.commons.chapter08;

import org.apache.commons.lang.time.DateUtils;

import java.util.Date;
import java.util.Calendar;
import java.util.Iterator;
import java.util.GregorianCalendar;

public class DateUtilsV1 {
  public static void main(String args[]) {
		GregorianCalendar calendar =
		  new GregorianCalendar(1974, 5, 25, 6, 30, 30);
		Date date = calendar.getTime();

		System.err.println("Original Date: " + date);
		System.err.println("Rounded Date: " +
			DateUtils.round(date, Calendar.HOUR));
		System.err.println("Truncated Date: " +
			DateUtils.truncate(date, Calendar.MONTH));

		Iterator itr =
		  DateUtils.iterator(date, DateUtils.RANGE_WEEK_MONDAY);

		while(itr.hasNext()) {
			System.err.println(((Calendar)itr.next()).getTime());
		}
	}

}
