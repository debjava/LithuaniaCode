package com.manning.commons.chapter07;

import java.util.Map;
import java.util.HashMap;

public class TestBean {
	private Map testMap;

	public Map getTestMap() {
		return this.testMap;
	}
	public void setTestMap(Map testMap) {
		this.testMap = testMap;
	}
}