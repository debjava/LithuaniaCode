package com.manning.commons.chapter07;

import org.apache.commons.collections.Buffer;
import org.apache.commons.collections.buffer.BlockingBuffer;
import org.apache.commons.collections.buffer.PriorityBuffer;

public class BufferExampleV1 {
	public static void main(String args[]) {
		Buffer buffer = new PriorityBuffer();

		// add two elements
		buffer.add("2");
		buffer.add("1");

		// decorate Buffer
		buffer = BlockingBuffer.decorate(buffer);

		buffer.remove();

		System.err.println(buffer);
		// remove all elements
		buffer.clear();

		AddElementThread runner = new AddElementThread(buffer);
		runner.start();

		// call remove again - will block till thread adds an element after 2 seconds
		buffer.remove();

		System.err.println(buffer);
	}

}

class AddElementThread extends Thread {
	private Buffer buffer;

	public AddElementThread(Buffer buffer) {

		this.buffer = buffer;
	}

	public void run() {
		try {
			sleep(2000);
		} catch (InterruptedException ie) {}

		buffer.add("3");
	}
}