package com.manning.commons.chapter07;

import org.apache.commons.collections.Closure;
import org.apache.commons.collections.ClosureUtils;
import org.apache.commons.collections.PredicateUtils;

public class ClosureExampleV1 {
	public static void main(String args[]) {
		Closure ifClosure =
		  ClosureUtils.ifClosure(
				PredicateUtils.equalPredicate(new Integer(20)),
				ClosureUtils.nopClosure(),
				ClosureUtils.exceptionClosure());
		ifClosure.execute(new Integer(20));
		ifClosure.execute(new Integer(30));
	}
}