package com.manning.commons.chapter07;

import org.apache.commons.collections.Predicate;
import org.apache.commons.collections.PredicateUtils;

public class DecoratorTesterV3 {

	Predicate uniquePredicate = PredicateUtils.uniquePredicate();
	Predicate equalPredicate  = PredicateUtils.equalPredicate(new Long(1));

	Predicate anyPredicate    =
	  PredicateUtils.anyPredicate(
			new Predicate[] {uniquePredicate, equalPredicate});

	public static void main(String args[]) {
		HighSalaryDecorator hsd = new HighSalaryDecorator(new Salary());
		System.err.println(hsd.getSalary());
	}

	public void setEmployeeSalary(long salary) {
		// no two employees should receive the same salary
		// or only volunteers with a salary of 1 should be allowed
		if(anyPredicate.evaluate(new Long(salary))) {
			// proceed to set the salary
		} else {
			System.err.println("Same salary " + salary + " amount already set");
		}
	}
}
