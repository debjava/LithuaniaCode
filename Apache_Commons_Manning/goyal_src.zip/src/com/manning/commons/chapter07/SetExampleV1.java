package com.manning.commons.chapter07;

import org.apache.commons.collections.set.MapBackedSet;

import java.util.Map;
import java.util.Set;
import java.util.HashMap;
import java.util.Iterator;

public class SetExampleV1 {
	public static void main(String args[]) {
		// create a Map
		Map map = new HashMap();
		map.put("Key1", "Value1");

		// create the decoration
		Set set = MapBackedSet.decorate(map);

		map.put("Key2", "Any dummy value");
		set.add("Key3");

		Iterator itr = set.iterator();

		while(itr.hasNext()) {
			System.err.println(itr.next());
		}

	}
}