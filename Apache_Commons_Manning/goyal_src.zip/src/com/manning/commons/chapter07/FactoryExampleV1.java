package com.manning.commons.chapter07;

import org.apache.commons.collections.Factory;
import org.apache.commons.collections.FactoryUtils;

public class FactoryExampleV1 {
	public static void main(String args[]) {
		Factory bufferFactory =
		  FactoryUtils.instantiateFactory(
				StringBuffer.class,
				new Class[] {String.class},
				new Object[] {"Do you like Functors?"});
		System.err.println(bufferFactory.create());
	}
}