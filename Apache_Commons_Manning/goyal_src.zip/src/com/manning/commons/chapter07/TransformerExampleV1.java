package com.manning.commons.chapter07;

import org.apache.commons.collections.Transformer;
import org.apache.commons.collections.TransformerUtils;

public class TransformerExampleV1 {
  public static void main(String args[]) {
		Transformer transformer =
		  TransformerUtils.invokerTransformer(
				"append",
				new Class[] {String.class},
				new Object[] {" a Transformer?"});
		Object newObject =
		  transformer.transform(new StringBuffer("Are you"));
		System.err.println(newObject);
  }
}