package com.manning.commons.chapter07;

import org.apache.commons.collections.comparators.ComparatorChain;

import java.util.Arrays;
import java.util.Comparator;

public class ComparatorExampleV2 {
	public static void main(String args[]) {
		prepareData();

		ComparatorChain chain = new ComparatorChain();
		chain.addComparator(new NameComparator());
		chain.addComparator(new NumberComparator());

		printArray(dataArray);

		Arrays.sort(dataArray, chain);

		printArray(dataArray);
	}

	private static void prepareData() {
		dataArray[0] = "Shashwat-4";
		dataArray[1] = "Sarthak-8";
		dataArray[2] = "Kartik-11";
		dataArray[3] = "Kartik-14";
		dataArray[4] = "Waris-14";
		dataArray[5] = "Shashwat-20";
		dataArray[6] = "Waris-5";
	}

	private static void printArray(String[] array) {
		System.err.println("---- Elements in Array ---- ");
		for(int i = 0; i < array.length; i++) {
			System.err.print(array[i] + ", ");
		}
		System.err.println("");
	}

	private static String[] dataArray = new String[7];
}


class NameComparator implements Comparator {
	public int compare(Object o1, Object o2) {
		if(o1 instanceof String && o2 instanceof String) {
			String s1 = (String)o1;
			String s2 = (String)o2;
			s1 = s1.substring(0, s1.indexOf("-"));
			s2 = s2.substring(0, s2.indexOf("-"));
			return s1.compareTo(s2);
		}
		return 0;
	}
}

class NumberComparator implements Comparator {
	public int compare(Object o1, Object o2) {
		if(o1 instanceof String && o2 instanceof String) {
			String s1 = (String)o1;
			String s2 = (String)o2;
			Integer i1 = new Integer(s1.substring(s1.indexOf("-"), s1.length()));
			Integer i2 = new Integer(s2.substring(s2.indexOf("-"), s2.length()));
			return i1.compareTo(i2);
		}
		return 0;
	}
}