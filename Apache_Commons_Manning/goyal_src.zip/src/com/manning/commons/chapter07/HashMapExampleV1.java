package com.manning.commons.chapter07;

import org.apache.commons.collections.BidiMap;
import org.apache.commons.collections.bidimap.DualHashBidiMap;

public class HashMapExampleV1 {
	public static void main(String args[]) {
		BidiMap agentToCode = new DualHashBidiMap();
		agentToCode.put("007", "Bond");
		agentToCode.put("006", "Trevelyan");
		agentToCode.put("002", "Fairbanks");

		System.err.println("Agent name from code: " +
		  agentToCode.get("007"));
		System.err.println("Code from Agent name: " +
		  agentToCode.getKey("Bond"));
	}
}