package com.manning.commons.chapter07;

import org.apache.commons.collections.ComparatorUtils;
import org.apache.commons.collections.comparators.BooleanComparator;
import org.apache.commons.collections.comparators.FixedOrderComparator;

import java.util.Arrays;
import java.util.Comparator;

public class ComparatorExampleV1 {
	public static void main(String args[]) {
		ComparatorExampleV1 example = new ComparatorExampleV1();
		example.createComparators();

		Arrays.sort(boolParams, boolComp); // all true together first

		example.printArray(boolParams);

		Arrays.sort(stringParams); // sorts alphabetically

		example.printArray(stringParams);

		Arrays.sort(stringParams, fixedComp); // sorts by size, // cannot add more params now

		example.printArray(stringParams);
	}

	private void createComparators() {
		boolComp = ComparatorUtils.booleanComparator(true);
		fixedComp = new FixedOrderComparator(stringParams);
	}

	private void printArray(Object[] array) {
		for(int i = 0; i < array.length; i++)
		  System.err.println(array[i]);
	}

	private static Comparator boolComp;
	private static Comparator fixedComp;

	private static Boolean boolParams[] =
	 {new Boolean(true), new Boolean(true),
	 new Boolean(false), new Boolean(false)};
	private static String  stringParams[] =
	  {"Russia", "Canada", "USA", "Australia", "India"}; // sorted by size
}