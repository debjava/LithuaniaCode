package com.manning.commons.chapter07;

public class DecoratorTesterV1 {
	public static void main(String args[]) {
		HighSalaryDecorator hsd = new HighSalaryDecorator(new Salary());
		System.err.println(hsd.getSalary());
	}
}

class HighSalaryDecorator {
	Salary salary;
	public HighSalaryDecorator(Salary salary) {
	  this.salary = salary;
	}

	public long getSalary() {
		return (salary.getBaseSalary() + 20000);
	}
}

class Salary {
  public long getBaseSalary() {
    return 50000;
  }
}