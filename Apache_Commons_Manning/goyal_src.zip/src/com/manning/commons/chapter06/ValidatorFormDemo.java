package com.manning.commons.chapter06;

import javax.swing.JFrame;

public class ValidatorFormDemo extends JFrame{
}