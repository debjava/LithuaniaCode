package com.manning.commons.chapter06;

import org.apache.commons.validator.Field;
import org.apache.commons.validator.ISBNValidator;
import org.apache.commons.validator.GenericValidator;
import org.apache.commons.validator.GenericTypeValidator;
import org.apache.commons.validator.util.ValidatorUtils;

public class ValidatorWrapper {

	/* Checks if the value is present */
	public static boolean doRequired(Object bean, Field field) {
		String value =
		  ValidatorUtils.getValueAsString(bean, field.getProperty());
		return !GenericValidator.isBlankOrNull(value);
	}

	/* Checks if the value is positive numeric */
	public static boolean doNumeric(Object bean, Field field) {
		String value =
		  ValidatorUtils.getValueAsString(bean, field.getProperty());

		// GenericTypeValidator converts values to their respective types
		Integer valInt = GenericTypeValidator.formatInt(value);
		if(valInt == null) return false;
		return valInt.intValue() > 0;
	}

	/* Checks if the value is a date */
	public static boolean doDate(Object bean, Field field) {
		String value =
		  ValidatorUtils.getValueAsString(bean, field.getProperty());

		// use getVarValue to get value of a variable
		String datePattern = field.getVarValue("datePattern");
		return
		  (GenericTypeValidator.formatDate(
				value,
				datePattern,
				false) == null) ? false : true;
	}

	/* Checks if the value is within a given integral range */
	public static boolean doRange(Object bean, Field field) {
		String value =
		  ValidatorUtils.getValueAsString(bean, field.getProperty());
		String min = field.getVarValue("min");
		String max = field.getVarValue("max");

		try {
			// if any of these parse fail, false will be returned
			int valueInt = Integer.parseInt(value);
			int minInt = Integer.parseInt(min);
			int maxInt = Integer.parseInt(max);

			return GenericValidator.isInRange(valueInt, minInt, maxInt);
		} catch (Exception e) { return false; }

	}

	/* Checks if a value represents an email */
	public static boolean doEmail(Object bean, Field field) {
		String value =
		  ValidatorUtils.getValueAsString(bean, field.getProperty());
		return GenericValidator.isEmail(value);
	}

	/* Checks if a value represents a URL */
	public static boolean doURL(Object bean, Field field) {
		String value =
		  ValidatorUtils.getValueAsString(bean, field.getProperty());
		return GenericValidator.isUrl(value);
	}

	/* Checks if a value matches the given regexp */
	public static boolean doRegExp(Object bean, Field field) {
		String value =
		  ValidatorUtils.getValueAsString(bean, field.getProperty());
		String expression = field.getVarValue("expression");
		return GenericValidator.matchRegexp(value, expression);
	}

	/* Checks if a value represents a credit card */
	public static boolean doCreditCard(Object bean, Field field) {
		String value =
		  ValidatorUtils.getValueAsString(bean, field.getProperty());
		return GenericValidator.isCreditCard(value);
	}

	/* Checks if a value represents an ISBN number */
	public static boolean doISBN(Object bean, Field field) {
		String value =
		  ValidatorUtils.getValueAsString(bean, field.getProperty());
		return new ISBNValidator().isValid(value);
	}
}