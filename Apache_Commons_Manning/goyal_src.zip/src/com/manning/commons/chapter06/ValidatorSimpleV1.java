package com.manning.commons.chapter06;

import org.apache.commons.validator.Validator;
import org.apache.commons.validator.ValidatorResult;
import org.apache.commons.validator.ValidatorResults;
import org.apache.commons.validator.ValidatorResources;

import java.io.FileInputStream;

public class ValidatorSimpleV1 {
	public static void main(String args[]) throws Exception {

		// first load the targeted rules
		ValidatorResources resources =
		  new ValidatorResources(
				new FileInputStream("validatorsimple.xml"));

		// next accept user input as a JavaBean
		Object userData = simulateUserData();

		// create an instance of the Validator passing in the
		// targeted rules
		Validator validator = new Validator(resources, "simpleform");

		// and pass in the bean to validate
		validator.setParameter(Validator.BEAN_PARAM, userData);

		// finally validate and retrive the results
		ValidatorResults results = validator.validate();

		ValidatorResult result = results.getValidatorResult("firstName");
    ValidatorResult result1 = results.getValidatorResult("lastName");

		System.err.println("First Name: " + result.isValid("required"));
		System.err.println("Last Name: " + result1.isValid("required"));
	}

	private static Object simulateUserData() {
		SimpleJavaBeanV1 simpleBean = new SimpleJavaBeanV1();
		simpleBean.setLastName("Goyal");
		return simpleBean;
	}
}