package com.manning.commons.chapter06;

public class WebJavaBeanV1 {
  private String required;
  private String numeric;
  private String date;
  private String range;
  private String email;
  private String url;
  private String regExp;
  private String cc;
  private String isbn;
  private String multi;

  public String getRequired() { return this.required; }
  public void setRequired(String required) { this.required = required; }

  public String getNumeric() { return this.numeric; }
  public void setNumeric(String numeric) { this.numeric = numeric; }

  public String getDate() { return this.date; }
  public void setDate(String date) { this.date = date; }

  public String getRange() { return this.range; }
  public void setRange(String range) { this.range = range; }

  public String getEmail() { return this.email; }
  public void setEmail(String email) { this.email = email; }

  public String getUrl() { return this.url; }
  public void setUrl(String url) { this.url = url; }

  public String getRegExp() { return this.regExp; }
  public void setRegExp(String regExp) { this.regExp = regExp; }

  public String getCc() { return this.cc; }
  public void setCc(String cc) { this.cc = cc; }

  public String getIsbn() { return this.isbn; }
  public void setIsbn(String isbn) { this.isbn = isbn; }

  public String getMulti() { return this.multi; }
  public void setMulti(String multi) { this.multi = multi; }

}