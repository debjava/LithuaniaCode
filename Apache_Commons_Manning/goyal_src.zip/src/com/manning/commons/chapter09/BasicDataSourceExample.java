package com.manning.commons.chapter09;

import java.sql.Connection;

import org.apache.commons.dbcp.BasicDataSource;

public class BasicDataSourceExample {

	public static void main(String args[]) throws Exception {

		BasicDataSource bds = new BasicDataSource();
		bds.setDriverClassName("com.mysql.jdbc.Driver");
		bds.setUrl("jdbc:mysql://localhost/commons");
		bds.setUsername("root");
		bds.setPassword("");

		bds.setInitialSize(5);

		Connection connection = bds.getConnection();

		System.err.println(connection);
		connection.close();
	}
}