package com.manning.commons.chapter09;

import org.apache.commons.pool.impl.GenericObjectPool;

public class TestObjectPool {

	public static void main(String args[]) throws Exception {

		GenericObjectPool pool = new GenericObjectPool();
		pool.setFactory(new EmployeeFactory());

		/*First way of initializing pool
		pool.setMinIdle(5);
		pool.setTimeBetweenEvictionRunsMillis(500);
		Thread.currentThread().sleep(600);*/

		/* second, and preferred way */
		for(int i = 0; i < 5; ++i) {
			pool.addObject();
		}

		// pool.setTestOnReturn(true);
		pool.setMinEvictableIdleTimeMillis(1000);
		pool.setTimeBetweenEvictionRunsMillis(600);

		System.err.println("Number of employees in pool: " + pool.getNumIdle());

    Thread.currentThread().sleep(1500);

		Employee employee = (Employee)pool.borrowObject();

		employee.setName("Fred Flintstone");
		employee.doWork();

		System.err.println("Employee: "  + employee);

		pool.returnObject(employee);

    System.err.println("Number of employees in pool: " + pool.getNumIdle());
	}
}
