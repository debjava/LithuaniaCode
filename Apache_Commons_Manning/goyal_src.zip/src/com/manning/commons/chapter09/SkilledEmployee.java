package com.manning.commons.chapter09;

public class SkilledEmployee extends Employee {

	private String skill;

	public SkilledEmployee(String skill) {
		this.skill = skill;
	}

	public String getSkill() {
		return this.skill;
	}

	public String toString() {
		return getSkill() + " -- " + getName();
	}
}