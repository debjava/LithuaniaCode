package com.manning.commons.chapter09;

import java.util.HashMap;

import org.apache.commons.pool.impl.SoftReferenceObjectPool;

public class TestRedundantObjectPool {


	public static void main(String args[]) throws Exception {

		SoftReferenceObjectPool pool =
		  new SoftReferenceObjectPool(new EmployeeFactory(), 5);

		try{

			System.err.println("Number of employees in pool: " + pool.getNumIdle());

			Employee employee = (Employee)pool.borrowObject();

			System.err.println("Borrowed Employee: " + employee);

			employee.doWork();

			pool.returnObject(employee);

			// employee = null;

			HashMap map = new HashMap();

			System.err.println("Running memory intensive operation");
			for(int i = 0; i < 1000000; i++) {
				map.put(new Integer(i), new String("Fred Flintstone" + i));
			}

		}catch(OutOfMemoryError e) {
			System.err.println("Borrowed employee after OutOfMemory: " +
			  pool.borrowObject());
			System.err.println("Error: "  + e);
		}
	}
}