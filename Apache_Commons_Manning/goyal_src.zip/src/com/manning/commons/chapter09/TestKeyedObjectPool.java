package com.manning.commons.chapter09;

import org.apache.commons.pool.impl.GenericKeyedObjectPool;

public class TestKeyedObjectPool {

	public static void main(String args[]) throws Exception {

		GenericKeyedObjectPool pool = new GenericKeyedObjectPool();
		pool.setFactory(new SkilledEmployeeFactory());

		pool.addObject("Java");
		pool.addObject("Java");
		pool.addObject("VB");
		pool.addObject("C++");

		System.err.println("Number of Java employees in pool: " +
		  pool.getNumIdle("Java") + " out of total employees: " +
		  pool.getNumIdle());

		Employee employee = (Employee)pool.borrowObject("Java");

		employee.doWork();

		System.err.println("Employee: "  + employee);

		pool.returnObject("Java", employee);

		System.err.println("Number of Java employees in pool: " +
		  pool.getNumIdle("Java") + " out of total employees: " +
		  pool.getNumIdle());
	}
}