package com.manning.commons.chapter09;

import org.apache.commons.pool.BaseKeyedPoolableObjectFactory;

public class SkilledEmployeeFactory extends BaseKeyedPoolableObjectFactory {

	public Object makeObject(Object key) {
		if(key == null || !(key instanceof String) || ((String)key).length() == 0)
		  throw new IllegalArgumentException("Invalid key specified");
		return new SkilledEmployee(key.toString());
	}

	/*public boolean validateObject(Object key, Object obj) {
		if(obj instanceof Employee) {
			if(((Employee)obj).getName() == null)
			  return true;
		}
		return false;
	}

	public void passivateObject(Object obj) throws Exception {
		if(obj instanceof Employee) {
		  ((Employee)obj).setName(null);
		} else throw new Exception("Unknown object");
	}*/
}