package com.manning.commons.chapter09;

import java.sql.Connection;
import java.sql.DriverManager;

import java.util.Properties;

import org.apache.commons.dbcp.PoolingDriver;
import org.apache.commons.dbcp.ConnectionFactory;
import org.apache.commons.dbcp.DriverConnectionFactory;
import org.apache.commons.dbcp.PoolableConnectionFactory;

import org.apache.commons.pool.impl.GenericObjectPool;

public class ConnectionPoolDriverBasics {

  public static void main(String args[]) throws Exception {

    /*GenericObjectPool gPool = new GenericObjectPool();

    Properties props = new Properties();
    props.setProperty("User", "root");
    props.setProperty("Password", "");

    ConnectionFactory cf =
      new DriverConnectionFactory(new com.mysql.jdbc.Driver(),
                                  "jdbc:mysql://localhost/commons",
                                  props);

    PoolableConnectionFactory pcf =
      new PoolableConnectionFactory(cf,
                                    gPool,
                                    null,
                                    null,
                                    false,
                                    true);

    // PoolingDriver pd = new PoolingDriver();
    // pd.registerPool("driverexample", gPool);

    for(int i = 0; i < 5; i++) {
      gPool.addObject();
    }*/

    Class.forName("org.apache.commons.dbcp.PoolingDriver");
		if(null == System.getProperty("org.xml.sax.driver")) {
				System.setProperty("org.xml.sax.driver","org.apache.xerces.parsers.SAXParser");
		}
    Connection conn =
    	DriverManager.getConnection("jdbc:apache:commons:dbcp:/driverexample");

    // do some work with the connection

    conn.close();

  }
}
