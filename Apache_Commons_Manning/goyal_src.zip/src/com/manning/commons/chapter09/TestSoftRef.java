package com.manning.commons.chapter09;

import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.apache.commons.pool.PoolableObjectFactory;
import org.apache.commons.pool.impl.SoftReferenceObjectPool;

import java.util.HashMap;
import java.lang.ref.SoftReference;

public class TestSoftRef extends TestCase {

	private SoftReferenceObjectPool pool;

  public static TestSuite suite() {
    return new TestSuite(TestSoftRef.class);
  }

  public static void main(String[] args) {
		String[] testClassName = { TestSoftRef.class.getName() };
    junit.textui.TestRunner.main(testClassName);
  }

  public TestSoftRef(String s) {
    super(s);
  }

public void testOutOfMemory() throws Exception {

	Object obj = pool.borrowObject();
	pool.returnObject(obj);
	obj = null;

	assertEquals(5, pool.getNumIdle());

	try {
		HashMap map = new HashMap();

		for(int i = 0; i < 1000000; i++) {
			map.put(new Integer(i), new String("Fred Flintstone" + i));
		}
	}catch(OutOfMemoryError ex) {
			pool.borrowObject();
			pool.borrowObject();
			pool.borrowObject();
			pool.borrowObject();
			pool.borrowObject();
		 // assertEquals(0, pool.getNumIdle());
	}
}

	public void setUp() throws Exception {
		this.pool = new SoftReferenceObjectPool(new PoolableObjectFactory() {
			 int counter;
			 public Object makeObject()                   { return String.valueOf(counter++); }
			 public void destroyObject( Object obj )      {}
			 public boolean validateObject( Object obj )  { return true; }
			 public void activateObject( Object obj )     {}
			 public void passivateObject( Object obj )    {}
		}, 5);
	}
}
