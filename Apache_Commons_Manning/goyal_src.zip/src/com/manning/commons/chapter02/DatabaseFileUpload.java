package com.manning.commons.chapter02;

// import java classes
import java.util.List;
import javax.sql.DataSource;
import javax.servlet.http.HttpServletRequest;

// import FileUpload classes
import org.apache.commons.fileupload.FileUploadBase;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;

public class DatabaseFileUpload extends FileUploadBase{

	// the factory that we will use for this file upload
	private DatabaseFileItemFactory fileItemFactory;

	// the datasource that will be used to add files in the database
	private DataSource dataSource;

	/**
	 *  This is the only constructor for this class.
	 *  If a datasource is not defined properly this will throw a
	 *  FileUploadException
	 */
	public DatabaseFileUpload(DataSource dataSource, String queryString)
	    throws FileUploadException{

	  super();

	  if(dataSource == null || queryString == null || queryString.length() == 0)
	    throw new FileUploadException(
				"DataSource or query string cannot be null!");

	  // beyond checking for null values, the actual datasource configuration
	  // will be tested by the DatabaseFileItemFactory
	  this.fileItemFactory = new DatabaseFileItemFactory(dataSource, queryString);
	}

	/**
	 * This returns the associated fileItemFactory, used to create file items.
	 */
	public FileItemFactory getFileItemFactory(){
	  return this.fileItemFactory;
	}

	/**
	 * This method sets the fileItemFactory to be used.
	 */
	public void setFileItemFactory(FileItemFactory fileItemFactory){
	  this.fileItemFactory = (DatabaseFileItemFactory)fileItemFactory;
	}

	/**
	 * The method that actually does the parsing of the request by passing it
	 * to the super class.
	 */
	public List parseRequest(HttpServletRequest req)
	    throws FileUploadException{
	  return parseRequest(req);
	}
}