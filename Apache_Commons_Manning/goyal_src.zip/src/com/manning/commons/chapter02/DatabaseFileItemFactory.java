package com.manning.commons.chapter02;

// import Java classes
import javax.sql.DataSource;

// import FileUpload classes
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;

public class DatabaseFileItemFactory implements FileItemFactory{

    public DatabaseFileItemFactory(DataSource dataSource, String queryString){
    }

    public FileItem createItem(
            String fieldName,
            String contentType,
            boolean isFormField,
            String fileName
            ){
      return new DatabaseFileItem(fieldName, contentType,
        isFormField, fileName);
    }

}
