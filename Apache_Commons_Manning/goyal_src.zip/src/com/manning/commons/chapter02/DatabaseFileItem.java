package com.manning.commons.chapter02;

// import Java classes
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;

// import FileUpload classes
import org.apache.commons.fileupload.FileItem;

public class DatabaseFileItem implements FileItem{

	// the original fieldName for this field
	private String fieldName;

	// the content type for this file, or null for normal form fields
	private String contentType;

	// whether or not this is a simple form field
	private boolean isFormField;

	// the name of the file as specified by the user
	private String fileName;


	public DatabaseFileItem(String fieldName, String contentType,
	                        boolean isFormField, String fileName){
	  this.fieldName = fieldName;
	  this.contentType = contentType;
	  this.isFormField = isFormField;
	  this.fileName = fileName;
	}

	public void delete(){
	}

	public byte[] get(){
		return null;
	}

	public String getContentType(){
		return this.contentType;
	}

	public String getFieldName(){
		return this.fieldName;
	}

	public InputStream getInputStream(){
		return null;
	}

	public String getName(){
		return this.fileName;
	}

	public OutputStream getOutputStream(){
		return null;
	}

	public long getSize(){
		return 0;
	}

	public String getString(){
		return null;
	}

	public String getString(String encoding){
		return null;
	}

	public boolean isFormField(){
		return this.isFormField;
	}

	public boolean isInMemory(){
		return false;
	}

	public void setFieldName(String fieldName){
		this.fieldName = fieldName;
	}

	public void setFormField(boolean isFormField){
		this.isFormField = isFormField;
	}

	public void write(File file){
		return;
	}
}