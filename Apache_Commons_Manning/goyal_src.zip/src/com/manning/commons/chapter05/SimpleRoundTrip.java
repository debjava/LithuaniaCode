package com.manning.commons.chapter05;

import java.io.File;
import java.io.FileWriter;

import org.apache.commons.betwixt.io.BeanReader;
import org.apache.commons.betwixt.io.BeanWriter;

public class SimpleRoundTrip {

  public static void main(String args[]) throws Exception {
	FileWriter fWriter = new FileWriter("output.xml");
	BeanWriter bWriter = new BeanWriter(fWriter);

	Ingredient ingredient = new Ingredient("POT", "Potato", "None");

	bWriter.write("ingredient", ingredient);
	bWriter.flush();

	BeanReader reader = new BeanReader();
	reader.registerBeanClass("ingredient", Ingredient.class);

	Ingredient ingReadFromFile =
	  (Ingredient)reader.parse(new File("output.xml"));

	System.err.println(ingReadFromFile);
  }
}