package com.manning.commons.chapter05;

import java.util.Collection;

public class Ingredient {
	private String key;
	private String name;
	private String alternate;

	public String getKey() {
		return this.key;
	}
	public void setKey(String key) {
		this.key = key;
	}

	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getAlternate() {
		return this.alternate;
	}
	public void setAlternate(String alternate) {
		this.alternate = alternate;
	}

	public Ingredient(String key, String name, String alternate) {
		this.key = key;
		this.name = name;
		this.alternate = alternate;
	}

	public String toString() {
		return "[Key=" + this.key + ", Name=" + this.name + ", Alternate=" +
		  this.alternate + "]";
	}
}