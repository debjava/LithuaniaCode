package com.manning.commons.chapter05;

import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.AbstractFactory;


public class SnackFactory extends AbstractFactory {

	public boolean createObject(JXPathContext context,
	                            Pointer pointer,
	                            Object parent,
	                            String name,
	                            int index) {

	  if((parent instanceof MealPlan) && "snack".equals(name)) {
		  ((MealPlan)parent).setSnack(new Meal(7, 3, "Fries"));
		  return true;
	  }

	  return false;
	}
}