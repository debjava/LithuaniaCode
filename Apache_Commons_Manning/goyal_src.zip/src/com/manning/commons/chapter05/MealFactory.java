package com.manning.commons.chapter05;

import java.util.ArrayList;
import java.util.Collection;

import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.AbstractFactory;

public class MealFactory extends AbstractFactory {

	public boolean createObject(JXPathContext context,
	                            Pointer pointer,
	                            Object parent,
	                            String name,
	                            int index) {

	  if((parent instanceof MealPlan) && "meals".equals(name)) {
		  if(index < 0) return false;
		  ArrayList meals = (ArrayList)((MealPlan)parent).getMeals();
		  meals.add(index, new Meal(0, 0, "Unknown Meal"));
		  return true;
	  }

	  return false;
	}
}
