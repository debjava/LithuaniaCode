package com.manning.commons.chapter05;

import java.io.File;
import java.io.FileWriter;

import org.apache.commons.betwixt.io.BeanReader;
import org.apache.commons.betwixt.io.BeanWriter;
import org.apache.commons.betwixt.BindingConfiguration;

public class CustomConversion {

  public static void main(String args[]) throws Exception {
	FileWriter fWriter = new FileWriter("output.xml");
	BeanWriter bWriter = new BeanWriter(fWriter);

	MealPlan plan = new MealPlan();

	Meal meal = new Meal(1, 1, "Potato Bake");

	Ingredient ingredient1 = new Ingredient("POT", "Potato", "None");
	Ingredient ingredient2 = new Ingredient("CRM", "Cream", "None");

	meal.addIngredient(ingredient1);
	meal.addIngredient(ingredient2);

	plan.addMeal(meal);

	bWriter.enablePrettyPrint();

	BindingConfiguration bConfig = bWriter.getBindingConfiguration();
	bConfig.setObjectStringConverter(new DateConvertor());

	bWriter.setBindingConfiguration(bConfig);

	bWriter.write("mealplan", plan);
	bWriter.flush();

	/*BeanReader reader = new BeanReader();
	reader.setBindingConfiguration(bConfig);
	reader.registerBeanClass("mealplan", MealPlan.class);

	MealPlan planReadFromFile =
	  (MealPlan)reader.parse(new File("output.xml"));

	System.err.println(planReadFromFile);*/
  }
}