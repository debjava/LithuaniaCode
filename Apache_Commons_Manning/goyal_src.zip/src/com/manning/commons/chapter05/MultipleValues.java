package com.manning.commons.chapter05;

import java.io.File;
import java.io.FileWriter;

import org.apache.commons.betwixt.io.BeanReader;
import org.apache.commons.betwixt.io.BeanWriter;

public class MultipleValues {

  public static void main(String args[]) throws Exception {
	FileWriter fWriter = new FileWriter("output.xml");
	BeanWriter bWriter = new BeanWriter(fWriter);

	Meal meal = new Meal(1, 1, "Potato Bake");

	Ingredient ingredient1 = new Ingredient("POT", "Potato", "None");
	Ingredient ingredient2 = new Ingredient("CRM", "Cream", "None");

	meal.addIngredient(ingredient1);
	meal.addIngredient(ingredient2);

	bWriter.enablePrettyPrint();

	bWriter.write("meal", meal);
	bWriter.flush();

	BeanReader reader = new BeanReader();
	reader.registerBeanClass("meal", Meal.class);

	Meal mealReadFromFile =
	  (Meal)reader.parse(new File("output.xml"));

	System.err.println(mealReadFromFile);
  }
}