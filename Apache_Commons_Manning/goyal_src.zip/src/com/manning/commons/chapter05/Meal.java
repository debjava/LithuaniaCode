package com.manning.commons.chapter05;

import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;

public class Meal {

	private int weekday;
	private int mealType;
	private String mealName;
	private Map ingredients;

	/** 0 - Sunday, 1 - Monday ..... 6 - Saturday */
	public int getWeekday() {
		return this.weekday;
	}
	public void setWeekday(int weekday) {
		this.weekday = weekday;
	}

	/** 0 - breakfast, 1 - lunch, 2 - dinner, 3 - other */
	public int getMealType() {
		return this.mealType;
	}
	public void setMealType(int mealType) {
		this.mealType = mealType;
	}

	public String getMealName() {
		return this.mealName;
	}
	public void setMealName(String mealName) {
		this.mealName = mealName;
	}

	public Map getIngredients() {
		return this.ingredients;
	}

	public void addIngredient(Ingredient ingredient) {
		ingredients.put(ingredient.getKey(), ingredient);
	}

	public Meal(int weekday, int mealType, String mealName) {
		this.weekday = weekday;
		this.mealType = mealType;
		this.mealName = mealName;

		ingredients = new HashMap();
	}

	public String toString() {
		StringBuffer buffer = new StringBuffer(
			"Meal name: " + this.mealName + ", Meal Type: " + this.mealType +
		  " Meal Day: " + this.weekday);

		buffer.append("\r\nIngredients:\r\n");

		Iterator itr = ingredients.values().iterator();
		while(itr.hasNext()) {
			buffer.append(itr.next() + "\r\n");
		}

		return buffer.toString();
	}
}
