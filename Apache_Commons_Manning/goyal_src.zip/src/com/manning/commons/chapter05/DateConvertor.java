package com.manning.commons.chapter05;

import java.text.SimpleDateFormat;

import org.apache.commons.betwixt.expression.Context;
import org.apache.commons.betwixt.strategy.ObjectStringConverter;

public class DateConvertor extends ObjectStringConverter {

  private static final SimpleDateFormat formatter
    = new SimpleDateFormat("dd-MMM-yyyy");

	public String objectToString(
		  Object object, Class type, String flavor, Context context) {

		if(object != null) {
		  if(object instanceof java.util.Date) {
				return formatter.format( (java.util.Date) object );
			}
		}

		return super.objectToString(object, type, flavor, context);
	}
}
