package com.manning.commons.chapter05;

import java.net.URL;
import java.util.Map;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.Collection;
import java.util.GregorianCalendar;

import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.Container;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.ClassFunctions;
import org.apache.commons.jxpath.xml.DocumentContainer;

public class MealPlan {

	private Date startDate;
	private Date endDate;

	private Collection meals;

	private Meal snack;

	public Date getStartDate() {
		return this.startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return this.endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Collection getMeals() {
		return this.meals;
	}

	public Meal getSnack() {
		return this.snack;
	}

	public void setSnack(Meal snack) {
		this.snack = snack;
	}

	public void addMeal(Meal meal) {
		if(meal == null)
			throw new IllegalArgumentException("Meal cannot be added null");
		meals.add(meal);
	}

	/** If this is called, it creates a MealPlan starting from now till
	 * end of week */
	public MealPlan() {
		this(null, null);
	}

	public Container loadMealPlan() {
	  URL url = getClass().getResource("/sampleXML_5.6.xml");
	  return new DocumentContainer(url);
	}

	public MealPlan(Date startDate, Date endDate) {

		if(startDate == null && endDate == null) {
			startDate = new Date();

			Calendar calendar = new GregorianCalendar();
			calendar.setTime(startDate);
			calendar.add(Calendar.WEEK_OF_YEAR, 1);

			endDate = calendar.getTime();
		}

		if(startDate == null || endDate == null || startDate.after(endDate))
			throw new IllegalArgumentException("Please check the dates");

		this.startDate = startDate;
		this.endDate = endDate;

		meals = new ArrayList();
	}

	public static void main(String args[]) {

		MealPlan plan = new MealPlan();

		plan.createMeals();
		Container alternatePlan = plan.loadMealPlan();
		JXPathContext context = JXPathContext.newContext(alternatePlan);
		System.err.println(context.getValue("mealplan/meal[1]/@name"));

		// System.err.println(plan);

		// plan.getIngredients(0);
		// plan.getDaysForIngredient("$%^");
	}

	public void getIngredients(int mealDay) {

		if(mealDay < 0 || mealDay > 6)
		  throw new IllegalArgumentException("Invalid day!");

		/*StringBuffer buffer = new StringBuffer();

		Iterator itr = meals.iterator();
		while(itr.hasNext()) {
			Meal meal = (Meal)itr.next();
			if(meal.getWeekday() == mealDay) {
				Map ingredients = meal.getIngredients();
				Iterator inner_itr = ingredients.values().iterator();
				while(inner_itr.hasNext()) {
					buffer.append(inner_itr.next() + "\r\n");
				}
			}
		}*/

		JXPathContext context = JXPathContext.newContext(this);

		// System.err.println("Number of meals: " + context.getValue("count(meals)"));
		context.getVariables().declareVariable("startDate", startDate);
		context.getVariables().declareVariable("endDate", endDate);
		// System.err.println(context.getValue("MealPlan.new($startDate, $endDate)"));
		// System.err.println(context.getValue("getTime($startDate)"));

		context.getVariables().declareVariable("mpf", new MealPlanFunctions());

		context.setFunctions(new ClassFunctions(MealPlanFunctions.class, "mpfunc"));
		System.err.println("Date Difference: " +
		  context.getValue("mpfunc:getDateDiffInDays($mpf, $startDate, $endDate)"));

		// System.err.println(context.getValue("mpfunc:getCountMealsOnDay($mpf, //meals/ingredients[@name='TMT'], 0)"));

		// System.err.println(context.getValue("mpfunc:getCountMealsOnDay($mpf, meals, 0)"));

		// context.getVariables().declareVariable("mealDay", new Integer(mealDay));
		/*Iterator itr = context.iterate("meals[weekday=$mealDay]/ingredients");
		System.err.println("Ingredients are: \r\n");
		while(itr.hasNext()) {
			System.err.println(((HashMap)itr.next()));
		}*/

		/*Iterator itr = context.iteratePointers("meals[weekday=$mealDay]/ingredients");
		while(itr.hasNext()) {
			Pointer pointer = (Pointer)itr.next();
			System.err.println(pointer + ": " + pointer.getValue());
		}*/

		// context.setValue("endDate", "2004-03");

		// System.err.println("New Date: " + context.getValue("endDate"));

		// context.setValue("//meals/ingredients[@name='TMT']/alternate", "Ketchup");
		// System.err.println(context.getPointer("//meals/ingredients[@name='TMT']/alternate"));

		// System.err.println(this);

		/*System.err.println(getSnack());
		context.setFactory(new SnackFactory());
		context.createPath("snack");
		context.setValue("snack/ingredients[@name='POT']", new Ingredient("POT", "Potatoes", "None"));*/

		/*context.setFactory(new MealFactory());
		context.createPath("meals[1]");
		context.createPath("meals[2]");*/

		// System.err.println(this);

		// System.err.println("Ingredients are: \r\n" +
			// context.getValue("meals[weekday='" + mealDay + "']/ingredients"));
		// System.err.println(context.getValue("meals[@weekday='1']/"));

		// System.err.println("Ingredients are: \r\n" + buffer.toString());

		// System.err.println("Alternate on snack ingredient: " + context.getValue("snack/ingredients"));

		// System.err.println("First Meal: " + context.getValue("meals[1]/ingredients//alternate"));
	}

	public void getDaysForIngredient(String key) {

		if(key == null || key.length() == 0)
		  throw new IllegalArgumentException("Invalid Name!");

		StringBuffer buffer = new StringBuffer();

		Iterator itr = meals.iterator();
		while(itr.hasNext()) {
			Meal meal = (Meal)itr.next();
			if(meal.getIngredients().get(key) != null) {
				buffer.append(meal.getWeekday() + "\r\n");
			}
		}

		System.err.println("Ingredient with key: " + key
		  + " is used on the following days:\r\n" + buffer.toString());

		JXPathContext context = JXPathContext.newContext(this);
		Iterator itrr = context.iterate("meals/ingredients[@name='"+ key + "']");
		while(itrr.hasNext()) {
			System.err.println(itrr.next() + "\r\n");
		}

	}

	public void createMeals() {

		Meal pastaMeal = new Meal(0, 0, "Spicy Pasta");

		Ingredient pasta = new Ingredient("$%^", "Pasta", "None");
		pastaMeal.addIngredient(pasta);

		Ingredient tomatoes = new Ingredient("TMT", "Tomatoes", "Tomato Paste");
		pastaMeal.addIngredient(tomatoes);

		this.addMeal(pastaMeal);

		Meal chickenMeal = new Meal(0, 2, "Honey Chicken");
		Ingredient chicken = new Ingredient("CHK", "Chicken", "None");
		chickenMeal.addIngredient(chicken);

		Ingredient honey = new Ingredient("HNY", "Honey", "Sugar Syrup");
		chickenMeal.addIngredient(honey);

		this.addMeal(chickenMeal);

		Meal indianMeal = new Meal(2, 2, "Butter Chicken");
		indianMeal.addIngredient(chicken);

		Ingredient butter = new Ingredient("BUT", "Butter", "Margarine");
		indianMeal.addIngredient(butter);

		this.addMeal(indianMeal);

		// snack = new Meal(7, 3, "Fries");
		// snack.addIngredient(new Ingredient("POT", "Potatoes", "None"));

	}

	public String toString() {

		StringBuffer buffer = new StringBuffer(" **** Your Meal Plan **** ");
		buffer.append("\r\nStart Date: " + this.startDate);
		buffer.append("\r\nEnd Date: " + this.endDate + "\r\n\r\n");

		Iterator itr = meals.iterator();
		while(itr.hasNext()) {
			buffer.append(itr.next() + "\r\n");
		}

		buffer.append(" ----------------------------------------------\r\n");

		return buffer.toString();
	}
}
