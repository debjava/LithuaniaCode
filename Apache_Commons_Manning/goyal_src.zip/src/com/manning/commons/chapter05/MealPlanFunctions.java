package com.manning.commons.chapter05;

import org.apache.commons.jxpath.NodeSet;
import org.apache.commons.jxpath.Pointer;

import java.util.Date;
import java.util.Iterator;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.Collection;
import java.util.GregorianCalendar;

public class MealPlanFunctions {

	public int getDateDiffInDays(Date startDate, Date endDate) {
		Calendar calendar = new GregorianCalendar();

		calendar.setTime(startDate);
		int firstWeek = calendar.get(Calendar.DAY_OF_YEAR);

		calendar.setTime(endDate);
		int secondWeek = calendar.get(Calendar.DAY_OF_YEAR);

		return (secondWeek - firstWeek);
	}

	/*public int getCountMealsOnDay(Collection meals, int day) {
		if(meals == null) throw new IllegalArgumentException("Invalid meals");

		int count = 0;
		Iterator itr = meals.iterator();
		while(itr.hasNext()) {
			Meal meal = (Meal)itr.next();
			if(meal.getWeekday() == day) count++;
		}

		return count;
	}*/


	public int getCountMealsOnDay(NodeSet meals, int day) {
		if(meals == null) throw new IllegalArgumentException("Invalid meals");

		int count = 0;
		Iterator itr = meals.getPointers().iterator();
		while(itr.hasNext()) {
			Pointer meal = (Pointer)itr.next();
			if(Integer.parseInt((String)meal.getValue()) == day) count++;
		}

		return count;
	}

	public Collection getIngredients(Meal meal) {

		Collection returnCollection = new ArrayList();
		return returnCollection;
	}
}