package com.manning.commons.chapter13;

import org.apache.commons.chain.Command;
import org.apache.commons.chain.Context;

public class StringPreProcessorCommand extends StringProcessorCommand {

	public boolean execute(Context context) {
		String currentString = (String)context.get(getMainStringKey());
		context.put(
			getMainStringKey(),
			getPreProcessingString() + currentString);
		return false;
	}

	public String getPreProcessingString() {
		return this.preProcessingString;
	}

	public void setPreProcessingString(String preProcessingString) {
		this.preProcessingString = preProcessingString;
	}

	private String preProcessingString;
}