package com.manning.commons.chapter13;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class LoggingExampleV1 {
	private static final Log log = LogFactory.getLog(LoggingExampleV1.class);

	public static void main(String args[]) {
		log.info("Starting the application using: " + log.getClass());
	}
}