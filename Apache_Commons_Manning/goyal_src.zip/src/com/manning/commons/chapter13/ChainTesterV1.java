package com.manning.commons.chapter13;

import org.apache.commons.chain.Chain;
import org.apache.commons.chain.Context;
import org.apache.commons.chain.Command;
import org.apache.commons.chain.impl.ChainBase;
import org.apache.commons.chain.impl.ContextBase;

public class ChainTesterV1 {
	public static void main(String args[]) throws Exception {
		Chain testChain = new ChainBase();

		StringPreProcessorCommand command1 = new StringPreProcessorCommand();
		command1.setPreProcessingString(" {");
		command1.setMainStringKey("main.string");

		StringPostProcessorCommand command2 = new StringPostProcessorCommand();
		command2.setPostProcessingString("} ");
		command2.setMainStringKey("main.string");

		testChain.addCommand(command1);
		testChain.addCommand(command2);

		ContextBase context = new ContextBase();
		context.put("main.string", "Chain is great");

		testChain.execute(context);

		System.err.println(context.get("main.string"));
	}
}