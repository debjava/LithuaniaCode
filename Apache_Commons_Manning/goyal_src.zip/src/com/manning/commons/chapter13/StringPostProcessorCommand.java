package com.manning.commons.chapter13;

import org.apache.commons.chain.Command;
import org.apache.commons.chain.Context;

public class StringPostProcessorCommand extends StringProcessorCommand {

	public boolean execute(Context context) {
		String currentString = (String)context.get(getMainStringKey());
		context.put(
			getMainStringKey(),
			currentString + getPostProcessingString());
		return false;
	}

	public String getPostProcessingString() {
		return this.postProcessingString;
	}

	public void setPostProcessingString(String postProcessingString) {
		this.postProcessingString = postProcessingString;
	}

	private String postProcessingString;
}