package com.manning.commons.chapter13;

import org.apache.commons.chain.Command;
import org.apache.commons.chain.Context;
import org.apache.commons.chain.web.servlet.ServletWebContext;

import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GlobalIdFilterCommand implements Command {

	public boolean execute(Context context) throws Exception {

		ServletWebContext servletContext = (ServletWebContext)context;

		HttpServletRequest request = servletContext.getRequest();

		String globalId = (String)request.getParameter(GLOBAL_ID_KEY);

		if(allowedGlobalIds.contains(globalId)) return false;
		else {
			System.err.println("Invalid Global Id found. Request not processed");
			servletContext.getResponse().setStatus(
				HttpServletResponse.SC_FORBIDDEN);
			return true;
		}
	}

	private static final Collection allowedGlobalIds = new ArrayList();

	private static final String GLOBAL_ID_KEY = "global.id";

	static {
		allowedGlobalIds.add("SK57eRt");
		allowedGlobalIds.add("Wt72fio");
	}
}
