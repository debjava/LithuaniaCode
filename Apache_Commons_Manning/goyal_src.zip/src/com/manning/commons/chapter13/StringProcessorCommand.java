package com.manning.commons.chapter13;

import org.apache.commons.chain.Command;
import org.apache.commons.chain.Context;

public abstract class StringProcessorCommand implements Command {

	public abstract boolean execute(Context context);

	public String getMainStringKey() {
		return this.mainStringKey;
	}

	public void setMainStringKey(String mainStringKey) {
		this.mainStringKey = mainStringKey;
	}

	private String mainStringKey;

}