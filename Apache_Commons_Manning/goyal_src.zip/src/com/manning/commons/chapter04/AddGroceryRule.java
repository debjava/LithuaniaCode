package com.manning.commons.chapter04;

import java.util.Map;
import org.apache.commons.digester.Rule;

public class AddGroceryRule extends Rule {

	public void end(String namespace, String name) throws Exception {
		Grocery grocery = (Grocery)digester.peek(0);
		Map supermarket = (Map)digester.peek(1);
		supermarket.put(new Integer(grocery.getId()), grocery);
	}
}
