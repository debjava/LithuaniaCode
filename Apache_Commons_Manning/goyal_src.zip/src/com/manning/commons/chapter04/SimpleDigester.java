package com.manning.commons.chapter04;

// import java packages
import java.io.IOException;

import org.xml.sax.SAXException;

// import Digester packages
import org.apache.commons.digester.Rule;
import org.apache.commons.digester.Digester;
import org.apache.commons.digester.SetNextRule;
import org.apache.commons.digester.CallParamRule;
import org.apache.commons.digester.CallMethodRule;
import org.apache.commons.digester.SetPropertyRule;
import org.apache.commons.digester.ObjectCreateRule;
import org.apache.commons.digester.SetPropertiesRule;


public class SimpleDigester {

  public static void main(String args[]) {

    Digester digester = new Digester();
    digester.setValidating(false);

    Rule objectCreate =
    	new ObjectCreateRule("com.manning.commons.chapter04.Book");

    digester.addRule("book", objectCreate);

    /*Rule propertiesSet = new SetPropertiesRule();

    digester.addRule("book", propertiesSet);

		Rule objectCreateAuthor =	new
			ObjectCreateRule("com.manning.commons.chapter04.Author");

    digester.addRule("book/author", objectCreateAuthor);

    digester.addRule("book/author", propertiesSet);

    digester.addRule("book/author",
    	new CallMethodRule("setName", 1, new Class[] {String.class}));
    digester.addRule("book/author/name", new CallParamRule(0));

    digester.addRule("book/author", new SetNextRule("addAuthor"));*/

    try {

    	Object book = digester.parse("book_4.1.xml");
    	System.err.println(book);

		} catch(IOException ioex) {	System.err.println(ioex.getMessage());
		} catch(SAXException saex) { System.err.println(saex.getMessage());
		}

  }
}
