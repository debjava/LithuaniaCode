package com.manning.commons.chapter04;

import java.util.Vector;

public class Book {

  private String title;
  private Vector authors;

  public String getTitle() { return this.title; }
  public void setTitle(String title) { this.title = title; }

  public Vector getAuthors() { return this.authors; }
  public void setAuthors(Vector authors) { this.authors = authors; }

  public void addAuthor(Author author) {
    if(authors == null) authors = new Vector();
    authors.add(author);
  }

  public String toString() {

		StringBuffer buffer = new StringBuffer("Title: " + getTitle() + "\r\n");

		if(authors != null) {
			for(int i = 0; i < authors.size(); i++) {
				buffer.append("Author " + (i + 1) + ": " + authors.get(i));
			}
		}

		return buffer.toString();
	}

}
