package com.manning.commons.chapter04;

// import java packages
import java.util.HashMap;
import java.util.Iterator;
import java.io.IOException;

import org.xml.sax.SAXException;

// import Digester packages
import org.apache.commons.digester.Rule;
import org.apache.commons.digester.Digester;

public class NamespaceAwareDigester {

  public static void main(String args[]) {

    Digester digester = new Digester();
    digester.setValidating(false);

    digester.addObjectCreate("supermarket", "java.util.HashMap");

    digester.addObjectCreate(
			"supermarket/grocery", "com.manning.commons.chapter04.Grocery");

    digester.addSetProperties("supermarket/grocery");

    digester.addObjectCreate(
			"supermarket/mynamespace:grocery", "com.manning.commons.chapter04.Grocery");

    digester.addSetProperties("supermarket/mynamespace:grocery");

    digester.addCallMethod(
			"supermarket/grocery/price", "setPrice", 0, new Class[] {int.class});

    digester.addCallMethod("supermarket/grocery/name", "setName", 0);

    digester.addRule("*/supermarket/grocery", new AddGroceryRule());
    //digester.addRule("supermarket/mynamespace:grocery", new AddGroceryRule());

    try {

    	HashMap supermarket = (HashMap)digester.parse("supermarket_4.9.xml");
    	Iterator itr = supermarket.keySet().iterator();
    	while(itr.hasNext()) {
				Integer key = (Integer)itr.next();
				System.err.println(key + "-" + supermarket.get(key));
			}
		} catch(IOException ioex) {	System.err.println(ioex.getMessage());
		} catch(SAXException saex) { System.err.println(saex.getMessage());
		}

  }
}