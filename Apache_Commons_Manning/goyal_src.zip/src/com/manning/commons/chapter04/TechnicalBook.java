package com.manning.commons.chapter04;

public class TechnicalBook extends Book {

	private int technicalCategory;

	public void setTechnicalCategory(int technicalCategory)
		{ this.technicalCategory = technicalCategory; }
	public int getTechnicalCategory() { return this.technicalCategory; }
}
