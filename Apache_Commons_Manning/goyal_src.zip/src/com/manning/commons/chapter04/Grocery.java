package com.manning.commons.chapter04;

public class Grocery {

  private int id;
  private String name;
  private int price;

  public int getId() { return this.id; }
  public void setId(int id) { this.id = id; }

  public String getName() { return this.name; }
  public void setName(String name) { this.name = name; }

  public int getPrice() { return this.price; }
  public void setPrice(int price) { this.price = price; }

  public String toString() {
		return this.name + "-" + this.price;
	}
}