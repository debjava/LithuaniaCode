package com.manning.commons.chapter04;

import org.apache.commons.digester.Digester;
import org.apache.commons.digester.RuleSetBase;

public class SupermarketRuleSet extends RuleSetBase {

	public SupermarketRuleSet() {
		this("");
	}

	public SupermarketRuleSet(String namespaceURI) {
		super();
		this.namespaceURI = namespaceURI;
	}

	public void addRuleInstances(Digester digester) {

    digester.addObjectCreate("supermarket", "java.util.HashMap");

    digester.addObjectCreate(
			"supermarket/grocery", "com.manning.commons.chapter04.Grocery");

    digester.addSetProperties("supermarket/grocery");

    digester.addCallMethod(
			"supermarket/grocery/price", "setPrice", 0, new Class[] {int.class});

    digester.addCallMethod("supermarket/grocery/name", "setName", 0);

    digester.addRule("supermarket/grocery", new AddGroceryRule());
	}
}