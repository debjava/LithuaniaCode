package com.manning.commons.chapter04;

// import java packages
import java.io.File;
import java.io.IOException;

import org.xml.sax.SAXException;

// import Digester packages
import org.apache.commons.digester.Rule;
import org.apache.commons.digester.Digester;
import org.apache.commons.digester.xmlrules.DigesterLoader;

public class SimpleDigesterV2 {

  public static void main(String args[]) {

    /*Digester digester = new Digester();
    digester.setValidating(false);

    digester.addObjectCreate("book", "com.manning.commons.chapter04.Book");
    digester.addSetProperties("book");

    digester.addObjectCreate(
			"book/author", "com.manning.commons.chapter04.Author");

    digester.addSetProperties("book/author");

    digester.addCallMethod(
			"book/author", "setName", 1, new Class[] {String.class});
    digester.addCallParam("book/author/name", 0);

    digester.addSetNext("book/author", "addAuthor");*/

    try {

			Digester digester =
				DigesterLoader.createDigester(new File("book_rules_4.15.xml").toURL());

    	Object book = digester.parse("book_4.1.xml");
    	System.err.println(book);

		} catch(IOException ioex) {	System.err.println(ioex.getMessage());
		} catch(SAXException saex) { System.err.println(saex.getMessage());
		}

  }
}
