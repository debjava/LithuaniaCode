package com.manning.commons.chapter04;

// import java packages
import java.util.HashMap;
import java.util.Iterator;
import java.io.IOException;

import org.xml.sax.SAXException;

// import Digester packages
import org.apache.commons.digester.Rule;
import org.apache.commons.digester.Digester;

public class NewRuleTest {

  public static void main(String args[]) {

    Digester digester = new Digester();
    digester.setValidating(false);

    digester.addRuleSet(new SupermarketRuleSet());
    try {

    	HashMap supermarket = (HashMap)digester.parse("supermarket_4.9.xml");
    	Iterator itr = supermarket.keySet().iterator();
    	while(itr.hasNext()) {
				Integer key = (Integer)itr.next();
				System.err.println(key + "-" + supermarket.get(key));
			}
		} catch(IOException ioex) {	System.err.println(ioex.getMessage());
		} catch(SAXException saex) { System.err.println(saex.getMessage());
		}

  }
}