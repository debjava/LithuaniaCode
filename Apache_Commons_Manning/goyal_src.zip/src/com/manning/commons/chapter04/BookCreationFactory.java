package com.manning.commons.chapter04;

import org.xml.sax.Attributes;
import org.apache.commons.digester.AbstractObjectCreationFactory;

public class BookCreationFactory extends AbstractObjectCreationFactory {

	public Object createObject(Attributes attributes) {

		Book book;
		if(attributes != null){
			book = new Book();
			book.setTitle(attributes.getValue("title"));
		}else
			throw new IllegalArgumentException("No Attributes!!");

		return book;
	}
}