package com.manning.commons.chapter11;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

/**
 * This is the original TimerApplication without any JMX stuff
 */
public class TimerApplicationOriginal extends TimerTask {

  private long delay;
  private String message;

  public TimerApplicationOriginal(long delay, String message) {
    this.delay = delay;
    this.message = message;

    Timer timer = new Timer();
    timer.schedule(this, new Date(), delay);
  }

  public long getDelay() { return this.delay; }
  public void setDelay(long delay) { this.delay = delay; }

  public String getMessage() { return this.message; }
  public void setMessage(String message) {
    this.message = message;
  }

  public void run() { System.err.println(getMessage() + new Date()); }

  public static void main(String[] args) {
    TimerApplicationOriginal timerApp =
      new TimerApplicationOriginal(15000, "The time is now: ");
  }

}
