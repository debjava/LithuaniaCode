package com.manning.commons.chapter11;

import java.util.Date;
import java.util.Timer;
import java.util.Iterator;
import java.util.TimerTask;

import javax.management.MBeanInfo;
import javax.management.Attribute;
import javax.management.DynamicMBean;
import javax.management.AttributeList;

import javax.management.MBeanAttributeInfo;
import javax.management.MBeanParameterInfo;
import javax.management.MBeanConstructorInfo;

import javax.management.AttributeNotFoundException;

public class TimerApplication extends TimerTask	implements DynamicMBean {

	private long delay;
	private String message;

	private MBeanInfo infoBean;
	private MBeanAttributeInfo delayInfo;
	private MBeanAttributeInfo messageInfo;

	public TimerApplication(long delay, String message) {
		this.delay = delay;
		this.message = message;

		Timer timer = new Timer();
		timer.schedule(this, new Date(), delay);
	}

	public Long getDelay() { return new Long(this.delay); }
	public void setDelay(Long delay) { this.delay = delay.longValue(); }

	public String getMessage() { return this.message; }
	public void setMessage(String message) {
		this.message = message;
	}

	public void run() {	System.err.println(getMessage() + new Date()); }

	public static void main(String[] args) {
		TimerApplication timerApp =
			new TimerApplication(15000, "The time is now: ");
	}

	public MBeanInfo getMBeanInfo() {

		if(infoBean == null) {

			delayInfo =
				new MBeanAttributeInfo("delay",
															 "java.lang.Long",
															 "Delay Attribute",
															 true,
															 true,
															 false);
			messageInfo =
				new MBeanAttributeInfo("message",
															 "java.lang.String",
															 "Message Attribute",
															 true,
															 true,
															 false);

			MBeanAttributeInfo[] attributes = new MBeanAttributeInfo[2];
			attributes[0] = delayInfo;
			attributes[1] = messageInfo;

			MBeanConstructorInfo[] constructors = new MBeanConstructorInfo[1];
			MBeanParameterInfo[] constructorParams = new MBeanParameterInfo[2];
			constructorParams[0] =
				new MBeanParameterInfo("delay", "lang", "Delay Param");
			constructorParams[1] =
				new MBeanParameterInfo("message", "java.lang.String", "Message Param");

			constructors[0] =
				new MBeanConstructorInfo("TimerApplication",
																 "TimerApp Constructor",
																 constructorParams);

			infoBean =
				new MBeanInfo("com.manning.commons.chapter11.TimerApplication",
											"Timer Application prints time after a delay",
											attributes,
											constructors,
											null,
											null);
		}

		return infoBean;
	}

	public Object getAttribute(String attribute)
		throws AttributeNotFoundException {

		if(attribute == null)
			throw new RuntimeException("Attribute name cannot be null");

		if(attribute.equals("delay")) return getDelay();
		else if(attribute.equals("message")) return getMessage();
		else throw new AttributeNotFoundException(attribute + " not found!");
	}

	public AttributeList getAttributes(String[] attributeNames) {

		if(attributeNames == null)
			throw new RuntimeException("Attributes cannot be null");

		AttributeList resultList = new AttributeList();

		if (attributeNames.length == 0)
	    return resultList;

		for(int i=0 ; i < attributeNames.length ; i++){
	    try {
				Object value = getAttribute((String) attributeNames[i]);
				resultList.add(new Attribute(attributeNames[i],value));
	    } catch(Exception e) { e.printStackTrace(); }
	   }

		return resultList;
	}

	public Object invoke(String actionName, Object[] params, String[] signature) {
		return null;
	}

	public void setAttribute(Attribute attribute)
		throws AttributeNotFoundException {

		if(attribute == null)
			throw new RuntimeException("Attribute name cannot be null");

		String attributeName = attribute.getName();
		Object attributeValue = attribute.getValue();

		if(attributeName.equals("delay")) setDelay((Long)attributeValue);
		else if(attributeName.equals("message")) setMessage((String)attributeValue);
		else throw new AttributeNotFoundException(attribute + " not found!");


	}

	public AttributeList setAttributes(AttributeList attributes) {

		if(attributes == null)
			throw new RuntimeException("Attributes cannot be null");

		AttributeList resultList = new AttributeList();

		if(attributes.isEmpty()) return resultList;

	  for(Iterator i = attributes.iterator(); i.hasNext();) {
	    Attribute attr = (Attribute)i.next();
	    try {
			  setAttribute(attr);
			  String name = attr.getName();
			  Object value = getAttribute(name);
			  resultList.add(new Attribute(name, value));
			} catch(Exception e) { e.printStackTrace(); }
		}

		return resultList;
	}

}
