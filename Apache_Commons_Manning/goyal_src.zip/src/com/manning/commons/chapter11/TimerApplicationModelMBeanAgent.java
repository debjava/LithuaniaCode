package com.manning.commons.chapter11;

import javax.management.ObjectName;
import javax.management.MBeanInfo;
import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.MBeanOperationInfo;
import javax.management.MBeanParameterInfo;
import javax.management.modelmbean.*;

import com.sun.jdmk.comm.HtmlAdaptorServer;

public class TimerApplicationModelMBeanAgent {

	public TimerApplicationModelMBeanAgent() {

		// first create the MBean server
		MBeanServer server =
			MBeanServerFactory.createMBeanServer("TimerDomain");

		// next create the HtmlAdaptor
		HtmlAdaptorServer adaptor = new HtmlAdaptorServer();

		// now create an MBean instance
		TimerApplicationOriginal timerApp =
			new TimerApplicationOriginal(15000, "The time is now: ");

		// create ObjectNames
		ObjectName adaptorName = null;
		ObjectName timerAppName = null;

		try {

			timerAppName = new ObjectName("TimerDomain:name=timerApp");

			RequiredModelMBean modelMBean =
				new RequiredModelMBean(buildModelMBeanInfo());

			modelMBean.setManagedResource(timerApp, "objectReference");

			server.registerMBean(modelMBean, timerAppName);

			adaptorName = new ObjectName("TimerDomain:name=adaptor, port=8082");
			adaptor.setPort(8082);

			server.registerMBean(adaptor, adaptorName);

			adaptor.start();
		} catch(Exception e) {
			System.err.println(e);
		}
	}

	private ModelMBeanInfo buildModelMBeanInfo() {

		DescriptorSupport delayDesc = new DescriptorSupport();
		delayDesc.setField("name","Delay");
		delayDesc.setField("descriptorType","attribute");
		delayDesc.setField("displayName","Delay");
		delayDesc.setField("getMethod","getDelay");
		delayDesc.setField("setMethod","setDelay");

		DescriptorSupport messageDesc = new DescriptorSupport();
		messageDesc.setField("name","Message");
		messageDesc.setField("descriptorType","attribute");
		messageDesc.setField("displayName","Message");
		messageDesc.setField("getMethod","getMessage");
		messageDesc.setField("setMethod","setMessage");

		ModelMBeanAttributeInfo delayInfo =
			new ModelMBeanAttributeInfo("delay",
														 "java.lang.Long",
														 "Delay Attribute",
														 true,
														 true,
														 false,
														 delayDesc);

		ModelMBeanAttributeInfo messageInfo =
			new ModelMBeanAttributeInfo("message",
														 "java.lang.String",
														 "Message Attribute",
														 true,
														 true,
														 false,
														 messageDesc);

		ModelMBeanAttributeInfo[] attributes =
			new ModelMBeanAttributeInfo[] {delayInfo, messageInfo };

		/*
		ModelMBeanConstructorInfo[] constructors =
			new ModelMBeanConstructorInfo[1];
		MBeanParameterInfo[] constructorParams = new MBeanParameterInfo[2];
		constructorParams[0] =
			new MBeanParameterInfo("delay", "lang", "Delay Param");
		constructorParams[1] =
			new MBeanParameterInfo("message", "java.lang.String", "Message Param");

		constructors[0] =
			new ModelMBeanConstructorInfo("TimerApplicationOriginal",
															 "TimerApp Constructor",
															 constructorParams);*/

		ModelMBeanOperationInfo[] operations = new ModelMBeanOperationInfo[4];
		MBeanParameterInfo[] params = null;

		MBeanParameterInfo[] setDelayParams =
			new MBeanParameterInfo[] { (new MBeanParameterInfo("delay",
												"java.lang.Lang",
												"new Delay value") )} ;

		MBeanParameterInfo[] setMessageParams =
			new MBeanParameterInfo[] { (new MBeanParameterInfo("message",
												"java.lang.String",
												"new Message value") )} ;

		DescriptorSupport getDelayDesc =
			new DescriptorSupport(new String[] {"name=getDelay",
							"descriptorType=operation",
							"class=com.manning.commons.chapter11.TimerApplicationOriginal",
							"role=getter"} );

		DescriptorSupport setDelayDesc =
			new DescriptorSupport(new String[] {"name=setDelay",
							"descriptorType=operation",
							"class=com.manning.commons.chapter11.TimerApplicationOriginal",
							"role=setter"} );

		DescriptorSupport getMessageDesc =
			new DescriptorSupport(new String[] {"name=getMessage",
							"descriptorType=operation",
							"class=com.manning.commons.chapter11.TimerApplicationOriginal",
							"role=getter"} );

		DescriptorSupport setMessageDesc =
			new DescriptorSupport(new String[] {"name=setMessage",
							"descriptorType=operation",
							"class=com.manning.commons.chapter11.TimerApplicationOriginal",
							"role=setter"} );

		operations[0] = new ModelMBeanOperationInfo("getDelay",
									 "get value of delay attribute",
									 params,
									 "java.lang.Lang",
									 MBeanOperationInfo.INFO,
									 getDelayDesc);

		operations[1] = new ModelMBeanOperationInfo("setDelay",
									 "set value of delay attribute",
									 setDelayParams,
									 "void",
									 MBeanOperationInfo.ACTION,
									 setDelayDesc);

		operations[2] = new ModelMBeanOperationInfo("getMessage",
									 "get value of message attribute",
									 params,
									 "java.lang.String",
									 MBeanOperationInfo.INFO,
									 getMessageDesc);

		operations[3] = new ModelMBeanOperationInfo("setMessage",
									 "set value of message attribute",
									 setMessageParams,
									 "void",
									 MBeanOperationInfo.ACTION,
									 setMessageDesc);

		DescriptorSupport beanDesc = new DescriptorSupport(new String[] {
			"name=timerApp",
			"descriptorType=MBean"});

		ModelMBeanInfoSupport infoBean =
			new ModelMBeanInfoSupport(
				"com.manning.commons.chapter11.TimerApplicationOriginal",
				"Timer Application prints time after a delay",
				attributes,
				null,
				operations,
				null,
				beanDesc);

		return infoBean;

	}

	public static void main(String[] args) {
		TimerApplicationModelMBeanAgent agent =
			new TimerApplicationModelMBeanAgent();
	}
}