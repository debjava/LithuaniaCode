package com.manning.commons.chapter11;

public interface TimerApplicationMBean {

	public long getDelay();
	public void setDelay(long delay);

	public String getMessage();
	public void setMessage(String message);

}
