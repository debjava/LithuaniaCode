package com.manning.commons.chapter11;

import java.net.URL;

import javax.management.ObjectName;

import org.apache.commons.modeler.Registry;

import com.sun.jdmk.comm.HtmlAdaptorServer;

public class TimerApplicationModelerAgent {

	public TimerApplicationModelerAgent() {

		URL url=
			this.getClass().getResource("/timer_app_11.6.xml");

		// next create the HtmlAdaptor
		HtmlAdaptorServer adaptor = new HtmlAdaptorServer();

		// now create an MBean instance
		TimerApplicationOriginal timerApp =
			new TimerApplicationOriginal(15000, "The time is now: ");

		// create ObjectNames
		ObjectName adaptorName = null;
		ObjectName timerAppName = null;

		try {

			Registry registry = Registry.getRegistry(null, null);
			registry.loadMetadata(url);

			timerAppName = new ObjectName("TimerDomain:name=timerApp");

			registry.registerComponent(
				timerApp,
				timerAppName,
				"com.manning.commons.chapter11.TimerApplicationOriginal");

			adaptorName = new ObjectName("TimerDomain:name=adaptor, port=8082");
			adaptor.setPort(8082);

			registry.registerComponent(
				adaptor,
				adaptorName,
				"com.sun.jdmk.comm.HtmlAdapterServer");

			adaptor.start();
		} catch(Exception e) {
			System.err.println(e);
		}
	}

	public static void main(String[] args) {
		TimerApplicationModelerAgent agent =
			new TimerApplicationModelerAgent();
	}
}