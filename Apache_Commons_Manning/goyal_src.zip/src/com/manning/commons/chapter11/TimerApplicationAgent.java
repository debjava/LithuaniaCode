package com.manning.commons.chapter11;

import javax.management.ObjectName;
import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;

import com.sun.jdmk.comm.HtmlAdaptorServer;

public class TimerApplicationAgent {

	public TimerApplicationAgent() {

		// first create the MBean server
		MBeanServer server =
			MBeanServerFactory.createMBeanServer("TimerDomain");

		// next create the HtmlAdaptor
		HtmlAdaptorServer adaptor = new HtmlAdaptorServer();

		// now create an MBean instance
		TimerApplication timerApp =
			new TimerApplication(15000, "The time is now: ");

		// create ObjectNames
		ObjectName adaptorName = null;
		ObjectName timerAppName = null;

		try {

			timerAppName = new ObjectName("TimerDomain:name=timerApp");

			server.registerMBean(timerApp, timerAppName);

			adaptorName = new ObjectName("TimerDomain:name=adaptor, port=8082");
			adaptor.setPort(8082);

			server.registerMBean(adaptor, adaptorName);

			adaptor.start();
		} catch(Exception e) {
			System.err.println(e);
		}
	}

	public static void main(String[] args) {
		TimerApplicationAgent agent = new TimerApplicationAgent();
	}
}