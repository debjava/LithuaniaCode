package com.manning.commons.chapter01;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.OptionsMethod;

import java.util.Enumeration;

public class OptionsMethodExampleV1 {

  public static void main(String args[]) {

		HttpClient client = new HttpClient();
		client.getParams().setParameter("http.useragent", "Test Client");

		OptionsMethod method = new OptionsMethod("http://www.verisign.com");

		try{
		  int returnCode = client.executeMethod(method);

		  Enumeration list = method.getAllowedMethods();

		  while(list.hasMoreElements()) {
				System.err.println(list.nextElement());
			}

		} catch (Exception e) {
			System.err.println(e);
		} finally {
			method.releaseConnection();
		}

  }
}