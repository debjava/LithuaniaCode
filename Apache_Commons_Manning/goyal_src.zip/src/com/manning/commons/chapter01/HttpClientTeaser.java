package com.manning.commons.chapter01;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;

public class HttpClientTeaser {

 public static void main(String args[]) throws Exception {
  HttpClient client = new HttpClient();
  GetMethod method = new GetMethod("http://www.google.com");
  int returnCode = client.executeMethod(method);
  System.err.println(method.getResponseBodyAsString());
  method.releaseConnection();
 }
}