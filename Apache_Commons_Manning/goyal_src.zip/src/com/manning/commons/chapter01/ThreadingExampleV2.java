package com.manning.commons.chapter01;

import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;

public class ThreadingExampleV2 {

  public static void main(String args[]) throws Exception {

		MultiThreadedHttpConnectionManager manager =
		  new MultiThreadedHttpConnectionManager();
		HttpConnectionManagerParams connectionManagerParams =
		  new HttpConnectionManagerParams();
		connectionManagerParams.setDefaultMaxConnectionsPerHost(5);
		manager.setParams(connectionManagerParams);

		HttpClient client = new HttpClient(manager);
		client.getParams().setParameter("http.useragent", "Test Client");

		HostConfiguration host = new HostConfiguration();
		host.setHost(new URI("http://localhost:8080", true));

		// first Get a big file
		MethodThread bigDataThread =
		  new MethodThread(client, host, "/big_movie.wmv");

		bigDataThread.start();

		// next try and get a small file
		MethodThread normalThread = new MethodThread(client, host, "/");

		normalThread.start();
	}
}