package com.manning.commons.chapter01;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpVersion;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.HostConfiguration;

public class HttpClientParameterV1 {

	public static void main(String args[]) throws Exception {

		HttpClient client = new HttpClient();
		client.getParams().setParameter("http.useragent", "My Browser");

		HostConfiguration host = client.getHostConfiguration();
		host.setHost("www.google.com");

		GetMethod method = new GetMethod("http://www.yahoo.com");

		int returnCode = client.executeMethod(host, method);

		System.err.println(method.getResponseBodyAsString());

		System.err.println("User-Agent: " +
		  method.getHostConfiguration().getParams().getParameter("http.useragent"));

		System.err.println("User-Agent: " +
		  method.getParams().getParameter("http.useragent"));

		method.releaseConnection();
	}
}