package com.manning.commons.chapter01;

import org.apache.commons.httpclient.ProxyClient;
import org.apache.commons.httpclient.ConnectMethod;
import org.apache.commons.httpclient.ProxyClient.ConnectResponse;

import java.net.Socket;

public class ConnectMethodExampleV1 {

  public static void main(String args[]) {

		ProxyClient client = new ProxyClient();
		client.getParams().setParameter(
			"http.useragent",
			"Proxy Test Client");

		client.getHostConfiguration().setHost("www.verisign.com");
		client.getHostConfiguration().setProxy(
			"localproxyaddress",
			80);

		Socket socket = null;

		try{

			ConnectResponse response = client.connect();
			socket = response.getSocket();

			if(socket != null) {

				// write your raw data over this socket

			} else {

				// connection via the socket could not be established
				ConnectMethod method = response.getConnectMethod();
				System.err.println("Socket not created: " + method.getStatusLine());
			}

		} catch (Exception e) {
			System.err.println(e);
		} finally {
			if(socket != null) try { socket.close(); } catch (Exception fe) {}
		}

  }
}