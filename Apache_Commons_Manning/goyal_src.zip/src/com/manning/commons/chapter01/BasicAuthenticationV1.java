package com.manning.commons.chapter01;

import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.HostConfiguration;

public class BasicAuthenticationV1 {

	public static void main(String args[]) throws Exception {

		HttpClient client = new HttpClient();
		client.getParams().setParameter("http.useragent", "My Browser");

		HostConfiguration host = client.getHostConfiguration();
		host.setHost(new URI("http://localhost:8080", true));

		GetMethod method = new GetMethod("/commons/chapter01/protected.jsp");
		try{
			client.executeMethod(host, method);
			System.err.println(method.getStatusLine());
			System.err.println(method.getResponseBodyAsString());
		} catch(Exception e) {
			System.err.println(e);
		} finally {
			method.releaseConnection();
		}
	}
}