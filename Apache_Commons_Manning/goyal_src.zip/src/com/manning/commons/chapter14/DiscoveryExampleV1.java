package com.manning.commons.chapter14;

import org.apache.commons.discovery.tools.DiscoverClass;

public class DiscoveryExampleV1  {
	public static void main(String args[]) throws Exception {

		DiscoverClass discoverClass = new DiscoverClass();

		// finding a class
		Class finderClass = discoverClass.find(NemoFinder.class);

		// instantiating a class
		NemoFinder finder =
		  (NemoFinder)discoverClass.newInstance(NemoFinder.class);
		finder.printMessage();
	}
}