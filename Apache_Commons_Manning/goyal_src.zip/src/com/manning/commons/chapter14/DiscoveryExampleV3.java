package com.manning.commons.chapter14;

import org.apache.commons.discovery.tools.DiscoverSingleton;

import java.util.Properties;

public class DiscoveryExampleV3  {
	public static void main(String args[]) throws Exception {

		Properties properties = new Properties();
		properties.put(
			"com.manning.commons.chapter14.NemoFinder",
			"com.manning.commons.chapter14.RedNemoFinder");

		// finding an instance of a class
		NemoFinder finder =
		   (NemoFinder)DiscoverSingleton.find(NemoFinder.class, properties);
		finder.printMessage();
	}
}