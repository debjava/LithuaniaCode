package com.manning.commons.chapter14;

public class BlueNemoFinder implements NemoFinder {
	public BlueNemoFinder() {
		super();
		System.err.println("Blue Nemo Finder");
	}
	public void printMessage() {
		System.err.println("Blue Found Nemo!");
	}
}