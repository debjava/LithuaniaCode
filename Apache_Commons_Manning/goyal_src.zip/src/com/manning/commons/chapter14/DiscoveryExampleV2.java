package com.manning.commons.chapter14;

import org.apache.commons.discovery.tools.DiscoverClass;

import java.util.Properties;

public class DiscoveryExampleV2  {
	public static void main(String args[]) throws Exception {

		DiscoverClass discoverClass = new DiscoverClass();

		Properties properties = new Properties();
		properties.put(
			"com.manning.commons.chapter14.NemoFinder",
			"com.manning.commons.chapter14.RedNemoFinder");

		// finding a class
		Class finderClass = discoverClass.find(NemoFinder.class, properties);

		// instantiating a class
		NemoFinder finder =
		  (NemoFinder)discoverClass.newInstance(NemoFinder.class, properties);
		finder.printMessage();
	}
}