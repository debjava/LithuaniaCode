package com.manning.commons.chapter14;

public interface NemoFinder {
  public void printMessage();
}