package com.manning.commons.chapter14;

import org.apache.commons.discovery.Resource;
import org.apache.commons.discovery.ResourceIterator;
import org.apache.commons.discovery.resource.ClassLoaders;
import org.apache.commons.discovery.resource.DiscoverResources;

import java.util.Iterator;

public class DiscoveryExampleV4  {
	public static void main(String args[]) throws Exception {

		DiscoveryExampleV4 example = new DiscoveryExampleV4();
		example.findResources();
	}

	private void findResources() {

		ClassLoaders loaders = new ClassLoaders();
		loaders.put(getClass().getClassLoader(), true);

		DiscoverResources resourceFinder = new DiscoverResources(loaders);
		ResourceIterator itr = resourceFinder.findResources("nemoslife");

		while(itr.hasNext()) {
			System.err.println(((Resource)itr.nextResource()));
		}

	}
}
