package com.manning.commons.chapter14;

public class RedNemoFinder implements NemoFinder {
	public RedNemoFinder() {
		super();
		System.err.println("Red Nemo Finder");
	}
	public void printMessage() {
		System.err.println("Red Found Nemo!");
	}
}