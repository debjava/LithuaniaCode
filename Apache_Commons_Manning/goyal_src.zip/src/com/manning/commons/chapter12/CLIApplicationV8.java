package com.manning.commons.chapter12;

import org.apache.commons.cli2.Group;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.CommandLine;
import org.apache.commons.cli2.util.HelpFormatter;
import org.apache.commons.cli2.commandline.Parser;
import org.apache.commons.cli2.builder.GroupBuilder;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;

public class CLIApplicationV8 {
  public static void main(String args[]) throws Exception {

    GroupBuilder gBuilder = new GroupBuilder();
    DefaultOptionBuilder oBuilder = new DefaultOptionBuilder();

    Option oName =
      oBuilder
        .withShortName("n")
        .withDescription("Print standard greeting")
        .create();

    Option oHelp =
      oBuilder
        .withShortName("h")
        .withShortName("?")
        .withLongName("help")
        .withDescription("Prints Help")
        .create();

    Group optionGroups =
      gBuilder
        .withOption(oName)
        .withOption(oHelp)
        .create();

    HelpFormatter formatter = new HelpFormatter("| ", " -- ", " |", 60);
    formatter.setShellCommand("CLIApplicationV8");
    formatter.setHeader("My Application Help");
    formatter.setFooter("Copyright @Vikram Goyal");
    formatter.setDivider(
      "|----------------------------------------------------------|");

    Parser parser = new Parser();
    parser.setGroup(optionGroups);
    parser.setHelpOption(oHelp);
    parser.setHelpFormatter(formatter);

    CommandLine commandLine = parser.parseAndHelp(args);

    if(commandLine != null && commandLine.hasOption(oName))
      System.err.println("Hello NoName");
  }
}
