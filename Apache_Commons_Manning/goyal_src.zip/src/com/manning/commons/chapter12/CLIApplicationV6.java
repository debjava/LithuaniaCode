package com.manning.commons.chapter12;

import org.apache.commons.cli2.Group;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.CommandLine;
import org.apache.commons.cli2.option.Switch;
import org.apache.commons.cli2.commandline.Parser;
import org.apache.commons.cli2.builder.GroupBuilder;
import org.apache.commons.cli2.option.PropertyOption;

public class CLIApplicationV6 {
	public static void main(String args[]) throws Exception {

		GroupBuilder gBuilder = new GroupBuilder();

		Switch sBright =
		  new Switch(
				"+",
				"-",
				"b",
				null,
				"Increase or Decrease Brightness",
				true,
				null,
				null,
				'b');

		Option pOption = new PropertyOption();

		Group gOptions =
		  gBuilder
		    .withOption(sBright)
		    .withOption(pOption)
		    .create();

		Parser parser = new Parser();
		parser.setGroup(gOptions);

		CommandLine commandLine = parser.parseAndHelp(args);

		if(commandLine != null) {
			System.err.println(commandLine.getProperty("myprop1"));
			System.err.println(commandLine.getProperty("myprop2"));
			System.err.println("Is brightness to be increased? " +
			  commandLine.getSwitch(sBright));
		}

	}
}


