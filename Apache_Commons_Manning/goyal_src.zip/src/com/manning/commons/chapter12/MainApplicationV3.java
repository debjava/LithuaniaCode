package com.manning.commons.chapter12;

import java.io.File;
import java.util.HashMap;

public class MainApplicationV3 {
	public static void main(String args[]) {
		HelperV3.processArgs(args);
		System.err.println(
			"Hello " + HelperV3.getOptionValue("n") +
			", your file size is " +
			new File(HelperV3.getOptionValue("f")).length() + " bytes");
	}
}

class HelperV3 {

	private static HashMap arguments = new HashMap();

	static void processArgs(String args[]) {
		if(args.length != 4 ||
			!args[0].equals("-n") ||
			!args[2].equals("-f") ||
			!(new File(args[3]).isFile())) {
			usage();
			System.exit(-1);
		}

		arguments.put("n", args[1]);
		arguments.put("f", args[3]);
	}

	static void usage() {
		System.err.println(
			"java MainApplicationV3 -n [Your Name] -f [Your File]");
	}

	static boolean hasOption(String optionName) {
		return arguments.containsKey(optionName);
	}

	static String getOptionValue(String optionName) {
		return (String)arguments.get(optionName);
	}
}