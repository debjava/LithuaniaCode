package com.manning.commons.chapter12;

import java.util.List;
import java.util.ArrayList;

import org.apache.commons.cli2.Group;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.Argument;
import org.apache.commons.cli2.CommandLine;
import org.apache.commons.cli2.commandline.Parser;
import org.apache.commons.cli2.builder.GroupBuilder;
import org.apache.commons.cli2.builder.ArgumentBuilder;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;

public class CLIApplicationV3 {
	public static void main(String args[]) throws Exception {

		GroupBuilder gBuilder = new GroupBuilder();
		ArgumentBuilder aBuilder = new ArgumentBuilder();
		DefaultOptionBuilder oBuilder = new DefaultOptionBuilder();

		Argument aName =
			aBuilder
			  .withDescription("Your Name")
			  .withName("name")
			  .withMinimum(1)
			  .withMaximum(1)
			  .withDefault("NoName")
			  .create();

		Option oName =
		  oBuilder
		    .withArgument(aName)
		  	.withShortName("n")
		  	.withDescription("Enter your name")
		  	.create();

		Argument aAge =
			aBuilder
			  .withDescription("Your Age")
			  .withName("age")
			  .withMinimum(1)
			  .withMaximum(1)
			  .create();

		Option oAge =
		  oBuilder
		    .withArgument(aAge)
		  	.withShortName("a")
		  	.withDescription("Enter your age")
		  	.create();

		Group gOptions =
		  gBuilder
		    .withOption(oName)
		    .withOption(oAge)
		    .create();

		Parser parser = new Parser();
		parser.setGroup(gOptions);

		CommandLine commandLine = parser.parseAndHelp(args);

		if(commandLine != null) {

			int age;
			String name = (String)commandLine.getValue(oName, "Pretty Face");

			if(commandLine.hasOption(oAge)) {
				try{
				  age = Integer.parseInt((String)commandLine.getValue(oAge));
				} catch(Exception e) { age = 0; }

				if(age > 80)
					System.err.println(name + ", you are still young at heart!");
				else
					System.err.println(name +	", you are still young!");
			}
		}
	}
}

