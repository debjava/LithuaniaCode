package com.manning.commons.chapter12;

import java.util.List;
import java.util.Date;
import java.util.HashSet;
import java.util.ArrayList;
import java.text.DateFormat;

import org.apache.commons.cli2.Group;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.Argument;
import org.apache.commons.cli2.CommandLine;
import org.apache.commons.cli2.commandline.Parser;
import org.apache.commons.cli2.builder.GroupBuilder;
import org.apache.commons.cli2.validation.Validator;
import org.apache.commons.cli2.builder.ArgumentBuilder;
import org.apache.commons.cli2.validation.FileValidator;
import org.apache.commons.cli2.validation.EnumValidator;
import org.apache.commons.cli2.validation.DateValidator;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;

public class CLIApplicationV5 {
	public static void main(String args[]) throws Exception {

		GroupBuilder gBuilder = new GroupBuilder();
		ArgumentBuilder aBuilder = new ArgumentBuilder();
		DefaultOptionBuilder oBuilder = new DefaultOptionBuilder();


		HashSet possibleEnumValues = new HashSet();
		possibleEnumValues.add("Orange");
		possibleEnumValues.add("Apple");
		Validator vEnum   = new EnumValidator(possibleEnumValues);

		ArrayList possbileDateFormats = new ArrayList();
		possbileDateFormats.add(DateFormat.getDateInstance(DateFormat.SHORT));
		possbileDateFormats.add(DateFormat.getDateInstance(DateFormat.MEDIUM));
		DateValidator vDate   = new DateValidator(possbileDateFormats);
		vDate.setMaximum(new Date());
		vDate.setMinimum(new Date(0)); // 1/1/1970

		FileValidator vFile   = FileValidator.getExistingFileInstance();
		vFile.setWritable(true);

		Validator vCustom = new AlphaNumericValidator();

		Argument aCustom =
		  aBuilder
		    .withName("custom")
		    .withMinimum(1)
		    .withMaximum(1)
		    .withValidator(vCustom)
		    .create();

		Option oCustom =
		  oBuilder
		    .withShortName("c")
		    .withArgument(aCustom)
		    .create();

		Argument aDate =
		  aBuilder
		    .withName("date")
		    .withMinimum(1)
		    .withMaximum(1)
		    .withValidator(vDate)
		    .create();

		Option oDate =
		  oBuilder
		    .withShortName("d")
		    .withArgument(aDate)
		    .create();

		Argument aEnum =
		  aBuilder
		    .withName("enum")
		    .withMinimum(1)
		    .withMaximum(1)
		    .withValidator(vEnum)
		    .create();

		Option oEnum =
		  oBuilder
		    .withShortName("e")
		    .withArgument(aEnum)
		    .create();

		Argument aFile =
		  aBuilder
		    .withName("file")
		    .withMinimum(1)
		    .withMaximum(1)
		    .withValidator(vFile)
		    .create();

		Option oFile =
		  oBuilder
		    .withShortName("f")
		    .withArgument(aFile)
		    .create();

		Group gOptions =
		  gBuilder
		    .withOption(oCustom)
		    .withOption(oDate)
		    .withOption(oEnum)
		    .withOption(oFile)
		    .create();

		Parser parser = new Parser();
		parser.setGroup(gOptions);

		CommandLine commandLine = parser.parseAndHelp(args);

		if(commandLine != null) {
			// process the values
		}

	}
}


