package com.manning.commons.chapter12;

import java.io.File;

public class MainApplicationV2 {
	public static void main(String args[]) {
		String[] options = HelperV2.processArgs(args);
		System.err.println("Hello " + options[0] +
			", your file size is " + new File(options[1]).length() + " bytes");
	}
}

class HelperV2 {
	static String[] processArgs(String args[]) {
		if(args.length != 4 ||
			!args[0].equals("-n") ||
			!args[2].equals("-f") ||
			!(new File(args[3]).isFile())) {
			usage();
			System.exit(-1);
		}

		return new String[] { args[1], args[3] };
	}

	static void usage() {
		System.err.println(
			"java MainApplicationV2 -n [Your Name] -f [Your File]");
	}
}