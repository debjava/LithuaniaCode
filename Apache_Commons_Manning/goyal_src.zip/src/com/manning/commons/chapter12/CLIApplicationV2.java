package com.manning.commons.chapter12;

import java.util.List;
import java.util.ArrayList;

import org.apache.commons.cli2.Group;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.CommandLine;
import org.apache.commons.cli2.commandline.Parser;
import org.apache.commons.cli2.builder.GroupBuilder;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;

public class CLIApplicationV2 {
	public static void main(String args[]) throws Exception {

		DefaultOptionBuilder oBuilder = new DefaultOptionBuilder();
		Option optionName =
		  oBuilder
		  	.withShortName("n")
		  	.withDescription("Print standard greeting")
		  	.create();

		GroupBuilder gBuilder = new GroupBuilder();
		Group optionGroups =
		  gBuilder
		    .withOption(optionName)
		    .create();

		Parser parser = new Parser();
		parser.setGroup(optionGroups);

		CommandLine commandLine = parser.parseAndHelp(args);

		if(commandLine != null && commandLine.hasOption(optionName))
			System.err.println("Hello NoName");
	}
}

