package com.manning.commons.chapter12;

import java.util.List;
import java.util.ArrayList;

import org.apache.commons.cli2.Group;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.CommandLine;
import org.apache.commons.cli2.option.GroupImpl;
import org.apache.commons.cli2.commandline.Parser;
import org.apache.commons.cli2.option.DefaultOption;

public class CLIApplicationV1 {
	public static void main(String args[]) throws Exception {

		DefaultOption optionName =
			new DefaultOption(
				"-",
				"--",
				false,
				"n",
				"Print standard greeting",
				null,
				null,
				true,
				null,
				null,
				'n');

		List options = new ArrayList();
		options.add(optionName);

		Group optionGroups =
			new GroupImpl(
				options,
				"Options",
				"All the Options",
				1,
				1);

		Parser parser = new Parser();
		parser.setGroup(optionGroups);

		CommandLine commandLine = parser.parseAndHelp(args);

		if(commandLine != null && commandLine.hasOption(optionName))
			System.err.println("Hello NoName");
	}
}

