package com.manning.commons.chapter12;

public class MainApplicationV1 {
	public static void main(String args[]) {
		System.err.println("Hello " + HelperV1.processArgs(args));
	}
}

class HelperV1 {
	static String processArgs(String args[]) {
		if(args.length != 2 || !args[0].equals("-n")) {
			usage();
			System.exit(-1);
		}

		return args[1];
	}

	static void usage() {
		System.err.println("java MainApplicationV1 -n [Your Name]");
	}
}