package com.manning.commons.chapter12;

import java.util.List;
import java.util.ListIterator;

import org.apache.commons.cli2.validation.Validator;
import org.apache.commons.cli2.validation.InvalidArgumentException;

public class AlphaNumericValidator implements Validator {

	public void validate(List values) throws InvalidArgumentException {

		for (final ListIterator i = values.listIterator(); i.hasNext();) {
				final String value = (String)i.next();

				char charArray[] = value.toCharArray();

				for(int k = 0; k < charArray.length; k++) {
					if(!Character.isLetterOrDigit(charArray[k]))
					  throw new InvalidArgumentException(
							charArray[k] + " is not allowed in " + value);
				}
		}

	}
}