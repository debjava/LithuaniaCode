package com.manning.commons.chapter12;

import java.util.List;
import java.util.ArrayList;

import org.apache.commons.cli2.Group;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.Argument;
import org.apache.commons.cli2.CommandLine;
import org.apache.commons.cli2.commandline.Parser;
import org.apache.commons.cli2.builder.GroupBuilder;
import org.apache.commons.cli2.builder.ArgumentBuilder;
import org.apache.commons.cli2.builder.DefaultOptionBuilder;

public class CLIApplicationV4 {
	public static void main(String args[]) throws Exception {

		GroupBuilder gBuilder = new GroupBuilder();
		ArgumentBuilder aBuilder = new ArgumentBuilder();
		DefaultOptionBuilder oBuilder = new DefaultOptionBuilder();

		Argument aWidth =
		  aBuilder
		    .withName("width")
		    .withMinimum(1)
		    .withMaximum(1)
		    .create();

		Argument aHeight =
		  aBuilder
		    .withName("height")
		    .withMinimum(1)
		    .withMaximum(1)
		    .create();

		Group gArgs =
		  gBuilder
		    .withOption(aWidth)
		    .withOption(aHeight)
		    .create();

		Option oRectangle =
		  oBuilder
		    .withChildren(gArgs)
		    .withShortName("rect")
		    .create();

		Group gOptions =
		  gBuilder
		    .withOption(oRectangle)
		    .create();

		Parser parser = new Parser();
		parser.setGroup(gOptions);

		CommandLine commandLine = parser.parseAndHelp(args);

		if(commandLine != null) {
			System.err.println("Rectangle: "  +
			  commandLine.getValues(oRectangle));
		}

	}
}

