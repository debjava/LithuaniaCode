package com.manning.commons.chapter03;

/**
 * Created by IntelliJ IDEA.
 * User: vgoyal
 * Date: Dec 20, 2003
 * Time: 2:28:25 PM
 * To change this template use Options | File Templates.
 */
public class MultiProtocolHandler {
}
