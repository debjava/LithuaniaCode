/*
 * Command.java
 *
 * Created on December 28, 2003, 3:10 PM
 */

package com.manning.commons.chapter03;

import java.util.Vector;
import java.util.Iterator;
import java.lang.IllegalArgumentException;

/**
 * A Command is a protocol independent class that implements commands.
 * A Command may have arguments, like USER for FTP, or it may be standalone
 * as in logout, again for ftp. A command can only be created by calling the
 * Command Constructor with the name of the command. To add arguments to the
 * command, use the addArgument method.
 * @author  vgoyal
 */
public class Command {
    
    private String commandName;
    
    private Vector commandArguments;
    
    /** Creates a new instance of Command */
    public Command(String commandName) {
        if(commandName == null || commandName.length() == 0) {
            throw new IllegalArgumentException("Invalid Command Name");
        }
        
        this.commandName = commandName;
    }
    
    public String getCommandName() {
        return this.commandName;
    }
    
    public void addArgument(String argValue) {
        if(argValue == null || 
           argValue.length() == 0) {
           throw new IllegalArgumentException("Invalid Command Argument");
        }
        
        if(commandArguments == null) commandArguments = new Vector();
        
        commandArguments.add(argValue);
    }
    
    public int getCountCommandArguments() {
        if(commandArguments == null) return 0;
        else return commandArguments.size();
    }
    
    /**
     * Returns space delimited String containing all arguments to this command
     */
    public String getArguments() {
        if(getCountCommandArguments() == 0) return "";
        
        String returnVal = "";
        Iterator itr = commandArguments.iterator();
        while(itr.hasNext()){
            returnVal = returnVal + " " + itr.next();
        }
        
        return returnVal;
    }
    
}
