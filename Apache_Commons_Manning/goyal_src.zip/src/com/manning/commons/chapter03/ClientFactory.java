/*
 * ClientFactory.java
 *
 * Created on December 31, 2003, 12:15 PM
 */

package com.manning.commons.chapter03;

import org.apache.commons.net.*;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.smtp.SMTPClient;
import org.apache.commons.net.pop3.POP3Client;
import org.apache.commons.net.nntp.NNTPClient;
import org.apache.commons.net.tftp.TFTPClient;

/**
 * Factory for creation of singleton clients.
 * @author  vgoyal
 */
class ClientFactory {
    
    public static SocketClient getTCPClientInstance(int clientType) {
       switch(clientType) {
            case 0: { // is chargen
                if(charGenTCPClient == null) {
                    charGenTCPClient = new CharGenTCPClient();
                }
                return charGenTCPClient;
            }
           case 1: { // is daytime 
               if(daytimeTCPClient == null) {
                   daytimeTCPClient = new DaytimeTCPClient();
               }
               return daytimeTCPClient;
           }
           case 2: { // is echo
               if(echoTCPClient == null) {
                   echoTCPClient = new EchoTCPClient();
               }
               return echoTCPClient;
           }
           case 3: { // is finger
               if(fingerClient == null) {
                   fingerClient = new FingerClient();
               }
               return fingerClient;
           }
           case 4: { // is ftp
               if(ftpClient == null) {
                   ftpClient = new FTPClient();
               }
               return ftpClient;
           }
           case 5: { // is nntp
               if(nntpClient == null) {
                   nntpClient = new NNTPClient();
               }
               return nntpClient;
           }
           case 6: { // is pop3
               if(pop3Client == null) {
                   pop3Client = new POP3Client();
               }
               return pop3Client;
           }
           case 7: { // is smtp
               if(smtpClient == null) {
                   smtpClient = new SMTPClient();
               }
               return smtpClient;
           }
           case 8: { // is time
               if(timeTCPClient == null) {
                   timeTCPClient = new TimeTCPClient();
               }
               return timeTCPClient;
           }
           case 9: { // is whois
               if(whoisClient == null) {
                   whoisClient = new WhoisClient();
               }
               return whoisClient;
           }
        }
        return null;
    }
    
    public static DatagramSocketClient getUDPClientInstance(int clientType) {
       switch(clientType) {
            case 0: { // is chargen
                if(charGenUDPClient == null) {
                    charGenUDPClient = new CharGenUDPClient();
                }
                return charGenUDPClient;
            }
           case 1: { // is daytime
               if(daytimeUDPClient == null) {
                   daytimeUDPClient = new DaytimeUDPClient();
               }
               return daytimeUDPClient;
           }
           case 2: { // is echo
               if(echoUDPClient == null) {
                   echoUDPClient = new EchoUDPClient();
               }
               return echoUDPClient;
           }
           case 3: { // is tftp
               if(tftpClient == null) {
                   tftpClient = new TFTPClient();
               }
               return tftpClient;
           }
           case 4: { // is time
               if(timeUDPClient == null) {
                   timeUDPClient = new TimeUDPClient();
               }
               return timeUDPClient;
           }
        }
       return null;
    }
    
    // TCP clients
    private static CharGenTCPClient charGenTCPClient;
    private static DaytimeTCPClient daytimeTCPClient;
    private static EchoTCPClient    echoTCPClient;
    private static FingerClient     fingerClient;
    private static FTPClient        ftpClient;
    private static NNTPClient       nntpClient;
    private static POP3Client       pop3Client;
    private static SMTPClient       smtpClient;
    private static TimeTCPClient    timeTCPClient;
    private static WhoisClient      whoisClient;
    
    // UDP clients
    private static CharGenUDPClient charGenUDPClient;
    private static DaytimeUDPClient daytimeUDPClient;
    private static EchoUDPClient    echoUDPClient;
    private static TFTPClient       tftpClient;
    private static TimeUDPClient    timeUDPClient;
}