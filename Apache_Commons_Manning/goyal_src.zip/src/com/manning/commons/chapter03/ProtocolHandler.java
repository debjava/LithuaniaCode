/*
 * ProtocolHandler.java
 *
 * Created on December 28, 2003, 1:05 PM
 */

package com.manning.commons.chapter03;

import org.apache.commons.net.*;
import org.apache.commons.net.ftp.*;
import org.apache.commons.net.nntp.*;
import org.apache.commons.net.pop3.*;
import org.apache.commons.net.smtp.*;
import org.apache.commons.net.tftp.*;

import java.util.Date;
import java.io.InputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * This class handles protocol commands that are either typed in or do not 
 * require much manual intervention.
 * @author  vgoyal
 */
public class ProtocolHandler {
    
    public static void handleTCPProtocol(
        int protocolId, SocketClient client, 
        ProtocolRunner runner, String commandString) 
        throws IOException {
        
        switch(protocolId) {
            case 0: { // is chargen
                handleTCPChargen((CharGenTCPClient)client, runner);
                return;
            }
            case 1: { // is daytime
                handleTCPDaytime((DaytimeTCPClient)client, runner);
                return;
            }
            case 2: { // is echo
                handleTCPEcho((EchoTCPClient)client, runner);
                return;
            }  
            case 3: { // is finger
                handleFinger((FingerClient)client, runner);
                return;
            }              
            case 4: { // is ftp
                handleFTP((FTPClient)client, runner, commandString);
                return;
            }
            case 5: { // is nntp
                handleNNTP((NNTPClient)client, runner, commandString);
                return;
            }
            case 6: { // is pop3
                handlePOP3((POP3Client)client, runner, commandString);
                return;
            }
            case 7: { // is smtp
                handleSMTP((SMTPClient)client, runner, commandString);
                return;
            }
            case 8: { // is Time
                handleTCPTime((TimeTCPClient)client, runner);
                return;
            }
            case 9: { // is Whois
                handleWhois((WhoisClient)client, runner);
                return;
            }
        }
    }    

    public static void handleTCPProtocol(
        int protocolId, SocketClient client, ProtocolRunner runner)  
        throws IOException {
            handleTCPProtocol(protocolId, client, runner, null);
    }

    
    public static void handleUDPProtocol(
        int protocolId, DatagramSocketClient client, ProtocolRunner runner)
        throws IOException {

        switch(protocolId) {
            case 0: { // is chargen
                handleUDPChargen((CharGenUDPClient)client, runner);
                return;
            }
            case 1: { // is daytime
                handleUDPDaytime((DaytimeUDPClient)client, runner);
                return;
            }
            case 2: { // is echo
                handleUDPEcho((EchoUDPClient)client, runner);
                return;
            }
            case 4: { // is time
                handleUDPTime((TimeUDPClient)client, runner);
                return;
            }
        }            
    }    
    
    private static void handleUDPChargen(
        CharGenUDPClient client, ProtocolRunner runner) 
        throws IOException {
            
        int packets = 500;        
        while(packets-- > 0) {
            client.send(InetAddress.getByName(runner.getUDPRemoteServer()));
            runner.getUDPServerResponse().append(new String(client.receive()));
        }
    }

    private static void handleUDPDaytime(
        DaytimeUDPClient client, ProtocolRunner runner) 
        throws IOException {            
            runner.getUDPServerResponse().append(
                client.getTime(
                    InetAddress.getByName(runner.getUDPRemoteServer())) 
                    + "\r\n");
    }

    private static void handleUDPEcho(
        EchoUDPClient client, ProtocolRunner runner) 
        throws IOException {
            
        // use the runner to get data from the user to send to echo server
        runner.getSingleValueLabel().setText("Enter echo data (UDP):");
        runner.showDialog(runner.getSingleValueDialog());
    }        
    
    private static void handleUDPTime(
        TimeUDPClient client, ProtocolRunner runner) 
        throws IOException {
            
        long origTime = client.getTime(InetAddress.getByName(
            runner.getUDPRemoteServer()));

        runner.getUDPServerResponse().append(
        "Time returned from server: " +  origTime + "\r\n" +
        "Converted to Date: " + 
        new Date(((origTime) - TimeUDPClient.SECONDS_1900_TO_1970)*1000L));
    }    

    private static void handleTCPChargen(
        CharGenTCPClient client, ProtocolRunner runner) 
        throws IOException {

        // simply grab the resulting inputstream to show the return by the
        // remote server for upto 500 lines
        BufferedReader chargenInput = 
            new BufferedReader(new InputStreamReader(client.getInputStream()));
        
        int lines = 500;
        while(lines-- > 0) {
            runner.getTCPServerResponse().append(
                chargenInput.readLine() + "\r\n");
        }
    }
    
    private static void handleTCPDaytime(
        DaytimeTCPClient client, ProtocolRunner runner) 
        throws IOException {            
            runner.getTCPServerResponse().append(client.getTime() + "\r\n");
    }

    private static void handleTCPTime(
        TimeTCPClient client, ProtocolRunner runner) 
        throws IOException {
            long origTime = client.getTime();
            
            // remember that the long time returned from the server is the 
            // seconds since midnight Jan 1900 and Date in Java is number of
            // seconds since midnight Jan 1970. NET TCPClient provides the time
            // in both formats but you cannot call them both one after another
            // as the internal getDate uses getTime, but the line has already
            // been closed if you have called getTime before.
            runner.getTCPServerResponse().append(
            "Time returned from server: " +  origTime + "\r\n" +
            "Converted to Date: " + 
            new Date(((origTime) - TimeTCPClient.SECONDS_1900_TO_1970)*1000L));
    }

    private static void handleTCPEcho(
        EchoTCPClient client, ProtocolRunner runner) 
        throws IOException {
            
        // use the runner to get data from the user to send to echo server
        runner.getSingleValueLabel().setText("Enter echo data:");
        runner.showDialog(runner.getSingleValueDialog());
    }    
    
    private static void handleFinger(
        FingerClient client, ProtocolRunner runner) 
        throws IOException {
            
        // use the runner to get data from the user to send to echo server
        runner.getSingleValueLabel().setText("Enter query:");
        runner.showDialog(runner.getSingleValueDialog());
    }

    private static void handleWhois(
        WhoisClient client, ProtocolRunner runner) 
        throws IOException {
            
        // use the runner to get data from the user to send to echo server
        runner.getSingleValueLabel().setText("Enter Whois query:");
        runner.showDialog(runner.getSingleValueDialog());
    }    
    
    private static void handleFTP(
        FTPClient client, 
        ProtocolRunner runner, 
        String commandString) 
        throws IOException {
        
        if(commandString == null) { // means just connected        
            
            // check if the server response was valid
            if(!FTPReply.isPositiveCompletion(client.getReplyCode())) {
                runner.handleDisconnect();
                return;
            }
            
        } else { // need to handle a command
            client.sendCommand(commandString);
        }
        
        runner.getTCPServerResponse().append(client.getReplyString());
    }

    private static void handleNNTP(
        NNTPClient client, 
        ProtocolRunner runner, 
        String commandString) 
        throws IOException {
        
        if(commandString == null) { // means just connected        
        
            // check if the server response was valid
            if(!NNTPReply.isPositiveCompletion(client.getReplyCode())) {
                runner.handleDisconnect();
                return;
            }
            
        } else { // need to handle a command
            client.sendCommand(commandString);
        }
        
        runner.getTCPServerResponse().append(client.getReplyString());
    }

    private static void handlePOP3(
        POP3Client client, 
        ProtocolRunner runner, 
        String commandString) 
        throws IOException {
        
        if(commandString == null) { // means just connected 
                return;            
        } else { // need to handle a command
            client.sendCommand(commandString);
        }
        
        runner.getTCPServerResponse().append(client.getReplyString());
    }

    private static void handleSMTP(
        SMTPClient client, 
        ProtocolRunner runner, 
        String commandString) 
        throws IOException {
        
        if(commandString == null) { // means just connected 
            // check if the server response was valid
            if(!SMTPReply.isPositiveCompletion(client.getReplyCode())) {
                runner.handleDisconnect();
                return;
            }
        } else { // need to handle a command
            client.sendCommand(commandString);
        }
        
        runner.getTCPServerResponse().append(client.getReplyString());
    } 
    
}
