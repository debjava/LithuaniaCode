readme.txt

These files contain the source code for Bitter Java by Bruce A. Tate.  
They are provided without any warranty, written or implied.  Keep in
mind that these come from a book on Java Antipatterns, meaning that
most of the examples are how *not* to code an application.

The programs were developed on Visual Age for Java version 4.0, with 
JDK 1.2.2.  You are free to run them on any platform, but the author
can best provide assistance on VisualAge for Java.  

Make sure that you have in your classpath:

servlets.jar  (mine is from tomcat version 3.2).
db2java.zip  (for DB2 version 7.1).


I compiled, but did not test, some of the programs on JDK 1.3.1.

For questions, check the forum from the Manning site.  Find a link to
the forum at the Bitter Java book page at www/manning.com/tate.