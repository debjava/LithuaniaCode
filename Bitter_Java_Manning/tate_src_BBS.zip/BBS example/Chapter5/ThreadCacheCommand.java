package bbs;

import java.io.*;
import java.sql.*;
import COM.ibm.db2.*;
import java.util.*;
/**
 * Insert the type's description here.
 * Creation date: (07/17/2001 5:07:55 PM)
 * @author: Administrator
 */
public class ThreadCacheCommand {




	private String parent = "0";
  public boolean cached = false;
	protected ShowThreadCommand threadCommand = null;
	private static java.util.Hashtable threadCache = null;
/**
 * execute
 * This is the work horse method for the command.
 * It will execute the query and get the result set.
 */
public void execute()
  throws
    java.io.IOException {
  try {
    synchronized (threadCache) {
      // Assume that we will get a cache "hit"
      cached = true;
      Hashtable cache = getThreadCache();
      if (cache == null) {
        throw new Exception();
      }
      threadCommand = (ShowThreadCommand) cache.get(getParent());
      if (threadCommand == null) {
        threadCommand = new ShowThreadCommand();
        getThreadCommand().setParent(getParent());
        getThreadCommand().initialize();
        getThreadCommand().execute();
        cache.put(getParent(), getThreadCommand());
        // We did not get a cache hit so reset the value of cached.
        cached = false;
      }
    }
  } catch (Throwable theException) {
    theException.printStackTrace();
  }
}
  /**
   * getAuthor
   * This method will get the author property.
   */
  public String getAuthor(int index)
  {
    return getThreadCommand().getAuthor(index);
  }
  /**
   * getBoard
   * This method will get the board property.
   * Since the SQL statement returns a result set,
   * we will index the result.
   */
  public String getBoard(int index)
  {
    return getThreadCommand().getBoard(index);  
	}

public boolean getCached() {
	return cached;
}

public String getParent() {
	return parent;
}

public java.lang.String getPostText(int index) {
	return getThreadCommand().getPostText(index);
}
 
  public int getSize() {
    return getThreadCommand().getSize();
  }

  public String getSubject(int index)
  {
    return getThreadCommand().getSubject(index);
  }

protected static Hashtable getThreadCache() {
	return threadCache;
}

ShowThreadCommand getThreadCommand() {
	return threadCommand;
}
/**
 * initialize
 * This method will validate and initialize the hash table.
 */
public void initialize()
  throws
    java.io.IOException,
    AddPostValidationException {
  synchronized (threadCache) {
    if (getParent() == null) {
      throw new AddPostValidationException("Parent was null");
    }
    if (threadCache == null) {
      threadCache = new Hashtable();
    }
  }
}
/**
 * Invalidate
 * This method removes objects from the cache.
 * The key is the command's unique identifier.
 */
public void invalidate(String key) {
  synchronized(threadCache) {
    getThreadCache().remove(key);
  }
}
/**
 * Insert the method's description here.
 * Creation date: (07/31/2001 11:06:11 PM)
 * @param newParent int
 */
public void setParent(String newParent) {
	parent = newParent;
}
}
