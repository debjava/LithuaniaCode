package bbs;

import java.io.*;
import java.sql.*;
import COM.ibm.db2.*;
import java.util.*;

public class AddPostCommand {

  private String author = null;
  private String subject = null;
  private String board = null;
  private String parent = "0";
  private java.lang.String postText = null;
  private ResultSet result;
  private Connection connection = null;
  private String query = null;


  /**
   * execute
   * This is the work-horse method for the command.
   */
  
  public void execute()
    throws
      java.io.IOException {

    try {
      query =
        "INSERT INTO POSTS values ('"
          + getSubject()
          + "', (select max(number) from posts) + 1, '"
          + getAuthor()
          + "', '"
          + getPostText()
          + "', current timestamp, "
          + getParent()
          + ", '"
          + getBoard()
          + "')";

      Statement statement = connection.createStatement();
      result = statement.executeQuery(query);
      result.close();
      statement.close();
    } catch (Throwable theException) {
      theException.printStackTrace();
    }

  }

  public String getAuthor() {
    return (String) author;
  }
  
  public String getBoard() {
    return (String) board;
  }
  
  public String getParent() {
    return parent;
  }
  
  public java.lang.String getPostText() {
    return postText;
  }
  
  public String getQuery() {
    return query;
  }
  
  public String getSubject() {
    return (String) subject;
  }
  /**
   * initialize
   * This method will connect to the database.
   */
  public void initialize()
    throws
      AddPostValidationException,
      java.io.IOException {

    try {

      // Validate the command input strings and raise exceptions
      if (getAuthor() == null) {
        throw new AddPostValidationException(
	        "Author field is required.");
      }
      if (getSubject() == null) {
        throw new AddPostValidationException(
	        "The Subject field is required.");
      }
      if (getPostText() == null) {
        throw new AddPostValidationException(
	        "The post is empty.");
      }
      if (getBoard() == null) {
        throw new AddPostValidationException(
	        "The board is not valid.");
      }
      Class.forName("COM.ibm.db2.jdbc.app.DB2Driver").newInstance();

      // URL is jdbc:db2:dbname
      String url = "jdbc:db2:board";

      // connect with default id/password
      connection = DriverManager.getConnection(url);

    } catch (Throwable theException) {
      theException.printStackTrace();
    }
  }

  public void setAuthor(String newAuthor) {
    author = newAuthor;
  }

  public void setBoard(String newBoard) {
    board = newBoard;
  }

  public void setParent(String newParent) {
    parent = newParent;
  }

  public void setPostText(java.lang.String newPostText) {
    postText = newPostText;
  }

  public void setSubject(String newSubject) {
    subject = newSubject;
  }
}