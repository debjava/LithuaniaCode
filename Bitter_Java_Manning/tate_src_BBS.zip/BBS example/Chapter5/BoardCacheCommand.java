package bbs;

import java.io.*;
import java.sql.*;
import COM.ibm.db2.*;
import java.util.*;

import bbs.AddPostValidationException;
import bbs.ShowBoardCommand;
/**
 * BoardCacheCommand
 * Creation date: (07/17/2001 5:07:55 PM)
 * @author: Bruce Tate
 */
public class BoardCacheCommand {

  protected String board = null;
  public boolean cached = false;

  protected ShowBoardCommand boardCommand = null;
  private static java.util.Hashtable boardCache = null;
  /**
   * execute
   * This is the work horse method for the command.
   * It will execute the query and get the result set.
   */
  public void execute()
    {

    try {
      // Cached is an instructional flag to show whether a
      // value was fetched from the cache.
      cached = true;
      synchronized(boardCache) {
        Hashtable cache = getBoardCache();
        if (cache == null) {
          throw new Exception();
        }
        boardCommand = (ShowBoardCommand) cache.get(getBoard());
        if (boardCommand == null) {
          boardCommand = new ShowBoardCommand();
          boardCommand.setBoard(getBoard());
          boardCommand.initialize();
          boardCommand.execute();
          cache.put(getBoard(), boardCommand);
          // We had to build the command from scratch, so it was not cached.
          cached = false;
        }
      }  
    } catch (Throwable theException) {
      theException.printStackTrace();
    }
  }
  /**
   * getAuthor
   * This method will get the author property.
   * Since the SQL statement returns a result set,
   * we will index the result.
   */
  public String getAuthor(int index)
    throws
      java.lang.IndexOutOfBoundsException,
      java.lang.ArrayIndexOutOfBoundsException {
    return getBoardCommand().getAuthor(index);
  }
  /**
   * getBoard
   * This method will get the board property.
   * Since the SQL statement returns a result set,
   * we will index the result.
   */
  public String getBoard() {
    return board;
  }
  protected static Hashtable getBoardCache() {
    return boardCache;
  }
  ShowBoardCommand getBoardCommand() {
    return boardCommand;
  }
  public boolean getCached() {
    return cached;
  }
  /**
   * getAuthor
   * This method will get the author property.
   * Since the SQL statement returns a result set,
   * we will index the result.
   */
  public String getNumber(int index)
    throws
      java.lang.IndexOutOfBoundsException,
      java.lang.ArrayIndexOutOfBoundsException {
    return getBoardCommand().getNumber(index);
  }
  /**
   * Insert the method's description here.
   * Creation date: (07/17/2001 11:38:44 PM)
   * @return int
   * @exception java.lang.IndexOutOfBoundsException The exception description.
   */
  public int getSize() {
    return getBoardCommand().getSize();
  }
  /**
   * getSubject
   * This method will get the subject property.
   * Since the SQL statement returns a result set,
   * we will index the result.
   */
  public String getSubject(int index)
    throws
      java.lang.IndexOutOfBoundsException,
      java.lang.ArrayIndexOutOfBoundsException {
    return getBoardCommand().getSubject(index);
  }
  /**
   * initialize
   * This method will initialize the cache and validate the parameters.
   */
  public void initialize()
    throws
      java.io.IOException,
      AddPostValidationException {
    synchronized(boardCache) {

      if (getBoard() == null) {
        throw new AddPostValidationException("Board was null");
      }
      if (boardCache == null) {
        boardCache = new Hashtable();
      }
    }  
  }
  /**
   * Invalidate
   * This method removes objects from the cache.
   * The key is the command's unique identifier.
   */
  public void invalidate(String key) {
    synchronized(boardCache) {
      getBoardCache().remove(key);
    }  
  }
  /**
   * getBoard
   * This method will get the board property.
   * Since the SQL statement returns a result set,
   * we will index the result.
   */
  public void setBoard(String name) {
    board = name;
  }
  /**
   * Insert the method's description here.
   * Creation date: (08/03/2001 2:49:16 PM)
   * @param newBoardCommand bbs.ShowBoardCommand
   */
  void setBoardCommand(ShowBoardCommand newBoardCommand) {
    boardCommand = newBoardCommand;
  }
}
