package bbs;

import java.io.*;
import java.sql.*;
import COM.ibm.db2.*;
import java.util.*;
/**
 * Insert the type's description here.
 * Creation date: (07/17/2001 5:07:55 PM)
 * @author: Administrator
 */
public class ShowThreadCommand {

  // Field indexes for command properties	
  private static final int SUBJECT_COLUMN = 1;
  private static final int AUTHOR_COLUMN = 2;
  private static final int BOARD_COLUMN = 3;
  private static final int POSTTEXT_COLUMN = 4;
  private static final int NUMBER_COLUMN = 5;

protected Vector author = new Vector();
  protected Vector subject = new Vector();
  protected Vector board = new Vector();

  // SQL result set
  protected ResultSet result;
  protected Connection connection = null;

	private Vector postText = new Vector();
	private String parent = "0";
	private String query = null;
  /**
   * execute
   * This is the work horse method for the command.
   * It will execute the query and get the result set.
   */
  public void execute()
    throws
      SQLException,
      java.io.IOException {

//    try {
	    query = "select subject, author, board, postData, number " + 
	      "from posts where (number = " + getParent() + ") or" + 
	      " (parent = "+ getParent() +") order by number";
    
          
   
      Statement statement = connection.createStatement();
      result = statement.executeQuery(query);
      while (result.next()) {
        subject.addElement(result.getString(SUBJECT_COLUMN));
        author.addElement(result.getString(AUTHOR_COLUMN));
        board.addElement(result.getString(BOARD_COLUMN));
        postText.addElement(result.getString(POSTTEXT_COLUMN));
      }
      result.close();
      statement.close();
//    } catch (Throwable theException) {
//      theException.printStackTrace();
//    }

  }
  /**
   * getAuthor
   * This method will get the author property.
   */
  public String getAuthor(int index)
  {
    return (String) author.elementAt(index);
  }
  /**
   * getBoard
   * This method will get the board property.
   * Since the SQL statement returns a result set,
   * we will index the result.
   */
  public String getBoard(int index)
  {
    return (String) board.elementAt(index);
  }
/**
 * Insert the method's description here.
 * Creation date: (07/31/2001 11:06:11 PM)
 * @return int
 */
public String getParent() {
	return parent;
}
/**
 * Insert the method's description here.
 * Creation date: (07/31/2001 11:00:52 PM)
 * @return java.lang.String
 */
public java.lang.String getPostText(int index) {
	return (String)postText.elementAt(index);
}
/**
 * Insert the method's description here.
 * Creation date: (07/31/2001 11:06:11 PM)
 * @return int
 */
public String getQuery() {
	return query;
}
   /**
   * Insert the method's description here.
   * Creation date: (07/17/2001 11:38:44 PM)
   * @return int
   * @exception java.lang.IndexOutOfBoundsException The exception description.
   */
  public int getSize() {
    return author.size();
  }
  /**
   * getSubject
   * This method will get the subject property.
   * Since the SQL statement returns a result set,
   * we will index the result.
   */
  public String getSubject(int index)
  {
    return (String) subject.elementAt(index);
  }
  /**
   * initialize
   * This method will connect to the database.
   */
  public void initialize()
    throws java.io.IOException {

    try {
      Class.forName("COM.ibm.db2.jdbc.app.DB2Driver").newInstance();

      
      // URL is jdbc:db2:dbname
      String url = "jdbc:db2:board";

      // connect with default id/password
      connection = DriverManager.getConnection(url);

    } catch (Throwable theException) {
      theException.printStackTrace();
    }
  }
/**
 * Insert the method's description here.
 * Creation date: (07/31/2001 11:06:11 PM)
 * @param newParent int
 */
public void setParent(String newParent) {
	parent = newParent;
}
}
