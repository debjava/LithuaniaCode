package bbs;

// Imports
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;


// Import for commands used by this class
import bbs.ThreadCacheCommand;

public class FastShowThreadController
  extends javax.servlet.http.HttpServlet
  implements Serializable {

  /**
   * DoGet
   * Pass get requests through to PerformTask
   */
  public void doGet(
    HttpServletRequest request,
    HttpServletResponse response)
    throws javax.servlet.ServletException, java.io.IOException {
      performTask(request, response);
  }
  /**
   * DoPost
   * Pass get requests through to PerformTask
   */
  public void doPost(
    HttpServletRequest request,
    HttpServletResponse response)
    throws javax.servlet.ServletException, java.io.IOException {
      performTask(request, response);
  }
/**********************************************************
* Process incoming requests for information
* 
* @param request encapsulates the request to the servlet
* @param response encapsulates the response from the servlet
*/
public void performTask(
  HttpServletRequest request,
  HttpServletResponse response) {

  try {
    String parent=request.getParameter("parent");
    ThreadCacheCommand fullMessage =
      (bbs.ThreadCacheCommand) java.beans.Beans.instantiate(
        getClass().getClassLoader(),
        "bbs.ThreadCacheCommand");
    fullMessage.setParent(parent);
    fullMessage.initialize();
    fullMessage.execute();

    request.setAttribute("ThreadCacheCommand", fullMessage);

    ServletContext sc = getServletContext();
    RequestDispatcher rd=null;
    if (fullMessage.getSize()>0) {
      rd = sc.getRequestDispatcher("/JSP/FastShowThreadResults.jsp");
    } else {
      rd = sc.getRequestDispatcher("/JSP/messageNotFound.jsp");
    }   
    rd.forward(request, response);

  } catch (Throwable theException) {
    // uncomment the following line when unexpected exceptions
    // are occuring to aid in debugging the problem.
    //theException.printStackTrace();
//    response.setContentType("text/html");
    try {
      java.io.PrintWriter out = response.getWriter();
      out.println("<HTML>");
      out.println("<BODY BGCOLOR=#C0C0C0>");
      out.println("<H2>Exception Occurred</H2>");
      out.println(theException);
     out.println("</BODY></HTML>");
    } catch (Throwable exception) {
      theException.printStackTrace();
    }
  }
}
}
