package bbs;

// Imports
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class FastAddPostController
  extends javax.servlet.http.HttpServlet
  implements Serializable {

  /**
   * DoGet
   * Pass get requests through to PerformTask
   */
  public void doGet(
    HttpServletRequest request,
    HttpServletResponse response)
    throws javax.servlet.ServletException, java.io.IOException {
    performTask(request, response);
  }
  /**
   * DoPost
   * Pass get requests through to PerformTask
   */
  public void doPost(
    HttpServletRequest request,
    HttpServletResponse response)
    throws javax.servlet.ServletException, java.io.IOException {
    performTask(request, response);
  }
  /**********************************************************
  * Process incoming requests for information
  * 
  * @param request encapsulates the request to the servlet
  * @param response encapsulates the response from the servlet
  */
  public void performTask(
    HttpServletRequest request,
    HttpServletResponse response) {

    try {
      String board = request.getParameter("board");
      String subject = request.getParameter("subject");
      String author = request.getParameter("author");
      String postText = request.getParameter("postText");
      String parent = request.getParameter("parent");
      FastAddPostCommand addPost =
        (bbs.FastAddPostCommand) java.beans.Beans.instantiate(
          getClass().getClassLoader(),
          "bbs.FastAddPostCommand");

      try {
        addPost.setBoard(board);
        addPost.setSubject(subject);
        addPost.setAuthor(author);
        addPost.setPostText(postText);
        addPost.setParent(parent);
        addPost.initialize();
      } catch (Throwable validationFailedException) {
        try {
          ServletContext sc = getServletContext();
          RequestDispatcher rd =
            sc.getRequestDispatcher("/JSP/FastAddPostError.jsp");
          rd.forward(request, response);
          return;
        } catch (Throwable exception) {
          exception.printStackTrace();
        }

      }
      addPost.execute();
      request.setAttribute("FastAddPostCommand", addPost);

      ServletContext sc = getServletContext();
      RequestDispatcher rd =
        sc.getRequestDispatcher("/servlet/bbs.ShowBoardController");
      rd.forward(request, response);

    } catch (Throwable theException) {
      try {
        java.io.PrintWriter out = response.getWriter();
        out.println("<HTML>");
        out.println("<HEAD><TITLE>Post List Controller</TITLE></HEAD>");
        out.println("<BODY BGCOLOR=#C0C0C0>");
        out.println("<H2>Exception Occurred</H2>");
        out.println(theException);
        out.println("</BODY></HTML>");
      } catch (Throwable exception) {
        theException.printStackTrace();
      }
    }
  }
}
