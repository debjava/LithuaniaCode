package bbs;

// Imports
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;


// Import for commands used by this class
import bbs.CompoundJSPCommand;

public class CompoundJSPController
  extends javax.servlet.http.HttpServlet
  implements Serializable {

  /**
   * DoPost
   * Pass get requests through to PerformTask
   */
  public void doPost(
    HttpServletRequest request,
    HttpServletResponse response)
    throws javax.servlet.ServletException, java.io.IOException {
      performTask(request, response);
  }
/**********************************************************
* Process incoming requests for information
* 
* @param request encapsulates the request to the servlet
* @param response encapsulates the response from the servlet
*/
public void performTask(
  HttpServletRequest request,
  HttpServletResponse response) {

  try {
    String board=request.getParameter("board");
    CompoundJSPCommand postList =
      (bbs.CompoundJSPCommand) java.beans.Beans.instantiate(
        getClass().getClassLoader(),
        "bbs.CompoundJSPCommand");
    postList.setBoard(board);
    postList.initialize();
    postList.execute();

    request.setAttribute("CompoundJSPCommand", postList);

    ServletContext sc = getServletContext();
    RequestDispatcher rd =
      sc.getRequestDispatcher("/JSP/CompoundJSPResults.jsp");
    rd.forward(request, response);

  } catch (Throwable theException) {
    // uncomment the following line when unexpected exceptions
    // are occuring to aid in debugging the problem.
    //theException.printStackTrace();
    response.setContentType("text/html");
    try {
      java.io.PrintWriter out = response.getWriter();
      out.println("<HTML>");
      out.println("<HEAD><TITLE>Compound JSPs</TITLE></HEAD>");
      out.println("<BODY BGCOLOR=#C0C0C0>");
      out.println("<H2>Exception Occurred</H2>");
      out.println(theException);
     out.println("</BODY></HTML>");
    } catch (Throwable exception) {
      theException.printStackTrace();
    }
  }
}

  /**
   * DoGet
   * Pass get requests through to PerformTask
   */
  public void doGet(
    HttpServletRequest request,
    HttpServletResponse response)
    throws javax.servlet.ServletException, java.io.IOException {
      performTask(request, response);
  }
}
