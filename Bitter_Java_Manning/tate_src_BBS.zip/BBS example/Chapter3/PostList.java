package bbs;

// Imports


import java.sql.*;
import COM.ibm.db2.jdbc.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class PostList
  extends javax.servlet.http.HttpServlet
  implements Serializable {

  /**
   * DoGet
   * Pass get requests through to PerformTask
   */
  public void doGet(
    HttpServletRequest request,
    HttpServletResponse response)
    throws javax.servlet.ServletException, java.io.IOException {
      performTask(request, response);
  }
  /**********************************************************
  * Process incoming requests for information
  * 
  * @param request encapsulates the request to the servlet
  * @param response encapsulates the response from the servlet
  */
  public void performTask(
    HttpServletRequest request,
    HttpServletResponse response) {

    try {

      response.setContentType("text/html");
      PrintWriter out = response.getWriter();
      out.println(
        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD "
          + "HTML 4.0 Transitional//EN\">\n"
          + "<HTML>\n"
          + "<HEAD><TITLE>Message Board</TITLE></HEAD>\n"
          + "<BODY>\n");

      Class.forName("COM.ibm.db2.jdbc.app.DB2Driver").newInstance();

      Connection con = null;

      // URL is jdbc:db2:dbname
      String url = "jdbc:db2:board";

      // connect with default id/password
      con = DriverManager.getConnection(url);

      // retrieve data from the database
      Statement stmt = con.createStatement();
      ResultSet rs =
        stmt.executeQuery("SELECT subject, author, board" + 
	                        " from posts");

      // display the result set
      // rs.next() returns false when there are no more rows
      out.println("<h1>Message board posts</h1>");
      out.println("<TABLE border=\"1\">");
      out.println("<TD><b>subject</b></TD>\n");
      out.println("<TD><b>author</b></TD>\n");
      out.println("<TD><b>board</b></TD>\n");

      while (rs.next()) {
        out.println("<TR>");
        String subject = rs.getString(1);
        String author = rs.getString(2);
        String board = rs.getString(3);

        out.println("<TD>" + subject + "</TD>\n");
        out.println("<TD>" + author + "</TD>\n");
        out.println("<TD>" + board + "</TD>\n");
        out.println("</TR>");
      }

      rs.close();
      stmt.close();
      out.println("</TABLE>");
      out.println("</body>");
    } catch (Throwable theException) {
      theException.printStackTrace();
    }

  }
}
