/*
 * program 3.3 
 *
 * This sample program is based on the sample that shipped with TomCat.
 * It is a basic servlet that returns an HTML page.
 * The program gets a writer, and prints HTML to the writer.
 * When the servlet completes, the printed HTML is returned to the client.
 *
*/



import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;


// The HttpServlet class is the root class for httpServlets.  
// It provides the basic functionality for the most common HTTP requests.
// It has methods for doGet and doPost.  This class will override doGet.

public class HelloWorld extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException
    {

// The response is a parameter that will contain the return HTML page.
// This statement calls a method on response that indicates that we will 
// be returning an HTML page.

        response.setContentType("text/html");

// The writer is used to generate the output page that will be returned 
//   to the client.  Since we've specified HTML, the standard HTML syntax
//   should be observed.

        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Hello bitter world!</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Hello, bitter world!</h1>");
        out.println("</body>");
        out.println("</html>");
    }
}
